<?php

declare(strict_types=1);

/**
 * Favorite Multimedia Theme - Functions & Bootstrap
 */

if (!function_exists('favorite_multimedia_theme_is_plugin_active')) {
    function favorite_multimedia_theme_is_plugin_active(): bool
    {
        return class_exists(\FavoriteCMS\Multimedia\FavoriteMultimediaPlugin::class);
    }
}

if (!function_exists('favorite_multimedia_theme_plugin_version')) {
    function favorite_multimedia_theme_plugin_version(): ?string
    {
        if (defined('\FavoriteCMS\Multimedia\FavoriteMultimediaPlugin::VERSION')) {
            return \FavoriteCMS\Multimedia\FavoriteMultimediaPlugin::VERSION;
        }
        return null;
    }
}

if (!function_exists('favorite_multimedia_theme_is_compatible')) {
    function favorite_multimedia_theme_is_compatible(): bool
    {
        $ver = favorite_multimedia_theme_plugin_version();
        return $ver !== null && version_compare($ver, '1.0.6', '>=');
    }
}

if (!function_exists('favorite_multimedia_theme_admin_notice')) {
    function favorite_multimedia_theme_admin_notice(): string
    {
        if (favorite_multimedia_theme_is_compatible()) {
            return '';
        }
        return '<div class="fm-theme-notice" style="background:#fef2f2;border:1px solid #ef4444;color:#991b1b;padding:12px;border-radius:6px;margin:16px 0;">'
            . '<strong>Favorite Multimedia Theme Notice:</strong> This theme requires the Favorite Multimedia plugin (v1.0.6 or newer). '
            . 'Please ensure the plugin is installed and activated in the admin panel.'
            . '</div>';
    }
}

if (!function_exists('favorite_multimedia_theme_asset')) {
    function favorite_multimedia_theme_asset(string $path): string
    {
        return '/themes/favorite-multimedia-theme/assets/' . ltrim($path, '/');
    }
}

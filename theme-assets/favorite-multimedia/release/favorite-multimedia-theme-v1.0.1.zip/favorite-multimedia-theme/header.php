<?php
require_once __DIR__ . '/functions.php';

$siteTitle = $siteTitle ?? \FavoriteCMS\Models\Setting::get('general', 'site_name', 'Favorite CMS');
$siteTagline = $siteTagline ?? \FavoriteCMS\Models\Setting::get('general', 'site_description', 'Entertainment Streaming Experience');
$metaTitle = $metaTitle ?? $siteTitle;
$metaDesc = $metaDescription ?? \FavoriteCMS\Models\Setting::get('seo', 'meta_description', '');

$tokensHtml = '';
if (class_exists(\FavoriteCMS\Multimedia\Theme\ThemeManager::class)) {
    try {
        $tokensHtml = \FavoriteCMS\Multimedia\Theme\ThemeManager::getInstance()->renderHeadTokens();
    } catch (\Throwable) {}
}

$isPluginActive = favorite_multimedia_theme_is_plugin_active();
$isCompatible = favorite_multimedia_theme_is_compatible();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <?php if (!empty($metaDesc)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($metaDesc, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>

    <!-- Theme Tokens & Stylesheets -->
    <link rel="stylesheet" href="/themes/favorite-multimedia-theme/assets/css/theme-tokens.css">
    <link rel="stylesheet" href="/themes/favorite-multimedia-theme/assets/css/multimedia-frontend.css">
    <link rel="stylesheet" href="/themes/favorite-multimedia-theme/assets/css/audio-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">

    <!-- Injected Dynamic Theme Tokens -->
    <?php if (!empty($tokensHtml)): ?>
        <?php echo $tokensHtml; ?>
    <?php else: ?>
        <style id="fm-theme-tokens">
        :root {
            --fm-color-primary: #E50914;
            --fm-color-secondary: #1E293B;
            --fm-color-accent: #FFB800;
            --fm-color-bg-page: #0B0E14;
            --fm-color-bg-surface: #121824;
            --fm-color-bg-elevated: #1C2436;
            --fm-color-text-primary: #FFFFFF;
            --fm-color-text-secondary: #94A3B8;
            --fm-color-text-muted: #64748B;
            --fm-color-border: #2A3548;
            --fm-font-base: system-ui, -apple-system, sans-serif;
            --fm-font-heading: system-ui, -apple-system, sans-serif;
            --fm-radius-card: 12px;
            --fm-layout-card-gap: 20px;
        }
        body { background: var(--fm-color-bg-page); color: var(--fm-color-text-primary); font-family: var(--fm-font-base); margin: 0; }
        a { color: inherit; text-decoration: none; }
        </style>
    <?php endif; ?>
</head>
<body class="fm-theme-body" style="min-height: 100vh; display: flex; flex-direction: column; background: var(--fm-color-bg-page); color: var(--fm-color-text-primary);">

<!-- Theme Top Navigation Bar -->
<header class="fm-header" style="position: sticky; top: 0; z-index: 100; background: rgba(11, 14, 20, 0.95); backdrop-filter: blur(12px); border-bottom: 1px solid var(--fm-color-border); padding: 0 24px; height: 64px; display: flex; align-items: center; justify-content: space-between;">
    <div style="display: flex; align-items: center; gap: 32px;">
        <a href="/" style="display: flex; align-items: center; gap: 8px; font-weight: 800; font-size: 1.25rem; color: var(--fm-color-primary);">
            <span>🎬</span>
            <span><?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?></span>
        </a>
        <nav style="display: flex; gap: 20px; font-weight: 600; font-size: 0.95rem;">
            <a href="/" style="color: var(--fm-color-text-primary);">Home</a>
            <a href="/movies" style="color: var(--fm-color-text-secondary);">Movies</a>
            <a href="/series" style="color: var(--fm-color-text-secondary);">Series</a>
            <a href="/multimedia/music" style="color: var(--fm-color-text-secondary);">Music</a>
            <a href="/multimedia/search" style="color: var(--fm-color-text-secondary);">Search</a>
            <a href="/multimedia/library" style="color: var(--fm-color-text-secondary);">Library</a>
        </nav>
    </div>
    <div style="display: flex; align-items: center; gap: 16px;">
        <a href="/multimedia/search" style="color: var(--fm-color-text-secondary); font-size: 1.1rem;" title="Search">🔍</a>
        <?php if (!empty($_SESSION['user_id'])): ?>
            <a href="/multimedia/library" style="font-size: 0.85rem; font-weight: 600; background: var(--fm-color-bg-surface); border: 1px solid var(--fm-color-border); padding: 6px 14px; border-radius: 20px;">My Library</a>
        <?php else: ?>
            <a href="/admin/login" style="font-size: 0.85rem; font-weight: 600; background: var(--fm-color-primary); color: #fff; padding: 6px 16px; border-radius: 20px;">Sign In</a>
        <?php endif; ?>
    </div>
</header>

<?php
/**
 * Global Responsive Frontend Header Component.
 *
 * @var string|null $currentNav Active navigation item ('home', 'movies', 'series', 'music', 'discover')
 */

use FavoriteCMS\Models\Setting;
use FavoriteCMS\Multimedia\Theme\ThemeManager;

$themeConfig = ThemeManager::getInstance()->getActiveConfig();
$headerStyle = (string)$themeConfig->get('header', 'style', 'glass');
$isSticky = (bool)$themeConfig->get('header', 'sticky', true);
$brandTitle = (string)$themeConfig->get('branding', 'brand_title', 'Favorite Multimedia');
$logoUrl = (string)$themeConfig->get('branding', 'logo_url', '');
$user = current_user();
?>
<header class="fm-header fm-header-<?php echo htmlspecialchars($headerStyle, ENT_QUOTES, 'UTF-8'); ?> <?php echo $isSticky ? 'fm-header-sticky' : ''; ?>">
    <div class="fm-header-inner">
        <!-- Brand Logo -->
        <a href="/multimedia" class="fm-brand-link" aria-label="<?php echo htmlspecialchars($brandTitle, ENT_QUOTES, 'UTF-8'); ?>">
            <?php if ($logoUrl !== ''): ?>
                <img src="<?php echo htmlspecialchars($logoUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($brandTitle, ENT_QUOTES, 'UTF-8'); ?>" class="fm-brand-logo" style="height: var(--fm-header-logo-height);">
            <?php else: ?>
                <span class="fm-brand-icon">🎬</span>
                <span class="fm-brand-text"><?php echo htmlspecialchars($brandTitle, ENT_QUOTES, 'UTF-8'); ?></span>
            <?php endif; ?>
        </a>

        <!-- Desktop Primary Nav -->
        <nav class="fm-desktop-nav" aria-label="Primary Navigation">
            <a href="/multimedia" class="fm-nav-link <?php echo ($currentNav ?? '') === 'home' ? 'active' : ''; ?>">Home</a>
            <a href="/movies" class="fm-nav-link <?php echo ($currentNav ?? '') === 'movies' ? 'active' : ''; ?>">Movies</a>
            <a href="/series" class="fm-nav-link <?php echo ($currentNav ?? '') === 'series' ? 'active' : ''; ?>">Series</a>
            <a href="/multimedia/music" class="fm-nav-link <?php echo ($currentNav ?? '') === 'music' ? 'active' : ''; ?>">Music</a>
            <a href="/multimedia/discover" class="fm-nav-link <?php echo ($currentNav ?? '') === 'discover' ? 'active' : ''; ?>">Browse</a>
        </nav>

        <!-- Header Actions -->
        <div class="fm-header-actions">
            <!-- Search Form / Link -->
            <form action="/multimedia/search" method="GET" class="fm-search-form" role="search">
                <div class="fm-search-wrap">
                    <span class="fm-search-icon" aria-hidden="true">🔍</span>
                    <input type="search" name="q" class="fm-search-input" placeholder="Search movies, songs..." aria-label="Search content">
                </div>
            </form>

            <?php if ($user): ?>
                <a href="/multimedia/my-list" class="fm-action-link" title="My Favorites &amp; Watchlist" aria-label="My Watchlist">
                    <span aria-hidden="true">❤️</span>
                    <span class="fm-desktop-only">My List</span>
                </a>
                <div class="fm-user-menu">
                    <a href="/multimedia/library" class="fm-user-badge" title="<?php echo htmlspecialchars((string)($user->name ?? $user->username), ENT_QUOTES, 'UTF-8'); ?>">
                        <span class="fm-user-avatar">👤</span>
                        <span class="fm-desktop-only fm-user-name"><?php echo htmlspecialchars((string)($user->name ?? $user->username), ENT_QUOTES, 'UTF-8'); ?></span>
                    </a>
                </div>
            <?php else: ?>
                <a href="/admin/login" class="fm-btn fm-btn-primary fm-btn-sm">Sign In</a>
            <?php endif; ?>
        </div>
    </div>
</header>


<?php
/**
 * Mobile Bottom Navigation Bar Component.
 *
 * Provides comfortable touch destinations respecting env(safe-area-inset-bottom).
 *
 * @var string|null $currentNav
 */
$user = current_user();
?>
<!-- Persistent Audio Player System -->
<?php include __DIR__ . '/audio-player.php'; ?>

<!-- Accessible Global Toast System -->
<?php include __DIR__ . '/toast.php'; ?>

<nav class="fm-mobile-nav" aria-label="Mobile Bottom Navigation">
    <a href="/multimedia" class="fm-mobile-nav-item <?php echo ($currentNav ?? '') === 'home' ? 'active' : ''; ?>">
        <span class="fm-mobile-nav-icon" aria-hidden="true">🏠</span>
        <span class="fm-mobile-nav-label">Home</span>
    </a>
    <a href="/movies" class="fm-mobile-nav-item <?php echo ($currentNav ?? '') === 'movies' ? 'active' : ''; ?>">
        <span class="fm-mobile-nav-icon" aria-hidden="true">🎬</span>
        <span class="fm-mobile-nav-label">Movies</span>
    </a>
    <a href="/multimedia/music" class="fm-mobile-nav-item <?php echo ($currentNav ?? '') === 'music' ? 'active' : ''; ?>">
        <span class="fm-mobile-nav-icon" aria-hidden="true">🎵</span>
        <span class="fm-mobile-nav-label">Music</span>
    </a>
    <a href="/multimedia/search" class="fm-mobile-nav-item <?php echo ($currentNav ?? '') === 'search' ? 'active' : ''; ?>">
        <span class="fm-mobile-nav-icon" aria-hidden="true">🔍</span>
        <span class="fm-mobile-nav-label">Search</span>
    </a>
    <a href="<?php echo $user ? '/multimedia/library' : '/admin/login'; ?>" class="fm-mobile-nav-item <?php echo ($currentNav ?? '') === 'library' ? 'active' : ''; ?>">
        <span class="fm-mobile-nav-icon" aria-hidden="true">📚</span>
        <span class="fm-mobile-nav-label"><?php echo $user ? 'Library' : 'Sign In'; ?></span>
    </a>
</nav>


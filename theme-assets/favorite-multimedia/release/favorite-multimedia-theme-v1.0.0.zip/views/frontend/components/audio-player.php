<?php
/**
 * Favorite Multimedia — Master Persistent Audio Player Bundle.
 * Combines Mini-Player, Expanded Modal, Queue Drawer, and Audio Engine Scripts.
 */
$compDir = __DIR__;
?>
<!-- Persistent Audio Player System -->
<?php include $compDir . '/mini-player.php'; ?>
<?php include $compDir . '/expanded-player.php'; ?>
<?php include $compDir . '/audio-queue-drawer.php'; ?>

<!-- Global Audio Toast Notification Container -->
<div id="fm-audio-toast-container" class="fm-audio-toast-container" aria-live="polite"></div>

<!-- Persistent Audio Player Scripts -->
<script src="/plugins/favorite-multimedia/assets/js/audio-player/favorite-audio-state.js"></script>
<script src="/plugins/favorite-multimedia/assets/js/audio-player/favorite-audio-queue.js"></script>
<script src="/plugins/favorite-multimedia/assets/js/audio-player/favorite-audio-player.js"></script>
<script src="/plugins/favorite-multimedia/assets/js/audio-player/favorite-audio-ui.js"></script>


<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Theme;

/**
 * Manages Theme Manifest definition and compatibility contracts.
 */
class ThemePackageService
{
    public const THEME_NAME = 'Favorite Multimedia Theme';
    public const THEME_SLUG = 'favorite-multimedia-theme';
    public const THEME_VERSION = '1.0.0';
    public const REQUIRES_PLUGIN = 'favorite-multimedia';
    public const MINIMUM_PLUGIN_VERSION = '1.0.6';
    public const THEME_SCHEMA_VERSION = '1.0.0';

    /**
     * Returns canonical theme manifest metadata.
     */
    public static function getManifest(): array
    {
        return [
            'name'                   => self::THEME_NAME,
            'slug'                   => self::THEME_SLUG,
            'version'                => self::THEME_VERSION,
            'description'            => 'High-performance streaming and audio experience theme for Favorite Multimedia',
            'requires_plugin'        => self::REQUIRES_PLUGIN,
            'minimum_plugin_version' => self::MINIMUM_PLUGIN_VERSION,
            'theme_schema_version'   => self::THEME_SCHEMA_VERSION,
            'author'                 => 'Favorite CMS Team',
            'license'                => 'Proprietary / Builtin',
        ];
    }

    /**
     * Validate a theme manifest array against schema requirements.
     *
     * @return array<int, string> Array of error messages, empty if valid.
     */
    public static function validateManifest(array $manifest): array
    {
        $errors = [];
        $requiredFields = ['name', 'slug', 'version', 'requires_plugin', 'minimum_plugin_version', 'theme_schema_version'];

        foreach ($requiredFields as $field) {
            if (empty($manifest[$field])) {
                $errors[] = "Manifest missing required field: '{$field}'";
            }
        }

        if (isset($manifest['slug']) && $manifest['slug'] !== self::THEME_SLUG) {
            $errors[] = "Invalid theme slug: '{$manifest['slug']}'. Expected '" . self::THEME_SLUG . "'";
        }

        return $errors;
    }

    /**
     * Verify compatibility of the theme with the current running plugin environment.
     *
     * @return array{compatible: bool, errors: array<int, string>}
     */
    public static function verifyCompatibility(string $installedPluginVersion, string $pluginSlug = 'favorite-multimedia'): array
    {
        $errors = [];

        if ($pluginSlug !== self::REQUIRES_PLUGIN) {
            $errors[] = "Missing required plugin: '" . self::REQUIRES_PLUGIN . "'. Found: '{$pluginSlug}'";
        }

        if (version_compare($installedPluginVersion, self::MINIMUM_PLUGIN_VERSION, '<')) {
            $errors[] = "Installed plugin version ({$installedPluginVersion}) is older than required minimum (" . self::MINIMUM_PLUGIN_VERSION . ")";
        }

        return [
            'compatible' => empty($errors),
            'errors'     => $errors,
        ];
    }
}

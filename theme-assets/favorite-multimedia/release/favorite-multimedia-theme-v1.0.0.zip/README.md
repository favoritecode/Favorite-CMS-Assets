# Favorite Multimedia Theme v1.0.0

Official streaming and audio experience theme for Favorite Multimedia.

## Requirements
- Favorite CMS Universal
- Favorite Multimedia Plugin >= 1.0.6

## Features
- No-code Theme Studio with live iframe canvas
- Drag & Drop Homepage Section Builder
- Persistent HTML5 Audio Player & Audio Queue Drawer
- Universal Search across Movies, Series, Songs, Albums, Artists, and Playlists
- Personal User Library with Continue Watching & Continue Listening
- Fully Accessible & Responsive Mobile-First Experience

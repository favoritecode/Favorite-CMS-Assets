<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Controllers;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\Setting;
use FavoriteCMS\Models\User;
use FavoriteCMS\Multimedia\Models\Album;
use FavoriteCMS\Multimedia\Models\AnalyticsEvent;
use FavoriteCMS\Multimedia\Models\Artist;
use FavoriteCMS\Multimedia\Models\Episode;
use FavoriteCMS\Multimedia\Models\Favorite;
use FavoriteCMS\Multimedia\Models\Genre;
use FavoriteCMS\Multimedia\Models\MediaProcessingJob;
use FavoriteCMS\Multimedia\Models\MediaSource;
use FavoriteCMS\Multimedia\Models\Movie;
use FavoriteCMS\Multimedia\Models\PlaybackProgress;
use FavoriteCMS\Multimedia\Models\Playlist;
use FavoriteCMS\Multimedia\Models\Season;
use FavoriteCMS\Multimedia\Models\Series;
use FavoriteCMS\Multimedia\Models\Song;
use FavoriteCMS\Multimedia\Models\Subtitle;
use FavoriteCMS\Multimedia\Models\MediaLocalization;
use FavoriteCMS\Multimedia\Permissions\MultimediaPermission;
use FavoriteCMS\Multimedia\Services\FFmpegService;
use FavoriteCMS\Multimedia\Services\MediaLanguageService;
use FavoriteCMS\Multimedia\Services\MediaProcessingService;
use FavoriteCMS\Multimedia\Services\MediaSourceResolver;
use FavoriteCMS\Multimedia\Services\MultimediaEngagementService;
use FavoriteCMS\Multimedia\Services\MultimediaNotificationService;
use FavoriteCMS\Multimedia\Services\MultimediaReleaseService;
use FavoriteCMS\Multimedia\Models\MediaStorageFile;
use FavoriteCMS\Multimedia\Services\MediaStorageService;
use FavoriteCMS\Multimedia\Storage\MediaStorageManager;
use FavoriteCMS\Multimedia\Services\MultimediaSubscriptionService;
use FavoriteCMS\Multimedia\Services\MultimediaAnalyticsService;

class MultimediaAdminController
{
    private Application $app;
    private Database $db;

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->db = $app->make(Database::class);
    }

    /**
     * Entry dispatcher for admin pages.
     */
    public function handle(Request $request, string $section = 'dashboard'): Response|string
    {
        $user = current_user();
        if (!$user || $user->isBanned()) {
            return Response::redirect('/admin/login');
        }

        if (!MultimediaPermission::can(MultimediaPermission::VIEW, $user)) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to view Multimedia.</p>', 403);
        }

        return match ($section) {
            'dashboard'  => $this->dashboard($request),
            'movies'     => $this->movies($request),
            'series'     => $this->series($request),
            'seasons'    => $this->seasons($request),
            'episodes'   => $this->episodes($request),
            'songs'      => $this->songs($request),
            'playlists'  => $this->playlists($request),
            'genres'     => $this->genres($request),
            'artists'    => $this->artists($request),
            'albums'     => $this->albums($request),
            'sources'    => $this->sources($request),
            'subtitles'  => $this->subtitles($request),
            'access'     => $this->accessRules($request),
            'analytics'  => $this->analytics($request),
            'settings'   => $this->settings($request),
            'moderation' => $this->moderation($request),
            'releases'   => $this->releases($request),
            'processing'    => $this->processing($request),
            'storage'       => $this->storage($request),
            'localizations' => $this->localizations($request),
            default         => $this->dashboard($request),
        };
    }

    // 1. Dashboard
    public function dashboard(Request $request): string
    {
        $stats = AnalyticsEvent::getStats();
        $recentMovies = Movie::published(5);
        $recentSeries = Series::published(5);
        $recentSongs = Song::published(5);
        $recentPlaylists = Playlist::published(5);

        return $this->renderView('dashboard', [
            'stats'           => $stats,
            'recentMovies'    => $recentMovies,
            'recentSeries'    => $recentSeries,
            'recentSongs'     => $recentSongs,
            'recentPlaylists' => $recentPlaylists,
        ]);
    }

    // 2. Movies CRUD
    public function movies(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            if (!MultimediaPermission::can(MultimediaPermission::CREATE)) {
                return Response::make('<h1>403 Forbidden</h1>', 403);
            }
            $this->validateCsrf($request);

            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title);
                $pubFields = $this->resolvePublishingFields($request, 'multimedia_movies', $id);
                $data = [
                    'title'           => $title,
                    'slug'            => $slug,
                    'description'     => trim((string)$request->post('description', '')),
                    'poster'          => trim((string)$request->post('poster', '')),
                    'backdrop'        => trim((string)$request->post('backdrop', '')),
                    'release_year'    => (int)$request->post('release_year', 0) ?: null,
                    'release_date'    => trim((string)$request->post('release_date', '')) ?: null,
                    'language'          => trim((string)$request->post('language', '')),
                    'original_language' => trim((string)$request->post('original_language', $request->post('language', 'en'))),
                    'country'           => trim((string)$request->post('country', '')),
                    'duration'          => (int)$request->post('duration', 0),
                    'director'          => trim((string)$request->post('director', '')),
                    'cast'              => trim((string)$request->post('cast', '')),
                    'trailer_url'       => trim((string)$request->post('trailer_url', '')),
                    'featured'          => (int)$request->post('featured', 0),
                    'status'            => $pubFields['status'],
                    'publish_at'        => $pubFields['publish_at'],
                    'published_at'      => $pubFields['published_at'],
                    'unpublish_at'      => $pubFields['unpublish_at'],
                    'access_mode'       => (string)$request->post('access_mode', 'public'),
                    'download_policy'   => (string)$request->post('download_policy', 'inherit'),
                    'seo_title'         => trim((string)$request->post('seo_title', '')),
                    'seo_description'   => trim((string)$request->post('seo_description', '')),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_movies', $data, ['id' => $id]);
                    $movieId = $id;
                    $_SESSION['flash_success'] = 'Movie updated successfully.';
                } else {
                    $movieId = $this->db->insert('multimedia_movies', $data);
                    $_SESSION['flash_success'] = 'Movie created successfully.';
                }

                // Sync genres
                $genres = (array)$request->post('genres', []);
                Genre::syncForContent('movie', $movieId, $genres);

                return Response::redirect('/admin/page/multimedia-movies');
            }

            if ($action === 'delete') {
                if (!MultimediaPermission::can(MultimediaPermission::DELETE)) {
                    return Response::make('<h1>403 Forbidden</h1>', 403);
                }
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_movies', ['id' => $id]);
                    $this->db->delete('multimedia_sources', ['content_type' => 'movie', 'content_id' => $id]);
                    $this->db->delete('multimedia_subtitles', ['content_type' => 'movie', 'content_id' => $id]);
                    $this->db->delete('multimedia_content_genres', ['content_type' => 'movie', 'content_id' => $id]);
                    PlaybackProgress::deleteForContent('movie', $id);
                    Favorite::deleteForContent('movie', $id);
                    MultimediaEngagementService::deleteForContent('movie', $id);
                    MediaLocalization::deleteForContent('movie', $id);
                    $_SESSION['flash_success'] = 'Movie deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-movies');
            }
        }

        $editId = (int)$request->get('edit', 0);
        $editMovie = ($editId > 0) ? Movie::find($editId) : null;
        $items = Movie::all();
        $genres = Genre::all();

        return $this->renderView('movies', [
            'items'     => $items,
            'editMovie' => $editMovie,
            'genres'    => $genres,
        ]);
    }

    // 3. Series CRUD
    public function series(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title);
                $pubFields = $this->resolvePublishingFields($request, 'multimedia_series', $id);
                $data = [
                    'title'           => $title,
                    'slug'            => $slug,
                    'description'     => trim((string)$request->post('description', '')),
                    'poster'          => trim((string)$request->post('poster', '')),
                    'backdrop'        => trim((string)$request->post('backdrop', '')),
                    'release_year'      => (int)$request->post('release_year', 0) ?: null,
                    'language'          => trim((string)$request->post('language', '')),
                    'original_language' => trim((string)$request->post('original_language', $request->post('language', 'en'))),
                    'country'           => trim((string)$request->post('country', '')),
                    'director'          => trim((string)$request->post('director', '')),
                    'cast'              => trim((string)$request->post('cast', '')),
                    'trailer_url'       => trim((string)$request->post('trailer_url', '')),
                    'featured'          => (int)$request->post('featured', 0),
                    'status'            => $pubFields['status'],
                    'publish_at'        => $pubFields['publish_at'],
                    'published_at'      => $pubFields['published_at'],
                    'unpublish_at'      => $pubFields['unpublish_at'],
                    'access_mode'       => (string)$request->post('access_mode', 'public'),
                    'download_policy'   => (string)$request->post('download_policy', 'inherit'),
                    'seo_title'         => trim((string)$request->post('seo_title', '')),
                    'seo_description'   => trim((string)$request->post('seo_description', '')),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_series', $data, ['id' => $id]);
                    $seriesId = $id;
                    $_SESSION['flash_success'] = 'Series updated successfully.';
                } else {
                    $seriesId = $this->db->insert('multimedia_series', $data);
                    $_SESSION['flash_success'] = 'Series created successfully.';
                }

                $genres = (array)$request->post('genres', []);
                Genre::syncForContent('series', $seriesId, $genres);

                return Response::redirect('/admin/page/multimedia-series');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $episodes = $this->db->select("SELECT id FROM multimedia_episodes WHERE series_id = ?", [$id]);
                    foreach ($episodes as $ep) {
                        $this->db->delete('multimedia_sources', ['content_type' => 'episode', 'content_id' => $ep->id]);
                        $this->db->delete('multimedia_subtitles', ['content_type' => 'episode', 'content_id' => $ep->id]);
                        PlaybackProgress::deleteForContent('episode', (int)$ep->id);
                        Favorite::deleteForContent('episode', (int)$ep->id);
                        MultimediaEngagementService::deleteForContent('episode', (int)$ep->id);
                        MediaLocalization::deleteForContent('episode', (int)$ep->id);
                    }
                    $this->db->delete('multimedia_episodes', ['series_id' => $id]);
                    $this->db->delete('multimedia_seasons', ['series_id' => $id]);
                    $this->db->delete('multimedia_content_genres', ['content_type' => 'series', 'content_id' => $id]);
                    $this->db->delete('multimedia_series', ['id' => $id]);
                    Favorite::deleteForContent('series', $id);
                    MultimediaEngagementService::deleteForContent('series', $id);
                    MultimediaSubscriptionService::deleteForTarget('series', $id);
                    MediaLocalization::deleteForContent('series', $id);
                    $_SESSION['flash_success'] = 'Series deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-series');
            }
        }

        $editId = (int)$request->get('edit', 0);
        $editSeries = ($editId > 0) ? Series::find($editId) : null;
        $items = Series::all();
        $genres = Genre::all();

        return $this->renderView('series', [
            'items'      => $items,
            'editSeries' => $editSeries,
            'genres'     => $genres,
        ]);
    }

    // 4. Seasons CRUD
    public function seasons(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $seriesId = (int)$request->post('series_id', 0);
                $data = [
                    'series_id'     => $seriesId,
                    'season_number' => (int)$request->post('season_number', 1),
                    'title'         => trim((string)$request->post('title', '')) ?: 'Season ' . (int)$request->post('season_number', 1),
                    'description'   => trim((string)$request->post('description', '')),
                    'poster'        => trim((string)$request->post('poster', '')),
                    'release_date'  => trim((string)$request->post('release_date', '')) ?: null,
                    'sort_order'    => (int)$request->post('sort_order', 0),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_seasons', $data, ['id' => $id]);
                    $_SESSION['flash_success'] = 'Season updated successfully.';
                } else {
                    $this->db->insert('multimedia_seasons', $data);
                    $_SESSION['flash_success'] = 'Season created successfully.';
                }
                return Response::redirect('/admin/page/multimedia-seasons?series_id=' . $seriesId);
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                $seriesId = (int)$request->post('series_id', 0);
                if ($id > 0) {
                    $episodes = $this->db->select("SELECT id FROM multimedia_episodes WHERE season_id = ?", [$id]);
                    foreach ($episodes as $ep) {
                        $this->db->delete('multimedia_sources', ['content_type' => 'episode', 'content_id' => $ep->id]);
                        $this->db->delete('multimedia_subtitles', ['content_type' => 'episode', 'content_id' => $ep->id]);
                    }
                    $this->db->delete('multimedia_episodes', ['season_id' => $id]);
                    $this->db->delete('multimedia_seasons', ['id' => $id]);
                    $_SESSION['flash_success'] = 'Season deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-seasons?series_id=' . $seriesId);
            }
        }

        $seriesList = Series::all();
        $selectedSeriesId = (int)$request->get('series_id', ($seriesList[0]->id ?? 0));
        $items = $this->db->select("SELECT * FROM multimedia_seasons WHERE series_id = ? ORDER BY season_number ASC", [$selectedSeriesId]);
        $seasons = array_map(fn($r) => new Season((array)$r), $items);

        $editId = (int)$request->get('edit', 0);
        $editSeason = ($editId > 0) ? Season::find($editId) : null;

        return $this->renderView('seasons', [
            'seriesList'       => $seriesList,
            'selectedSeriesId' => $selectedSeriesId,
            'seasons'          => $seasons,
            'editSeason'       => $editSeason,
        ]);
    }

    // 5. Episodes CRUD
    public function episodes(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $seasonId = (int)$request->post('season_id', 0);
                $seriesId = (int)$request->post('series_id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title . '-s' . $seasonId . '-e' . (int)$request->post('episode_number', 1));

                $pubFields = $this->resolvePublishingFields($request, 'multimedia_episodes', $id);
                $data = [
                    'series_id'       => $seriesId,
                    'season_id'       => $seasonId,
                    'episode_number'  => (int)$request->post('episode_number', 1),
                    'title'           => $title,
                    'slug'            => $slug,
                    'description'     => trim((string)$request->post('description', '')),
                    'thumbnail'       => trim((string)$request->post('thumbnail', '')),
                    'duration'        => (int)$request->post('duration', 0),
                    'release_date'    => trim((string)$request->post('release_date', '')) ?: null,
                    'status'          => $pubFields['status'],
                    'publish_at'      => $pubFields['publish_at'],
                    'published_at'    => $pubFields['published_at'],
                    'unpublish_at'    => $pubFields['unpublish_at'],
                    'access_mode'     => (string)$request->post('access_mode', 'inherit'),
                    'download_policy' => (string)$request->post('download_policy', 'inherit'),
                    'sort_order'      => (int)$request->post('sort_order', 0),
                ];

                if ($id > 0) {
                    $existing = Episode::find($id);
                    $wasPublished = $existing && $existing->status === 'published';
                    $this->db->update('multimedia_episodes', $data, ['id' => $id]);
                    if (!$wasPublished && $data['status'] === 'published') {
                        MultimediaNotificationService::onEpisodePublished($id);
                    }
                    $_SESSION['flash_success'] = 'Episode updated successfully.';
                } else {
                    $newId = (int)$this->db->insert('multimedia_episodes', $data);
                    if ($data['status'] === 'published') {
                        MultimediaNotificationService::onEpisodePublished($newId);
                    }
                    $_SESSION['flash_success'] = 'Episode created successfully.';
                }
                return Response::redirect('/admin/page/multimedia-episodes?season_id=' . $seasonId);
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                $seasonId = (int)$request->post('season_id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_episodes', ['id' => $id]);
                    $this->db->delete('multimedia_sources', ['content_type' => 'episode', 'content_id' => $id]);
                    $this->db->delete('multimedia_subtitles', ['content_type' => 'episode', 'content_id' => $id]);
                    PlaybackProgress::deleteForContent('episode', $id);
                    Favorite::deleteForContent('episode', $id);
                    MultimediaEngagementService::deleteForContent('episode', $id);
                    $_SESSION['flash_success'] = 'Episode deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-episodes?season_id=' . $seasonId);
            }
        }

        $seriesList = Series::all();
        $selectedSeasonId = (int)$request->get('season_id', 0);
        $seasons = Season::all();

        $where = ($selectedSeasonId > 0) ? "WHERE season_id = ?" : "";
        $params = ($selectedSeasonId > 0) ? [$selectedSeasonId] : [];
        $items = $this->db->select("SELECT * FROM multimedia_episodes {$where} ORDER BY sort_order ASC, episode_number ASC", $params);
        $episodes = array_map(fn($r) => new Episode((array)$r), $items);

        $editId = (int)$request->get('edit', 0);
        $editEpisode = ($editId > 0) ? Episode::find($editId) : null;

        return $this->renderView('episodes', [
            'seriesList'       => $seriesList,
            'seasons'          => $seasons,
            'selectedSeasonId' => $selectedSeasonId,
            'episodes'         => $episodes,
            'editEpisode'      => $editEpisode,
        ]);
    }

    // 6. Songs CRUD
    public function songs(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title);
                $pubFields = $this->resolvePublishingFields($request, 'multimedia_songs', $id);
                $data = [
                    'title'           => $title,
                    'slug'            => $slug,
                    'description'     => trim((string)$request->post('description', '')),
                    'cover'           => trim((string)$request->post('cover', '')),
                    'artist_id'       => (int)$request->post('artist_id', 0) ?: null,
                    'album_id'        => (int)$request->post('album_id', 0) ?: null,
                    'language'        => trim((string)$request->post('language', '')),
                    'release_date'    => trim((string)$request->post('release_date', '')) ?: null,
                    'duration'        => (int)$request->post('duration', 0),
                    'lyrics'          => trim((string)$request->post('lyrics', '')),
                    'featured'        => (int)$request->post('featured', 0),
                    'status'          => $pubFields['status'],
                    'publish_at'      => $pubFields['publish_at'],
                    'published_at'    => $pubFields['published_at'],
                    'unpublish_at'    => $pubFields['unpublish_at'],
                    'access_mode'     => (string)$request->post('access_mode', 'public'),
                    'download_policy' => (string)$request->post('download_policy', 'inherit'),
                    'seo_title'       => trim((string)$request->post('seo_title', '')),
                    'seo_description' => trim((string)$request->post('seo_description', '')),
                ];

                if ($id > 0) {
                    $existing = Song::find($id);
                    $wasPublished = $existing && $existing->status === 'published';
                    $this->db->update('multimedia_songs', $data, ['id' => $id]);
                    $songId = $id;
                    if (!$wasPublished && $data['status'] === 'published') {
                        MultimediaNotificationService::onSongPublished((int)$songId);
                    }
                    $_SESSION['flash_success'] = 'Song updated successfully.';
                } else {
                    $songId = (int)$this->db->insert('multimedia_songs', $data);
                    if ($data['status'] === 'published') {
                        MultimediaNotificationService::onSongPublished((int)$songId);
                    }
                    $_SESSION['flash_success'] = 'Song created successfully.';
                }

                $genres = (array)$request->post('genres', []);
                Genre::syncForContent('song', $songId, $genres);

                // Auto source creation if audio_url provided
                $audioUrl = trim((string)$request->post('audio_url', ''));
                if ($audioUrl !== '') {
                    $resolved = MediaSourceResolver::resolve($audioUrl, 'auto', 'audio');
                    $this->db->insert('multimedia_sources', [
                        'content_type'   => 'song',
                        'content_id'     => $songId,
                        'source_mode'    => $resolved['source_mode'],
                        'source_type'    => 'audio',
                        'url_or_path'    => $audioUrl,
                        'label'          => 'Main Audio',
                        'mime_type'      => $resolved['mime_type'],
                        'is_default'     => 1,
                        'allow_download' => 'inherit',
                        'status'         => 'active',
                    ]);
                }

                return Response::redirect('/admin/page/multimedia-songs');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_songs', ['id' => $id]);
                    $this->db->delete('multimedia_sources', ['content_type' => 'song', 'content_id' => $id]);
                    $this->db->delete('multimedia_playlist_items', ['song_id' => $id]);
                    $this->db->delete('multimedia_content_genres', ['content_type' => 'song', 'content_id' => $id]);
                    PlaybackProgress::deleteForContent('song', $id);
                    Favorite::deleteForContent('song', $id);
                    MultimediaEngagementService::deleteForContent('song', $id);
                    $_SESSION['flash_success'] = 'Song deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-songs');
            }
        }

        $editId = (int)$request->get('edit', 0);
        $editSong = ($editId > 0) ? Song::find($editId) : null;
        $items = Song::all();
        $artists = Artist::all();
        $albums = Album::all();
        $genres = Genre::all();

        return $this->renderView('songs', [
            'items'    => $items,
            'editSong' => $editSong,
            'artists'  => $artists,
            'albums'   => $albums,
            'genres'   => $genres,
        ]);
    }

    // 7. Playlists CRUD
    public function playlists(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title);
                $data = [
                    'title'           => $title,
                    'slug'            => $slug,
                    'description'     => trim((string)$request->post('description', '')),
                    'cover'           => trim((string)$request->post('cover', '')),
                    'featured'        => (int)$request->post('featured', 0),
                    'status'          => (string)$request->post('status', 'published'),
                    'access_mode'     => (string)$request->post('access_mode', 'public'),
                    'download_policy' => (string)$request->post('download_policy', 'inherit'),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_playlists', $data, ['id' => $id]);
                    $playlistId = $id;
                    $_SESSION['flash_success'] = 'Playlist updated successfully.';
                } else {
                    $playlistId = $this->db->insert('multimedia_playlists', $data);
                    $_SESSION['flash_success'] = 'Playlist created successfully.';
                }

                // Selected songs
                $songIds = (array)$request->post('songs', []);
                $playlist = Playlist::find($playlistId);
                if ($playlist) {
                    $this->db->delete('multimedia_playlist_items', ['playlist_id' => $playlistId]);
                    foreach ($songIds as $order => $sId) {
                        $playlist->addSong((int)$sId, (int)$order);
                    }
                    if ($data['status'] === 'published') {
                        MultimediaNotificationService::onPlaylistUpdated((int)$playlistId);
                    }
                }

                return Response::redirect('/admin/page/multimedia-playlists');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_playlists', ['id' => $id]);
                    $this->db->delete('multimedia_playlist_items', ['playlist_id' => $id]);
                    Favorite::deleteForContent('playlist', $id);
                    MultimediaEngagementService::deleteForContent('playlist', $id);
                    MultimediaSubscriptionService::deleteForTarget('playlist', $id);
                    $_SESSION['flash_success'] = 'Playlist deleted successfully.';
                }
                return Response::redirect('/admin/page/multimedia-playlists');
            }
        }

        $editId = (int)$request->get('edit', 0);
        $editPlaylist = ($editId > 0) ? Playlist::find($editId) : null;
        $items = Playlist::all();
        $allSongs = Song::all();

        return $this->renderView('playlists', [
            'items'        => $items,
            'editPlaylist' => $editPlaylist,
            'allSongs'     => $allSongs,
        ]);
    }

    // 8. Genres CRUD
    public function genres(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $name = trim((string)$request->post('name', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($name);
                $data = [
                    'name'        => $name,
                    'slug'        => $slug,
                    'description' => trim((string)$request->post('description', '')),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_genres', $data, ['id' => $id]);
                    $_SESSION['flash_success'] = 'Genre updated.';
                } else {
                    $this->db->insert('multimedia_genres', $data);
                    $_SESSION['flash_success'] = 'Genre created.';
                }
                return Response::redirect('/admin/page/multimedia-genres');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_genres', ['id' => $id]);
                    $this->db->delete('multimedia_content_genres', ['genre_id' => $id]);
                    $_SESSION['flash_success'] = 'Genre deleted.';
                }
                return Response::redirect('/admin/page/multimedia-genres');
            }
        }

        $items = Genre::all();
        $editId = (int)$request->get('edit', 0);
        $editGenre = ($editId > 0) ? Genre::find($editId) : null;

        return $this->renderView('genres', [
            'items'     => $items,
            'editGenre' => $editGenre,
        ]);
    }

    // 9. Artists CRUD
    public function artists(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $name = trim((string)$request->post('name', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($name);
                $data = [
                    'name'      => $name,
                    'slug'      => $slug,
                    'photo'     => trim((string)$request->post('photo', '')),
                    'biography' => trim((string)$request->post('biography', '')),
                    'status'    => (string)$request->post('status', 'active'),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_artists', $data, ['id' => $id]);
                    $_SESSION['flash_success'] = 'Artist updated.';
                } else {
                    $this->db->insert('multimedia_artists', $data);
                    $_SESSION['flash_success'] = 'Artist created.';
                }
                return Response::redirect('/admin/page/multimedia-artists');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_artists', ['id' => $id]);
                    MultimediaSubscriptionService::deleteForTarget('artist', $id);
                    $_SESSION['flash_success'] = 'Artist deleted.';
                }
                return Response::redirect('/admin/page/multimedia-artists');
            }
        }

        $items = Artist::all();
        $editId = (int)$request->get('edit', 0);
        $editArtist = ($editId > 0) ? Artist::find($editId) : null;

        return $this->renderView('artists', [
            'items'      => $items,
            'editArtist' => $editArtist,
        ]);
    }

    // 10. Albums CRUD
    public function albums(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $title = trim((string)$request->post('title', ''));
                $slug = trim((string)$request->post('slug', '')) ?: str_slug($title);
                $data = [
                    'title'        => $title,
                    'slug'         => $slug,
                    'cover'        => trim((string)$request->post('cover', '')),
                    'artist_id'    => (int)$request->post('artist_id', 0) ?: null,
                    'release_date' => trim((string)$request->post('release_date', '')) ?: null,
                    'status'       => (string)$request->post('status', 'published'),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_albums', $data, ['id' => $id]);
                    $_SESSION['flash_success'] = 'Album updated.';
                } else {
                    $this->db->insert('multimedia_albums', $data);
                    $_SESSION['flash_success'] = 'Album created.';
                }
                return Response::redirect('/admin/page/multimedia-albums');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_albums', ['id' => $id]);
                    $_SESSION['flash_success'] = 'Album deleted.';
                }
                return Response::redirect('/admin/page/multimedia-albums');
            }
        }

        $items = Album::all();
        $artists = Artist::all();
        $editId = (int)$request->get('edit', 0);
        $editAlbum = ($editId > 0) ? Album::find($editId) : null;

        return $this->renderView('albums', [
            'items'     => $items,
            'artists'   => $artists,
            'editAlbum' => $editAlbum,
        ]);
    }

    // 11. Sources CRUD
    public function sources(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $url = trim((string)$request->post('url_or_path', ''));
                $manualType = trim((string)$request->post('source_type', ''));

                $resolved = MediaSourceResolver::resolve($url, 'auto', ($manualType !== 'unknown' && $manualType !== '') ? $manualType : null);

                $rawLang = trim((string)$request->post('language_code', ''));
                $langCode = $rawLang !== '' ? MediaLanguageService::normalizeLanguageCode($rawLang) : null;
                $audioRole = trim((string)$request->post('audio_role', 'main')) ?: 'main';

                $data = [
                    'content_type'   => (string)$request->post('content_type', 'movie'),
                    'content_id'     => (int)$request->post('content_id', 0),
                    'source_mode'    => $resolved['source_mode'],
                    'source_type'    => $resolved['source_type'],
                    'url_or_path'    => $url,
                    'label'          => trim((string)$request->post('label', 'Default')) ?: 'Default',
                    'quality'        => trim((string)$request->post('quality', '')),
                    'mime_type'      => $resolved['mime_type'],
                    'poster'         => trim((string)$request->post('poster', '')),
                    'language_code'  => $langCode,
                    'audio_role'     => $audioRole,
                    'is_default'     => (int)$request->post('is_default', 1),
                    'allow_download' => (string)$request->post('allow_download', 'inherit'),
                    'status'         => (string)$request->post('status', 'active'),
                    'sort_order'     => (int)$request->post('sort_order', 0),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_sources', $data, ['id' => $id]);
                    $sourceId = $id;
                    $_SESSION['flash_success'] = 'Media source updated.';
                } else {
                    $sourceId = (int)$this->db->insert('multimedia_sources', $data);
                    $_SESSION['flash_success'] = 'Media source created.';
                }

                if ($data['source_type'] === 'audio' && $data['is_default'] === 1) {
                    MediaSource::enforceSingleDefaultAudio($data['content_type'], $data['content_id'], $sourceId);
                }

                $retParams = "content_type={$data['content_type']}&content_id={$data['content_id']}";
                return Response::redirect('/admin/page/multimedia-sources?' . $retParams);
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                $ct = (string)$request->post('content_type', 'movie');
                $cid = (int)$request->post('content_id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_sources', ['id' => $id]);
                    $_SESSION['flash_success'] = 'Media source deleted.';
                }
                return Response::redirect("/admin/page/multimedia-sources?content_type={$ct}&content_id={$cid}");
            }
        }

        $contentType = (string)$request->get('content_type', 'movie');
        $contentId = (int)$request->get('content_id', 0);
        $editId = (int)$request->get('edit', 0);
        $editSource = ($editId > 0) ? MediaSource::find($editId) : null;

        $items = MediaSource::all();
        $movies = Movie::all();
        $episodes = Episode::all();
        $songs = Song::all();

        return $this->renderView('sources', [
            'items'       => $items,
            'contentType' => $contentType,
            'contentId'   => $contentId,
            'editSource'  => $editSource,
            'movies'      => $movies,
            'episodes'    => $episodes,
            'songs'       => $songs,
        ]);
    }

    // 12. Subtitles CRUD
    public function subtitles(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $contentType = (string)$request->post('content_type', 'movie');
                $contentId = (int)$request->post('content_id', 0);
                $rawLang = trim((string)$request->post('language_code', $request->post('language', 'en')));
                $langCode = MediaLanguageService::normalizeLanguageCode($rawLang ?: 'en');
                $label = trim((string)$request->post('label', '')) ?: MediaLanguageService::getLanguageLabel($langCode);
                $isDef = (int)$request->post('is_default', 0);
                $isForced = (int)$request->post('is_forced', 0);
                $isSdh = (int)$request->post('is_sdh', 0);

                $data = [
                    'content_type'  => $contentType,
                    'content_id'    => $contentId,
                    'language'      => $langCode,
                    'language_code' => $langCode,
                    'label'         => $label,
                    'file_or_url'   => trim((string)$request->post('file_or_url', '')),
                    'format'        => (string)$request->post('format', 'vtt'),
                    'is_default'    => $isDef,
                    'is_forced'     => $isForced,
                    'is_sdh'        => $isSdh,
                    'sort_order'    => (int)$request->post('sort_order', 0),
                ];

                if ($id > 0) {
                    $this->db->update('multimedia_subtitles', $data, ['id' => $id]);
                    $subId = $id;
                    $_SESSION['flash_success'] = 'Subtitle updated.';
                } else {
                    $subId = (int)$this->db->insert('multimedia_subtitles', $data);
                    $_SESSION['flash_success'] = 'Subtitle created.';
                }

                if ($isDef === 1) {
                    Subtitle::enforceSingleDefault($contentType, $contentId, $subId);
                }

                return Response::redirect('/admin/page/multimedia-subtitles');
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                if ($id > 0) {
                    $this->db->delete('multimedia_subtitles', ['id' => $id]);
                    $_SESSION['flash_success'] = 'Subtitle deleted.';
                }
                return Response::redirect('/admin/page/multimedia-subtitles');
            }
        }

        $items = Subtitle::all();
        $movies = Movie::all();
        $episodes = Episode::all();
        $editId = (int)$request->get('edit', 0);
        $editSubtitle = ($editId > 0) ? Subtitle::find($editId) : null;

        return $this->renderView('subtitles', [
            'items'        => $items,
            'movies'       => $movies,
            'episodes'     => $episodes,
            'editSubtitle' => $editSubtitle,
        ]);
    }

    // 13. Access Control overview
    public function accessRules(Request $request): string
    {
        return $this->renderView('access', [
            'digitalAvailable' => \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::isAvailable(),
            'payAvailable'     => \FavoriteCMS\Multimedia\Integrations\FavoritePayAdapter::isAvailable(),
        ]);
    }

    // 14. Analytics
    public function analytics(Request $request): Response|string
    {
        if (!MultimediaPermission::can(MultimediaPermission::VIEW_ANALYTICS)) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to view multimedia analytics.</p>', 403);
        }

        $range       = (string)$request->get('range', 'last_30_days');
        $customStart = (string)$request->get('start_date', '');
        $customEnd   = (string)$request->get('end_date', '');
        $dateFilter  = MultimediaAnalyticsService::resolveDateRange($range, $customStart, $customEnd);

        // CSV Export Workflow
        if ($request->get('export') === 'csv') {
            $reportType  = (string)$request->get('report', 'overview');
            $contentType = (string)$request->get('content_type', 'movie');
            $csvData     = MultimediaAnalyticsService::exportCsv($reportType, $dateFilter, $contentType);
            $filename    = "multimedia_report_{$reportType}_" . gmdate('Ymd_His') . ".csv";

            return Response::make($csvData, 200, [
                'Content-Type'        => 'text/csv; charset=UTF-8',
                'Content-Disposition' => "attachment; filename=\"{$filename}\"",
                'Cache-Control'       => 'no-store, private',
            ]);
        }

        $tab         = (string)$request->get('tab', 'overview');
        $contentType = (string)$request->get('content_type', 'movie');
        $sortBy      = (string)$request->get('sort', 'plays');
        $sortOrder   = (string)$request->get('order', 'DESC');
        $page        = max(1, (int)$request->get('p', 1));
        $perPage     = 20;
        $offset      = ($page - 1) * $perPage;

        // Data based on selected tab
        $overviewStats    = MultimediaAnalyticsService::getOverviewStats($dateFilter);
        $trends           = [];
        $contentData      = [];
        $dropOff          = [];
        $resumeStats      = [];
        $engagementStats  = [];
        $followerGrowth   = [];
        $notificationData = [];
        $discoveryData    = [];
        $premiumFunnel    = [];
        $languageStats    = [];
        $operationalStats = [];

        if ($tab === 'overview') {
            $trends     = MultimediaAnalyticsService::getPlayTrends($dateFilter);
            $dropOff    = MultimediaAnalyticsService::getCompletionAndDropOff('movie', null, $dateFilter);
            $contentData = MultimediaAnalyticsService::getContentPerformance('movie', $dateFilter, 5, 0, 'plays', 'DESC');
        } elseif ($tab === 'content') {
            $contentData = MultimediaAnalyticsService::getContentPerformance($contentType, $dateFilter, $perPage, $offset, $sortBy, $sortOrder);
            $dropOff     = MultimediaAnalyticsService::getCompletionAndDropOff($contentType, null, $dateFilter);
        } elseif ($tab === 'engagement') {
            $engagementStats  = MultimediaAnalyticsService::getRatingAndReviewAnalytics($dateFilter);
            $followerGrowth   = MultimediaAnalyticsService::getFollowerGrowth($dateFilter);
            $notificationData = MultimediaAnalyticsService::getNotificationAnalytics($dateFilter);
            $resumeStats      = MultimediaAnalyticsService::getResumeEngagement($dateFilter);
        } elseif ($tab === 'funnel') {
            $premiumFunnel = MultimediaAnalyticsService::getPremiumFunnel($dateFilter);
            $languageStats = MultimediaAnalyticsService::getLanguageUsageAnalytics($dateFilter);
            $discoveryData = MultimediaAnalyticsService::getDiscoveryPerformance($dateFilter);
        } elseif ($tab === 'operations') {
            $operationalStats = MultimediaAnalyticsService::getProcessingAndStorageMetrics();
        }

        $recentEvents = $this->db->select("
            SELECT * FROM multimedia_analytics
            WHERE created_at >= ? AND created_at <= ?
            ORDER BY id DESC LIMIT 50
        ", [$dateFilter['start'], $dateFilter['end']]);

        return $this->renderView('analytics', [
            'tab'              => $tab,
            'range'            => $range,
            'dateFilter'       => $dateFilter,
            'contentType'      => $contentType,
            'sortBy'           => $sortBy,
            'sortOrder'        => $sortOrder,
            'page'             => $page,
            'overviewStats'    => $overviewStats,
            'trends'           => $trends,
            'contentData'      => $contentData,
            'dropOff'          => $dropOff,
            'resumeStats'      => $resumeStats,
            'engagementStats'  => $engagementStats,
            'followerGrowth'   => $followerGrowth,
            'notificationData' => $notificationData,
            'discoveryData'    => $discoveryData,
            'premiumFunnel'    => $premiumFunnel,
            'languageStats'    => $languageStats,
            'operationalStats' => $operationalStats,
            'recentEvents'     => $recentEvents,
        ]);
    }

    // 15. Settings
    public function settings(Request $request): Response|string
    {
        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            Setting::set('multimedia', 'enable_downloads', (string)$request->post('enable_downloads', 'yes'));
            Setting::set('multimedia', 'default_video_resolution', (string)$request->post('default_video_resolution', '1080p'));
            Setting::set('multimedia', 'hls_autoplay', (string)$request->post('hls_autoplay', 'no'));
            Setting::set('multimedia', 'player_theme_color', (string)$request->post('player_theme_color', '#2563eb'));
            Setting::set('multimedia', 'enable_discovery', (string)$request->post('enable_discovery', 'yes'));
            Setting::set('multimedia', 'enable_trending', (string)$request->post('enable_trending', 'yes'));
            Setting::set('multimedia', 'trending_window_days', (string)max(1, (int)$request->post('trending_window_days', 7)));
            Setting::set('multimedia', 'max_discovery_items', (string)max(4, (int)$request->post('max_discovery_items', 10)));
            Setting::set('multimedia', 'review_moderation_mode', (string)$request->post('review_moderation_mode', 'auto_approve'));

            $_SESSION['flash_success'] = 'Settings saved successfully.';
            return Response::redirect('/admin/page/multimedia-settings');
        }

        return $this->renderView('settings', [
            'enableDownloads'      => Setting::get('multimedia', 'enable_downloads', 'yes'),
            'resolution'           => Setting::get('multimedia', 'default_video_resolution', '1080p'),
            'themeColor'           => Setting::get('multimedia', 'player_theme_color', '#2563eb'),
            'enableDiscovery'      => Setting::get('multimedia', 'enable_discovery', 'yes'),
            'enableTrending'       => Setting::get('multimedia', 'enable_trending', 'yes'),
            'trendingWindowDays'   => (int)Setting::get('multimedia', 'trending_window_days', 7),
            'maxDiscoveryItems'    => (int)Setting::get('multimedia', 'max_discovery_items', 10),
            'reviewModerationMode' => Setting::get('multimedia', 'review_moderation_mode', 'auto_approve'),
        ]);
    }

    // 16. Community Moderation Queue
    public function moderation(Request $request): Response|string
    {
        $user = current_user();
        if (!$user || !MultimediaEngagementService::canModerate($user)) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to moderate multimedia content.</p>', 403);
        }

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            $action = (string)$request->post('action', '');
            $targetType = (string)$request->post('target_type', '');
            $targetId = (int)$request->post('target_id', 0);

            if ($targetType === 'review' && $targetId > 0) {
                if (in_array($action, ['approve', 'reject', 'hide', 'delete'], true)) {
                    MultimediaEngagementService::moderateReview($user, $targetId, $action);
                    $_SESSION['flash_success'] = "Review successfully actioned ({$action}).";
                }
            } elseif ($targetType === 'comment' && $targetId > 0) {
                if (in_array($action, ['approve', 'reject', 'hide', 'delete'], true)) {
                    MultimediaEngagementService::moderateComment($user, $targetId, $action);
                    $_SESSION['flash_success'] = "Comment successfully actioned ({$action}).";
                }
            } elseif ($targetType === 'report' && $targetId > 0) {
                if (in_array($action, ['dismiss', 'action', 'review'], true)) {
                    MultimediaEngagementService::resolveReport($user, $targetId, $action);
                    $_SESSION['flash_success'] = "Report status updated ({$action}).";
                }
            }

            return Response::redirect('/admin/page/multimedia-moderation');
        }

        $tab = (string)$request->get('tab', 'pending_reviews');
        $page = max(1, (int)$request->get('p', 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $items = [];
        $total = 0;

        if ($tab === 'pending_reviews' && MultimediaEngagementService::hasReviewsTable()) {
            $items = $this->db->select("SELECT * FROM multimedia_reviews WHERE status = 'pending' ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $total = (int)($this->db->selectOne("SELECT COUNT(*) as c FROM multimedia_reviews WHERE status = 'pending'")->c ?? 0);
        } elseif ($tab === 'reported_reviews' && MultimediaEngagementService::hasReportsTable() && MultimediaEngagementService::hasReviewsTable()) {
            $items = $this->db->select("
                SELECT r.*, rep.reason as report_reason, rep.notes as report_notes, rep.id as report_id
                FROM multimedia_reviews r
                JOIN multimedia_reports rep ON rep.target_type = 'review' AND rep.target_id = r.id
                WHERE rep.status = 'open'
                ORDER BY rep.created_at DESC LIMIT {$perPage} OFFSET {$offset}
            ");
            $total = (int)($this->db->selectOne("SELECT COUNT(*) as c FROM multimedia_reports WHERE target_type = 'review' AND status = 'open'")->c ?? 0);
        } elseif ($tab === 'comments' && MultimediaEngagementService::hasCommentsTable()) {
            $items = $this->db->select("SELECT * FROM multimedia_comments ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $total = (int)($this->db->selectOne("SELECT COUNT(*) as c FROM multimedia_comments")->c ?? 0);
        } elseif ($tab === 'reports' && MultimediaEngagementService::hasReportsTable()) {
            $items = $this->db->select("SELECT * FROM multimedia_reports WHERE status = 'open' ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $total = (int)($this->db->selectOne("SELECT COUNT(*) as c FROM multimedia_reports WHERE status = 'open'")->c ?? 0);
        }

        $counts = MultimediaEngagementService::getModerationCounts();

        return $this->renderView('moderation', [
            'tab'        => $tab,
            'items'      => $items,
            'total'      => $total,
            'page'       => $page,
            'totalPages' => max(1, (int)ceil($total / $perPage)),
            'counts'     => $counts,
        ]);
    }

    // 17. Releases & Editorial Calendar
    public function releases(Request $request): Response|string
    {
        $user = current_user();
        if ($request->method() === 'POST') {
            if (!MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
                return Response::make('<h1>403 Forbidden</h1>', 403);
            }
            $this->validateCsrf($request);
            $action = (string)$request->post('action', '');

            if ($action === 'publish_now') {
                $type = (string)$request->post('content_type', '');
                $id = (int)$request->post('content_id', 0);
                $res = MultimediaReleaseService::publishNow($type, $id, $user);
                if ($res['success']) {
                    $_SESSION['flash_success'] = "Content successfully published now.";
                } else {
                    $_SESSION['flash_error'] = "Publish failed: " . ($res['error'] ?? 'Unknown error');
                }
                return Response::redirect('/admin/page/multimedia-releases');
            }

            if ($action === 'schedule') {
                $type = (string)$request->post('content_type', '');
                $id = (int)$request->post('content_id', 0);
                $publishAtLocal = (string)$request->post('publish_at', '');
                $unpublishAtLocal = (string)$request->post('unpublish_at', '');
                $publishAtUtc = MultimediaReleaseService::localToUtc($publishAtLocal) ?? $publishAtLocal;
                $unpublishAtUtc = $unpublishAtLocal !== '' ? (MultimediaReleaseService::localToUtc($unpublishAtLocal) ?? $unpublishAtLocal) : null;

                $res = MultimediaReleaseService::scheduleItem($type, $id, $publishAtUtc, $unpublishAtUtc, $user);
                if ($res['success']) {
                    $_SESSION['flash_success'] = "Content successfully scheduled for release.";
                } else {
                    $_SESSION['flash_error'] = "Scheduling failed: " . ($res['error'] ?? 'Unknown error');
                }
                return Response::redirect('/admin/page/multimedia-releases');
            }

            if ($action === 'cancel') {
                $type = (string)$request->post('content_type', '');
                $id = (int)$request->post('content_id', 0);
                $res = MultimediaReleaseService::cancelSchedule($type, $id, $user);
                if ($res['success']) {
                    $_SESSION['flash_success'] = "Schedule cancelled; content reverted to draft.";
                } else {
                    $_SESSION['flash_error'] = "Cancel failed: " . ($res['error'] ?? 'Unknown error');
                }
                return Response::redirect('/admin/page/multimedia-releases');
            }

            if ($action === 'run_due') {
                $res = MultimediaReleaseService::processDueReleases();
                $_SESSION['flash_success'] = sprintf(
                    "Due release processor executed: %d items published, %d unpublished, %d errors.",
                    $res['published'] ?? 0,
                    $res['unpublished'] ?? 0,
                    count($res['errors'] ?? [])
                );
                return Response::redirect('/admin/page/multimedia-releases');
            }
        }

        $typeFilter = (string)$request->get('type', '');
        $statusFilter = (string)$request->get('status', '');
        $month = (string)$request->get('month', date('Y-m'));

        $filters = [];
        if ($typeFilter !== '' && $typeFilter !== 'all') {
            $filters['content_type'] = $typeFilter;
        }
        if ($statusFilter !== '' && $statusFilter !== 'all') {
            $filters['status'] = $statusFilter;
        }

        $metrics = MultimediaReleaseService::getOperationalMetrics();
        $queue = MultimediaReleaseService::getScheduledQueue($filters);

        // Calculate start and end UTC for selected calendar month
        $startLocal = $month . '-01 00:00:00';
        $endLocal = date('Y-m-t 23:59:59', strtotime($startLocal));
        $startUtc = MultimediaReleaseService::localToUtc($startLocal) ?? $startLocal;
        $endUtc = MultimediaReleaseService::localToUtc($endLocal) ?? $endLocal;

        $calendarEvents = MultimediaReleaseService::getCalendarReleases($startUtc, $endUtc, $filters);
        $timezone = MultimediaReleaseService::getAppTimezone();

        return $this->renderView('releases', [
            'metrics'        => $metrics,
            'queue'          => $queue,
            'calendarEvents' => $calendarEvents,
            'month'          => $month,
            'typeFilter'     => $typeFilter,
            'statusFilter'   => $statusFilter,
            'timezone'       => $timezone,
        ]);
    }

    // Release API Handlers
    public function apiPublishNow(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $type = (string)($data['content_type'] ?? '');
        $id = (int)($data['content_id'] ?? 0);

        $res = MultimediaReleaseService::publishNow($type, $id, $user);
        return Response::json($res, $res['success'] ? 200 : 400);
    }

    public function apiScheduleRelease(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $type = (string)($data['content_type'] ?? '');
        $id = (int)($data['content_id'] ?? 0);
        $publishAtLocal = trim((string)($data['publish_at'] ?? ''));
        $unpublishAtLocal = trim((string)($data['unpublish_at'] ?? ''));

        $publishAtUtc = MultimediaReleaseService::localToUtc($publishAtLocal) ?? $publishAtLocal;
        $unpublishAtUtc = $unpublishAtLocal !== '' ? (MultimediaReleaseService::localToUtc($unpublishAtLocal) ?? $unpublishAtLocal) : null;

        $res = MultimediaReleaseService::scheduleItem($type, $id, $publishAtUtc, $unpublishAtUtc, $user);
        return Response::json($res, $res['success'] ? 200 : 400);
    }

    public function apiCancelSchedule(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $type = (string)($data['content_type'] ?? '');
        $id = (int)($data['content_id'] ?? 0);

        $res = MultimediaReleaseService::cancelSchedule($type, $id, $user);
        return Response::json($res, $res['success'] ? 200 : 400);
    }

    public function apiRunDueReleases(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $limit = max(1, min(500, (int)($data['limit'] ?? $request->get('limit', 100))));
        $res = MultimediaReleaseService::processDueReleases($limit);
        return Response::json(['success' => true, 'summary' => $res]);
    }

    public function apiGetCalendar(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::VIEW, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $start = (string)$request->get('start', date('Y-m-01 00:00:00'));
        $end = (string)$request->get('end', date('Y-m-t 23:59:59'));
        $startUtc = MultimediaReleaseService::localToUtc($start) ?? $start;
        $endUtc = MultimediaReleaseService::localToUtc($end) ?? $end;

        $filters = [];
        if ($request->get('type')) {
            $filters['content_type'] = (string)$request->get('type');
        }
        if ($request->get('status')) {
            $filters['status'] = (string)$request->get('status');
        }

        $events = MultimediaReleaseService::getCalendarReleases($startUtc, $endUtc, $filters);
        return Response::json(['success' => true, 'events' => $events]);
    }

    public function apiGetQueue(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::VIEW, $user)) {
            return Response::json(['success' => false, 'error' => 'Permission denied.'], 403);
        }

        $filters = [];
        if ($request->get('type')) {
            $filters['content_type'] = (string)$request->get('type');
        }
        if ($request->get('status')) {
            $filters['status'] = (string)$request->get('status');
        }

        $queue = MultimediaReleaseService::getScheduledQueue($filters);
        return Response::json(['success' => true, 'queue' => $queue]);
    }

    private function resolvePublishingFields(Request $request, string $table, int $id): array
    {
        $status = (string)$request->post('status', 'published');
        if (!in_array($status, ['draft', 'scheduled', 'published', 'unpublished'], true)) {
            $status = 'published';
        }

        $publishAtRaw = trim((string)$request->post('publish_at', ''));
        $unpublishAtRaw = trim((string)$request->post('unpublish_at', ''));
        $publishAtUtc = $publishAtRaw !== '' ? MultimediaReleaseService::localToUtc($publishAtRaw) : null;
        $unpublishAtUtc = $unpublishAtRaw !== '' ? MultimediaReleaseService::localToUtc($unpublishAtRaw) : null;

        $publishedAt = null;
        if ($status === 'published') {
            if ($id > 0) {
                $existing = $this->db->selectOne("SELECT published_at FROM {$table} WHERE id = ?", [$id]);
                $publishedAt = ($existing && !empty($existing->published_at)) ? $existing->published_at : gmdate('Y-m-d H:i:s');
            } else {
                $publishedAt = gmdate('Y-m-d H:i:s');
            }
        }

        return [
            'status'       => $status,
            'publish_at'   => $publishAtUtc,
            'published_at' => $publishedAt,
            'unpublish_at' => $unpublishAtUtc,
        ];
    }

    public function processing(Request $request): string
    {
        if ($request->isPost()) {
            $this->validateCsrf($request);
            $action = (string)$request->post('action', '');

            if ($action === 'run_queue') {
                MediaProcessingService::processQueue(10);
                return (string)Response::redirect('/admin/page/multimedia-processing');
            } elseif ($action === 'retry_job') {
                $jobId = (int)$request->post('job_id', 0);
                MediaProcessingService::retryJob($jobId);
                return (string)Response::redirect('/admin/page/multimedia-processing');
            } elseif ($action === 'cancel_job') {
                $jobId = (int)$request->post('job_id', 0);
                MediaProcessingService::cancelJob($jobId);
                return (string)Response::redirect('/admin/page/multimedia-processing');
            }
        }

        $capabilities = FFmpegService::getCapabilities();
        $jobs = MediaProcessingJob::getRecent(50);
        $statusCounts = MediaProcessingJob::countByStatus();

        return $this->renderView('processing', [
            'ffmpegCapabilities' => $capabilities,
            'jobs'               => $jobs,
            'statusCounts'       => $statusCounts,
        ]);
    }

    public function apiDispatchProcessingJob(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SOURCES, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $contentType = (string)($data['content_type'] ?? '');
        $contentId = (int)($data['content_id'] ?? 0);
        $inputPath = (string)($data['input_path'] ?? '');
        $jobType = (string)($data['job_type'] ?? MediaProcessingJob::TYPE_FULL_PIPELINE);
        $settings = (array)($data['settings'] ?? []);
        $sourceId = isset($data['source_id']) ? (int)$data['source_id'] : null;

        $job = MediaProcessingService::dispatchJob($contentType, $contentId, $inputPath, $jobType, $settings, $sourceId);
        if (!$job) {
            return Response::json(['success' => false, 'error' => 'Failed to dispatch processing job.'], 400);
        }

        return Response::json(['success' => true, 'job' => $job]);
    }

    public function apiRetryProcessingJob(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SOURCES, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $jobId = (int)($data['job_id'] ?? 0);
        $res = MediaProcessingService::retryJob($jobId);
        $code = $res['success'] ? 200 : 400;
        return Response::json($res, $code);
    }

    public function apiCancelProcessingJob(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SOURCES, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $jobId = (int)($data['job_id'] ?? 0);
        $res = MediaProcessingService::cancelJob($jobId);
        $code = $res['success'] ? 200 : 400;
        return Response::json($res, $code);
    }

    public function apiRunProcessingQueue(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SOURCES, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $limit = (int)($data['limit'] ?? 5);
        $res = MediaProcessingService::processQueue($limit);
        return Response::json($res);
    }

    public function apiGetProcessingStatus(Request $request): Response
    {
        $capabilities = FFmpegService::getCapabilities();
        $statusCounts = MediaProcessingJob::countByStatus();
        return Response::json([
            'capabilities' => $capabilities,
            'counts'       => $statusCounts,
        ]);
    }

    // 17. Storage & CDN
    public function storage(Request $request): Response|string
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::make('<h1>403 Forbidden</h1><p>You do not have permission to manage storage settings.</p>', 403);
        }

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);
            $driver    = (string)$request->post('multimedia_storage_driver', 'local');
            $endpoint  = trim((string)$request->post('multimedia_s3_endpoint', ''));
            $region    = trim((string)$request->post('multimedia_s3_region', 'us-east-1'));
            $bucket    = trim((string)$request->post('multimedia_s3_bucket', ''));
            $accessKey = trim((string)$request->post('multimedia_s3_access_key', ''));
            $secretKey = trim((string)$request->post('multimedia_s3_secret_key', ''));
            $prefix    = trim((string)$request->post('multimedia_s3_path_prefix', 'multimedia'));
            $cdnUrl    = trim((string)$request->post('multimedia_cdn_base_url', ''));
            $ttl       = (int)$request->post('multimedia_signed_url_ttl', 300);

            if ($driver === 's3' && !empty($endpoint)) {
                $check = MediaStorageManager::validateEndpointSecurity($endpoint);
                if (!$check['valid']) {
                    $_SESSION['flash_error'] = "Invalid S3 Endpoint: " . $check['reason'];
                    return Response::redirect('/admin/page/multimedia-storage');
                }
            }

            Setting::set('multimedia', 'storage_driver', $driver);
            Setting::set('multimedia', 's3_endpoint', $endpoint);
            Setting::set('multimedia', 's3_region', $region);
            Setting::set('multimedia', 's3_bucket', $bucket);
            Setting::set('multimedia', 's3_access_key', $accessKey);
            if ($secretKey !== '') {
                Setting::set('multimedia', 's3_secret_key', $secretKey);
            }
            Setting::set('multimedia', 's3_path_prefix', $prefix);
            Setting::set('multimedia', 'cdn_base_url', $cdnUrl);
            Setting::set('multimedia', 'signed_url_ttl', (string)$ttl);

            MediaStorageManager::resetInstances();
            $_SESSION['flash_success'] = 'Storage configuration updated successfully.';
            return Response::redirect('/admin/page/multimedia-storage');
        }

        $settings = [
            'multimedia_storage_driver' => Setting::get('multimedia', 'storage_driver', 'local'),
            'multimedia_s3_endpoint'   => Setting::get('multimedia', 's3_endpoint', 'https://s3.amazonaws.com'),
            'multimedia_s3_region'     => Setting::get('multimedia', 's3_region', 'us-east-1'),
            'multimedia_s3_bucket'     => Setting::get('multimedia', 's3_bucket', ''),
            'multimedia_s3_access_key' => Setting::get('multimedia', 's3_access_key', ''),
            'multimedia_s3_secret_key' => Setting::get('multimedia', 's3_secret_key', ''),
            'multimedia_s3_path_prefix'=> Setting::get('multimedia', 's3_path_prefix', 'multimedia'),
            'multimedia_cdn_base_url'  => Setting::get('multimedia', 'cdn_base_url', ''),
            'multimedia_signed_url_ttl'=> (int)Setting::get('multimedia', 'signed_url_ttl', 300),
        ];

        $stats = MediaStorageService::getStorageUsageSummary();

        return $this->renderView('storage', [
            'settings' => $settings,
            'stats'    => $stats,
        ]);
    }

    public function apiSaveStorageSettings(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $driver = (string)($data['multimedia_storage_driver'] ?? 'local');
        $endpoint = trim((string)($data['multimedia_s3_endpoint'] ?? ''));

        if ($driver === 's3' && !empty($endpoint)) {
            $check = MediaStorageManager::validateEndpointSecurity($endpoint);
            if (!$check['valid']) {
                return Response::json(['success' => false, 'error' => $check['reason']], 400);
            }
        }

        Setting::set('multimedia', 'storage_driver', $driver);
        Setting::set('multimedia', 's3_endpoint', $endpoint);
        Setting::set('multimedia', 's3_region', (string)($data['multimedia_s3_region'] ?? 'us-east-1'));
        Setting::set('multimedia', 's3_bucket', (string)($data['multimedia_s3_bucket'] ?? ''));
        Setting::set('multimedia', 's3_access_key', (string)($data['multimedia_s3_access_key'] ?? ''));

        $secret = trim((string)($data['multimedia_s3_secret_key'] ?? ''));
        if ($secret !== '') {
            Setting::set('multimedia', 's3_secret_key', $secret);
        }

        Setting::set('multimedia', 's3_path_prefix', (string)($data['multimedia_s3_path_prefix'] ?? 'multimedia'));
        Setting::set('multimedia', 'cdn_base_url', (string)($data['multimedia_cdn_base_url'] ?? ''));
        Setting::set('multimedia', 'signed_url_ttl', (string)($data['multimedia_signed_url_ttl'] ?? 300));

        MediaStorageManager::resetInstances();
        return Response::json(['success' => true, 'message' => 'Settings updated successfully.']);
    }

    public function apiTestStorageConnection(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $driver = (string)Setting::get('multimedia_storage_driver', 'local');
        $disk = MediaStorageManager::getDisk($driver);
        $res = $disk->testConnection();

        return Response::json($res);
    }

    public function apiMigrateStorage(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $sourceId = (int)($data['source_id'] ?? 0);
        $deleteLocal = (bool)($data['delete_local'] ?? false);

        if ($sourceId > 0) {
            $source = MediaSource::find($sourceId);
            if (!$source) {
                return Response::json(['success' => false, 'error' => 'Source not found.'], 404);
            }
            $res = MediaStorageService::migrateSourceToRemote($source, $deleteLocal);
            return Response::json($res);
        }

        // Batch migration of up to 10 un-migrated local sources
        $sources = $this->db->select("SELECT id FROM multimedia_sources WHERE (storage_driver IS NULL OR storage_driver = 'local') AND is_migrated = 0 LIMIT 10");
        $migrated = 0;
        foreach ($sources as $s) {
            $src = MediaSource::find((int)$s->id);
            if ($src) {
                $mRes = MediaStorageService::migrateSourceToRemote($src, $deleteLocal);
                if ($mRes['success'] ?? false) {
                    $migrated++;
                }
            }
        }

        return Response::json(['success' => true, 'migrated' => $migrated]);
    }

    public function apiCleanupOrphans(Request $request): Response
    {
        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $dryRun = (bool)($data['dry_run'] ?? true);
        $limit = (int)($data['limit'] ?? 100);

        $res = MediaStorageService::cleanupOrphans($dryRun, $limit);
        return Response::json($res);
    }

    public function apiGetStorageStats(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::MANAGE_SETTINGS, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $summary = MediaStorageService::getStorageUsageSummary();
        return Response::json($summary);
    }

    // 19. Localizations CRUD
    public function localizations(Request $request): Response|string
    {
        $action = (string)$request->post('action', $request->get('action', 'index'));

        if ($request->method() === 'POST') {
            $this->validateCsrf($request);

            if ($action === 'create' || $action === 'edit') {
                $id = (int)$request->post('id', 0);
                $contentType = (string)$request->post('content_type', 'movie');
                $contentId = (int)$request->post('content_id', 0);
                $rawLang = trim((string)$request->post('language_code', ''));
                $langCode = MediaLanguageService::normalizeLanguageCode($rawLang);
                $title = trim((string)$request->post('title', ''));
                $desc = trim((string)$request->post('description', ''));
                $tagline = trim((string)$request->post('tagline', ''));

                if (!MediaLanguageService::isValidCode($langCode)) {
                    $_SESSION['flash_error'] = 'Invalid BCP 47 language code: ' . htmlspecialchars($rawLang, ENT_QUOTES, 'UTF-8');
                } elseif (empty($title)) {
                    $_SESSION['flash_error'] = 'Title is required for localization.';
                } else {
                    MediaLocalization::saveLocalization($contentType, $contentId, $langCode, $title, $desc, $tagline);
                    $_SESSION['flash_success'] = "Localization saved for [{$langCode}].";
                }

                $retParams = "content_type={$contentType}&content_id={$contentId}";
                return Response::redirect('/admin/page/multimedia-localizations?' . $retParams);
            }

            if ($action === 'delete') {
                $id = (int)$request->post('id', 0);
                $ct = (string)$request->post('content_type', 'movie');
                $cid = (int)$request->post('content_id', 0);
                $lang = (string)$request->post('language_code', '');

                if ($id > 0) {
                    $this->db->delete('multimedia_localizations', ['id' => $id]);
                    $_SESSION['flash_success'] = 'Localization deleted.';
                } elseif ($cid > 0 && !empty($lang)) {
                    MediaLocalization::deleteLocalization($ct, $cid, $lang);
                    $_SESSION['flash_success'] = 'Localization deleted.';
                }

                return Response::redirect("/admin/page/multimedia-localizations?content_type={$ct}&content_id={$cid}");
            }
        }

        $contentType = (string)$request->get('content_type', '');
        $contentId = (int)$request->get('content_id', 0);
        $editId = (int)$request->get('edit', 0);
        $editLocalization = ($editId > 0) ? MediaLocalization::find($editId) : null;

        $items = (!empty($contentType) && $contentId > 0)
            ? MediaLocalization::getForContent($contentType, $contentId)
            : MediaLocalization::all();

        $movies = Movie::all();
        $series = Series::all();
        $episodes = Episode::all();
        $songs = Song::all();
        $languages = MediaLanguageService::getSupportedLanguages();

        return $this->renderView('localizations', [
            'items'            => $items,
            'contentType'      => $contentType,
            'contentId'        => $contentId,
            'editLocalization' => $editLocalization,
            'movies'           => $movies,
            'series'           => $series,
            'episodes'         => $episodes,
            'songs'            => $songs,
            'languages'        => $languages,
        ]);
    }

    public function apiSaveLocalization(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::EDIT, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $contentType = (string)($data['content_type'] ?? 'movie');
        $contentId = (int)($data['content_id'] ?? 0);
        $rawLang = trim((string)($data['language_code'] ?? ''));
        $langCode = MediaLanguageService::normalizeLanguageCode($rawLang);
        $title = trim((string)($data['title'] ?? ''));
        $desc = trim((string)($data['description'] ?? ''));
        $tagline = trim((string)($data['tagline'] ?? ''));

        if (!MediaLanguageService::isValidCode($langCode)) {
            return Response::json(['success' => false, 'error' => 'Invalid language code.'], 422);
        }
        if (empty($title)) {
            return Response::json(['success' => false, 'error' => 'Title is required.'], 422);
        }

        $saved = MediaLocalization::saveLocalization($contentType, $contentId, $langCode, $title, $desc, $tagline);

        return Response::json([
            'success'      => true,
            'localization' => $saved->toArray(),
        ]);
    }

    public function apiDeleteLocalization(Request $request): Response
    {
        $user = current_user();
        if (!$user || !MultimediaPermission::can(MultimediaPermission::DELETE, $user)) {
            return Response::json(['success' => false, 'error' => 'Unauthorized.'], 403);
        }

        $raw = @file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
        $data = is_array($json) ? array_merge($request->all(), $json) : $request->all();

        if (!$this->validateApiCsrf($request, $data)) {
            return Response::json(['success' => false, 'error' => 'Invalid CSRF token.'], 403);
        }

        $contentType = (string)($data['content_type'] ?? '');
        $contentId = (int)($data['content_id'] ?? 0);
        $langCode = trim((string)($data['language_code'] ?? ''));

        if (!empty($contentType) && $contentId > 0 && !empty($langCode)) {
            MediaLocalization::deleteLocalization($contentType, $contentId, $langCode);
            return Response::json(['success' => true]);
        }

        return Response::json(['success' => false, 'error' => 'Missing parameters.'], 400);
    }

    public function apiGetLocalizations(Request $request): Response
    {
        $contentType = (string)$request->get('content_type', '');
        $contentId = (int)$request->get('content_id', 0);

        if (empty($contentType) || $contentId <= 0) {
            return Response::json(['success' => false, 'error' => 'content_type and content_id required.'], 400);
        }

        $locs = MediaLocalization::getForContent($contentType, $contentId);
        $data = array_map(fn($l) => $l->toArray(), $locs);

        return Response::json(['success' => true, 'localizations' => $data]);
    }

    private function renderView(string $viewName, array $data = []): string
    {
        $viewPath = __DIR__ . '/../../views/admin/' . $viewName . '.php';
        if (!file_exists($viewPath)) {
            return "<div class='notice notice-error'>View not found: " . htmlspecialchars($viewName, ENT_QUOTES, 'UTF-8') . "</div>";
        }

        extract($data, EXTR_SKIP);
        ob_start();
        include $viewPath;
        return (string)ob_get_clean();
    }

    private function validateCsrf(Request $request): void
    {
        $token = (string)$request->post('_token', '');
        $sessionToken = (string)($_SESSION['_token'] ?? $_SESSION['csrf_token'] ?? '');
        if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
            http_response_code(403);
            echo "Invalid CSRF Token.";
            exit;
        }
    }

    private function validateApiCsrf(Request $request, array $data): bool
    {
        $token = (string)($data['_token'] ?? $data['csrf_token'] ?? $request->header('X-CSRF-TOKEN') ?? $request->header('X-XSRF-TOKEN') ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        $sessionToken = (string)($_SESSION['csrf_token'] ?? $_SESSION['_token'] ?? '');
        if ($sessionToken !== '') {
            return ($token !== '' && hash_equals($sessionToken, $token));
        }
        return true;
    }
}


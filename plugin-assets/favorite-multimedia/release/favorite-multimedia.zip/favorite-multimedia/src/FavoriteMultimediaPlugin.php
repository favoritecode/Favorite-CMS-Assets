<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia;

use FavoriteCMS\Core\AdminMenu;
use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Core\Migrator;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Router;
use FavoriteCMS\Multimedia\Controllers\MediaPlaybackController;
use FavoriteCMS\Multimedia\Controllers\MultimediaAdminController;
use FavoriteCMS\Multimedia\Controllers\MultimediaFrontendController;
use FavoriteCMS\Multimedia\Permissions\MultimediaPermission;

final class FavoriteMultimediaPlugin
{
    public const TABLES = [
        'multimedia_genres',
        'multimedia_artists',
        'multimedia_albums',
        'multimedia_movies',
        'multimedia_series',
        'multimedia_seasons',
        'multimedia_episodes',
        'multimedia_songs',
        'multimedia_playlists',
        'multimedia_playlist_items',
        'multimedia_content_genres',
        'multimedia_sources',
        'multimedia_subtitles',
        'multimedia_analytics',
        'multimedia_playback_progress',
        'multimedia_favorites',
        'multimedia_ratings',
        'multimedia_reviews',
        'multimedia_review_helpful',
        'multimedia_comments',
        'multimedia_reports',
        'multimedia_subscriptions',
        'multimedia_notifications',
        'multimedia_notification_preferences',
        'multimedia_processing_jobs',
        'multimedia_storage_files',
        'multimedia_localizations',
        'multimedia_user_language_preferences',
    ];

    private static ?self $instance = null;
    private static bool $routesRegistered = false;
    private Application $app;
    private bool $booted = false;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public static function getInstance(?Application $app = null): ?self
    {
        if (self::$instance === null && $app !== null) {
            self::$instance = new self($app);
        }
        return self::$instance;
    }

    public static function reset(): void
    {
        self::$instance = null;
        self::$routesRegistered = false;
    }

    public static function bootstrap(Application $app): self
    {
        if (self::$instance !== null && self::$instance->booted) {
            return self::$instance;
        }

        $plugin = new self($app);
        $plugin->register();
        $plugin->boot();
        self::$instance = $plugin;
        return $plugin;
    }

    public function register(): void
    {
        // 1. Register prefixable tables with Database
        if ($this->app->has(Database::class)) {
            $db = $this->app->make(Database::class);
            if (method_exists($db, 'registerPrefixableTables')) {
                $db->registerPrefixableTables(self::TABLES);
            }
        }

        // 2. Bind Controllers
        $this->app->singleton(MultimediaAdminController::class, function ($app) {
            return new MultimediaAdminController($app);
        });

        $this->app->singleton(MultimediaFrontendController::class, function ($app) {
            return new MultimediaFrontendController($app);
        });

        $this->app->singleton(MediaPlaybackController::class, function ($app) {
            return new MediaPlaybackController($app);
        });
    }

    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        // Register Admin Navigation
        $this->registerAdminMenus();

        // Register Dynamic Frontend and Player Routes
        $this->registerRoutes();

        // Hook lifecycle actions
        if (function_exists('add_action')) {
            add_action('plugin.activated', function (string $pluginId): void {
                if ($pluginId === 'favorite-multimedia') {
                    $this->onActivate();
                }
            });

            add_action('plugin.deactivated', function (string $pluginId): void {
                if ($pluginId === 'favorite-multimedia') {
                    $this->onDeactivate();
                }
            });

            add_action('multimedia_process_due_releases', function (int $limit = 100): array {
                return \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::processDueReleases($limit);
            });

            add_action('multimedia_process_media_queue', function (int $limit = 5): array {
                return \FavoriteCMS\Multimedia\Services\MediaProcessingService::processQueue($limit);
            });
        }

        if (class_exists(\FavoriteCMS\Core\Hook::class)) {
            \FavoriteCMS\Core\Hook::addAction('plugin.activated', function (string $pluginId): void {
                if ($pluginId === 'favorite-multimedia') {
                    $this->onActivate();
                }
            });

            \FavoriteCMS\Core\Hook::addAction('plugin.deactivated', function (string $pluginId): void {
                if ($pluginId === 'favorite-multimedia') {
                    $this->onDeactivate();
                }
            });

            \FavoriteCMS\Core\Hook::addAction('multimedia_process_due_releases', function (int $limit = 100): array {
                return \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::processDueReleases($limit);
            });

            \FavoriteCMS\Core\Hook::addAction('multimedia_process_media_queue', function (int $limit = 5): array {
                return \FavoriteCMS\Multimedia\Services\MediaProcessingService::processQueue($limit);
            });
        }

        // Register default permissions if DB is ready
        if ($this->app->has(Database::class)) {
            try {
                MultimediaPermission::registerDefaultPermissions($this->app->make(Database::class));
            } catch (\Throwable) {
                // Table might not be migrated yet
            }
        }

        $this->booted = true;
    }

    public function onActivate(): void
    {
        try {
            $this->runMigrations();
        } catch (\Throwable $e) {
            if (function_exists('cms_log')) {
                cms_log("Favorite Multimedia migration failed: " . $e->getMessage(), 'error', ['plugin' => 'favorite-multimedia']);
            }
        }

        if ($this->app->has(Database::class)) {
            try {
                MultimediaPermission::registerDefaultPermissions($this->app->make(Database::class));
            } catch (\Throwable) {
            }
        }

        if (function_exists('cms_log')) {
            cms_log('Favorite Multimedia plugin activated.', 'info', ['plugin' => 'favorite-multimedia']);
        }
    }

    public function onDeactivate(): void
    {
        if (function_exists('cms_log')) {
            cms_log('Favorite Multimedia plugin deactivated.', 'info', ['plugin' => 'favorite-multimedia']);
        }
    }

    public function runMigrations(): array
    {
        if (!$this->app->has(Database::class)) {
            return [];
        }

        $db = $this->app->make(Database::class);
        if (method_exists($db, 'registerPrefixableTables')) {
            $db->registerPrefixableTables(self::TABLES);
        }

        $migrator = new Migrator($db);
        $migrationsPath = __DIR__ . '/../database/migrations';
        return $migrator->migrate($migrationsPath);
    }

    private function registerAdminMenus(): void
    {
        if (!function_exists('add_admin_menu')) {
            return;
        }

        $adminCtrl = $this->app->make(MultimediaAdminController::class);

        // Top level: Multimedia
        add_admin_menu(
            'multimedia',
            'Multimedia',
            '🎬',
            fn(Request $req) => $adminCtrl->handle($req, 'dashboard'),
            MultimediaPermission::VIEW,
            52
        );

        if (function_exists('add_admin_submenu')) {
            add_admin_submenu('multimedia', 'multimedia', 'Dashboard', fn(Request $r) => $adminCtrl->handle($r, 'dashboard'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-movies', 'Movies', fn(Request $r) => $adminCtrl->handle($r, 'movies'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-series', 'Web Series', fn(Request $r) => $adminCtrl->handle($r, 'series'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-seasons', 'Seasons', fn(Request $r) => $adminCtrl->handle($r, 'seasons'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-episodes', 'Episodes', fn(Request $r) => $adminCtrl->handle($r, 'episodes'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-songs', 'Songs', fn(Request $r) => $adminCtrl->handle($r, 'songs'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-playlists', 'Playlists', fn(Request $r) => $adminCtrl->handle($r, 'playlists'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-genres', 'Genres', fn(Request $r) => $adminCtrl->handle($r, 'genres'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-artists', 'Artists', fn(Request $r) => $adminCtrl->handle($r, 'artists'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-albums', 'Albums', fn(Request $r) => $adminCtrl->handle($r, 'albums'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-sources', 'Media Sources', fn(Request $r) => $adminCtrl->handle($r, 'sources'), MultimediaPermission::MANAGE_SOURCES);
            add_admin_submenu('multimedia', 'multimedia-subtitles', 'Subtitles', fn(Request $r) => $adminCtrl->handle($r, 'subtitles'), MultimediaPermission::MANAGE_SUBTITLES);
            add_admin_submenu('multimedia', 'multimedia-access', 'Access Control', fn(Request $r) => $adminCtrl->handle($r, 'access'), MultimediaPermission::MANAGE_ACCESS);
            add_admin_submenu('multimedia', 'multimedia-analytics', 'Analytics', fn(Request $r) => $adminCtrl->handle($r, 'analytics'), MultimediaPermission::VIEW_ANALYTICS);
            add_admin_submenu('multimedia', 'multimedia-settings', 'Settings', fn(Request $r) => $adminCtrl->handle($r, 'settings'), MultimediaPermission::MANAGE_SETTINGS);
            add_admin_submenu('multimedia', 'multimedia-moderation', 'Moderation', fn(Request $r) => $adminCtrl->handle($r, 'moderation'), MultimediaPermission::MODERATE);
            add_admin_submenu('multimedia', 'multimedia-releases', 'Release Calendar', fn(Request $r) => $adminCtrl->handle($r, 'releases'), MultimediaPermission::VIEW);
            add_admin_submenu('multimedia', 'multimedia-processing', 'Media Processing', fn(Request $r) => $adminCtrl->handle($r, 'processing'), MultimediaPermission::MANAGE_SOURCES);
            add_admin_submenu('multimedia', 'multimedia-storage', 'Storage & CDN', fn(Request $r) => $adminCtrl->handle($r, 'storage'), MultimediaPermission::MANAGE_SETTINGS);
            add_admin_submenu('multimedia', 'multimedia-localizations', 'Localizations', fn(Request $r) => $adminCtrl->handle($r, 'localizations'), MultimediaPermission::MANAGE_SETTINGS);
        }
    }

    private function registerRoutes(): void
    {
        foreach (Router::getRoutes() as $existing) {
            if ($existing['path'] === '/multimedia') {
                self::$routesRegistered = true;
                return;
            }
        }

        $frontendCtrl = $this->app->make(MultimediaFrontendController::class);
        $playbackCtrl = $this->app->make(MediaPlaybackController::class);

        // Public Catalog routes
        Router::get('/multimedia', fn(Request $r) => $frontendCtrl->hub($r));
        Router::get('/multimedia/search', fn(Request $r) => $frontendCtrl->search($r));

        Router::get('/movies', fn(Request $r) => $frontendCtrl->movies($r));
        Router::get('/movie/{slug}', fn(Request $r, string $slug) => $frontendCtrl->movie($r, $slug));

        Router::get('/series', fn(Request $r) => $frontendCtrl->series($r));
        Router::get('/series/{slug}', fn(Request $r, string $slug) => $frontendCtrl->seriesSingle($r, $slug));
        Router::get('/episode/{slug}', fn(Request $r, string $slug) => $frontendCtrl->episode($r, $slug));

        Router::get('/songs', fn(Request $r) => $frontendCtrl->songs($r));
        Router::get('/song/{slug}', fn(Request $r, string $slug) => $frontendCtrl->song($r, $slug));

        Router::get('/playlists', fn(Request $r) => $frontendCtrl->playlists($r));
        Router::get('/playlist/{slug}', fn(Request $r, string $slug) => $frontendCtrl->playlist($r, $slug));

        // Personal Library & User Progress routes
        Router::get('/multimedia/library', fn(Request $r) => $frontendCtrl->library($r));
        Router::get('/multimedia/history', fn(Request $r) => $frontendCtrl->history($r));
        Router::get('/multimedia/my-list', fn(Request $r) => $frontendCtrl->myList($r));

        // Discovery & Taxonomy routes
        Router::get('/multimedia/discover', fn(Request $r) => $frontendCtrl->discover($r));
        Router::get('/multimedia/genre/{slug}', fn(Request $r, string $slug) => $frontendCtrl->genre($r, $slug));
        Router::get('/multimedia/artist/{slug}', fn(Request $r, string $slug) => $frontendCtrl->artist($r, $slug));
        Router::get('/multimedia/album/{slug}', fn(Request $r, string $slug) => $frontendCtrl->album($r, $slug));

        Router::get('/multimedia/play/{id}', fn(Request $r, string $id) => $playbackCtrl->player($r, $id));
        Router::get('/multimedia/stream/{id}', fn(Request $r, string $id) => $playbackCtrl->stream($r, $id));
        Router::get('/multimedia/download/{id}', fn(Request $r, string $id) => $playbackCtrl->download($r, $id));
        Router::get('/multimedia/subtitle/{id}', fn(Request $r, string $id) => $playbackCtrl->subtitle($r, $id));
        Router::get('/api/multimedia/subtitles/{id}', fn(Request $r, string $id) => $playbackCtrl->subtitle($r, $id));

        // API routes
        Router::get('/multimedia/api/detect', fn(Request $r) => $playbackCtrl->apiDetect($r));
        Router::get('/multimedia/api/progress', fn(Request $r) => $playbackCtrl->apiGetProgress($r));
        Router::post('/multimedia/api/progress', fn(Request $r) => $playbackCtrl->apiSaveProgress($r));
        Router::post('/multimedia/api/favorite/toggle', fn(Request $r) => $playbackCtrl->apiToggleFavorite($r));
        Router::post('/multimedia/api/history/remove', fn(Request $r) => $playbackCtrl->apiRemoveHistory($r));
        Router::post('/multimedia/api/history/clear', fn(Request $r) => $playbackCtrl->apiClearHistory($r));
        Router::get('/multimedia/api/next-episode/{id}', fn(Request $r, string $id) => $playbackCtrl->apiNextEpisode($r, $id));
        Router::get('/multimedia/api/user-language-preferences', fn(Request $r) => $playbackCtrl->apiGetUserLanguagePreferences($r));
        Router::post('/multimedia/api/user-language-preferences', fn(Request $r) => $playbackCtrl->apiSaveUserLanguagePreferences($r));

        // Community & Engagement API routes
        Router::post('/multimedia/api/rate', fn(Request $r) => $playbackCtrl->apiRate($r));
        Router::post('/multimedia/api/rate/remove', fn(Request $r) => $playbackCtrl->apiRemoveRating($r));
        Router::post('/multimedia/api/review', fn(Request $r) => $playbackCtrl->apiSaveReview($r));
        Router::post('/multimedia/api/review/{id}/delete', fn(Request $r, string $id) => $playbackCtrl->apiDeleteReview($r, $id));
        Router::post('/multimedia/api/review/{id}/helpful', fn(Request $r, string $id) => $playbackCtrl->apiHelpfulReview($r, $id));
        Router::post('/multimedia/api/comment', fn(Request $r) => $playbackCtrl->apiSaveComment($r));
        Router::post('/multimedia/api/comment/{id}/delete', fn(Request $r, string $id) => $playbackCtrl->apiDeleteComment($r, $id));
        Router::post('/multimedia/api/report', fn(Request $r) => $playbackCtrl->apiReport($r));
        Router::get('/multimedia/api/reviews', fn(Request $r) => $playbackCtrl->apiGetReviews($r));
        Router::get('/multimedia/api/comments', fn(Request $r) => $playbackCtrl->apiGetComments($r));

        // Subscriptions & Notifications routes
        Router::get('/multimedia/notifications', fn(Request $r) => $frontendCtrl->notifications($r));
        Router::get('/multimedia/following', fn(Request $r) => $frontendCtrl->following($r));
        Router::post('/multimedia/api/subscribe/toggle', fn(Request $r) => $playbackCtrl->apiToggleSubscribe($r));
        Router::get('/multimedia/api/notifications', fn(Request $r) => $playbackCtrl->apiGetNotifications($r));
        Router::get('/multimedia/api/notifications/unread-count', fn(Request $r) => $playbackCtrl->apiGetUnreadCount($r));
        Router::post('/multimedia/api/notifications/{id}/read', fn(Request $r, string $id) => $playbackCtrl->apiMarkNotificationRead($r, $id));
        Router::post('/multimedia/api/notifications/mark-all-read', fn(Request $r) => $playbackCtrl->apiMarkAllNotificationsRead($r));
        Router::get('/multimedia/api/notification-preferences', fn(Request $r) => $playbackCtrl->apiGetNotificationPreferences($r));
        Router::post('/multimedia/api/notification-preferences', fn(Request $r) => $playbackCtrl->apiSaveNotificationPreferences($r));

        // Release Automation & Calendar Admin API routes
        $adminCtrl = $this->app->make(MultimediaAdminController::class);
        Router::post('/multimedia/api/releases/publish-now', fn(Request $r) => $adminCtrl->apiPublishNow($r));
        Router::post('/multimedia/api/releases/schedule', fn(Request $r) => $adminCtrl->apiScheduleRelease($r));
        Router::post('/multimedia/api/releases/cancel', fn(Request $r) => $adminCtrl->apiCancelSchedule($r));
        Router::post('/multimedia/api/releases/run-due', fn(Request $r) => $adminCtrl->apiRunDueReleases($r));
        Router::get('/multimedia/api/releases/calendar', fn(Request $r) => $adminCtrl->apiGetCalendar($r));
        Router::get('/multimedia/api/releases/queue', fn(Request $r) => $adminCtrl->apiGetQueue($r));

        // HLS Adaptive Streaming routes
        Router::get('/api/multimedia/hls/{id}/master.m3u8', fn(Request $r, string $id) => $playbackCtrl->hlsMaster($r, $id));
        Router::get('/api/multimedia/hls/{id}/audio/{audioId}/index.m3u8', fn(Request $r, string $id, string $audioId) => $playbackCtrl->hlsAudioVariant($r, $id, $audioId));
        Router::get('/api/multimedia/hls/{id}/audio/{audioId}/stream.mp3', fn(Request $r, string $id, string $audioId) => $playbackCtrl->hlsAudioStream($r, $id, $audioId));
        Router::get('/api/multimedia/hls/{id}/{quality}/index.m3u8', fn(Request $r, string $id, string $quality) => $playbackCtrl->hlsVariant($r, $id, $quality));
        Router::get('/api/multimedia/hls/{id}/{quality}/{segment}', fn(Request $r, string $id, string $quality, string $segment) => $playbackCtrl->hlsSegment($r, $id, $quality, $segment));

        // Media Processing Admin API routes
        Router::post('/multimedia/api/processing/dispatch', fn(Request $r) => $adminCtrl->apiDispatchProcessingJob($r));
        Router::post('/multimedia/api/processing/retry', fn(Request $r) => $adminCtrl->apiRetryProcessingJob($r));
        Router::post('/multimedia/api/processing/cancel', fn(Request $r) => $adminCtrl->apiCancelProcessingJob($r));
        Router::post('/multimedia/api/processing/run-queue', fn(Request $r) => $adminCtrl->apiRunProcessingQueue($r));
        Router::get('/multimedia/api/processing/status', fn(Request $r) => $adminCtrl->apiGetProcessingStatus($r));

        // Storage & Token Stream routes
        Router::get('/api/multimedia/storage/token-stream', fn(Request $r) => $playbackCtrl->tokenStream($r));
        Router::post('/api/multimedia/admin/storage/save-settings', fn(Request $r) => $adminCtrl->apiSaveStorageSettings($r));
        Router::post('/api/multimedia/admin/storage/test-connection', fn(Request $r) => $adminCtrl->apiTestStorageConnection($r));
        Router::post('/api/multimedia/admin/storage/migrate', fn(Request $r) => $adminCtrl->apiMigrateStorage($r));
        Router::post('/api/multimedia/admin/storage/cleanup-orphans', fn(Request $r) => $adminCtrl->apiCleanupOrphans($r));
        Router::get('/api/multimedia/admin/storage/stats', fn(Request $r) => $adminCtrl->apiGetStorageStats($r));

        // Localization Admin API routes
        Router::get('/admin/api/multimedia/localizations', fn(Request $r) => $adminCtrl->apiGetLocalizations($r));
        Router::post('/admin/api/multimedia/localizations', fn(Request $r) => $adminCtrl->apiSaveLocalization($r));
        Router::post('/admin/api/multimedia/localizations/delete', fn(Request $r) => $adminCtrl->apiDeleteLocalization($r));

        self::$routesRegistered = true;
    }
}


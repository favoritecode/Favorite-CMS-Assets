<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Integrations;

use FavoriteCMS\Core\Container;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Models\User;

class FavoriteDigitalAdapter
{
    /**
     * Check if Favorite Digital plugin is installed, booted, or active in the CMS.
     */
    public static function isAvailable(): bool
    {
        // 1. Check test injection
        if (isset($GLOBALS['_test_favorite_digital_available'])) {
            return (bool)$GLOBALS['_test_favorite_digital_available'];
        }

        // 2. Check known Favorite Digital classes
        if (class_exists('FavoriteCMS\\Digital\\FavoriteDigitalPlugin') || class_exists('FavoriteCMS\\Digital\\Services\\MembershipService')) {
            return true;
        }

        // 3. Check active plugins setting
        try {
            $raw = \FavoriteCMS\Models\Setting::get('plugins', 'active', '[]');
            $list = is_array($raw) ? $raw : json_decode((string)$raw, true);
            if (is_array($list) && in_array('favorite-digital', $list, true)) {
                return true;
            }
        } catch (\Throwable) {
            // Ignore during setup
        }

        // 4. Check database membership tables
        try {
            if (Container::getInstance()->has(Database::class)) {
                $db = Container::getInstance()->get(Database::class);
                if ($db->tableExists('favorite_digital_memberships')) {
                    return true;
                }
            }
        } catch (\Throwable) {
            // Ignore
        }

        return false;
    }

    /**
     * Verify whether a user holds a valid premium entitlement for the requested multimedia item.
     *
     * @param User|int|null $user
     * @param string $contentType 'movie', 'series', 'episode', 'song', 'playlist'
     * @param int $contentId
     * @return bool
     */
    public static function userHasEntitlement(User|int|null $user, string $contentType, int $contentId): bool
    {
        $resolvedUser = null;
        if ($user instanceof User) {
            $resolvedUser = $user;
        } elseif (is_numeric($user) && (int)$user > 0) {
            $resolvedUser = User::find((int)$user);
        } elseif (function_exists('current_user')) {
            $resolvedUser = current_user();
        }

        if (!$resolvedUser) {
            return false;
        }

        // Super-admin always has bypass permission
        if ($resolvedUser->hasRole('super-admin') || $resolvedUser->hasRole('admin')) {
            return true;
        }

        // Test mock injection for entitlement
        if (isset($GLOBALS['_test_favorite_digital_entitled_users'])) {
            $entitled = (array)$GLOBALS['_test_favorite_digital_entitled_users'];
            return in_array((int)$resolvedUser->id, $entitled, true);
        }

        // Check if Favorite Digital hook is registered
        if (function_exists('apply_filters')) {
            try {
                $filtered = apply_filters('favorite_multimedia.user_has_entitlement', null, $resolvedUser, $contentType, $contentId);
                if ($filtered !== null) {
                    return (bool)$filtered;
                }
            } catch (\Throwable) {
                // Fail closed on error
                return false;
            }
        }

        // If Favorite Digital is installed, inspect active memberships table
        if (self::isAvailable()) {
            try {
                $db = Container::getInstance()->get(Database::class);
                if ($db->tableExists('favorite_digital_memberships')) {
                    $now = date('Y-m-d H:i:s');
                    $row = $db->selectOne(
                        "SELECT id FROM favorite_digital_memberships 
                         WHERE user_id = ? AND status = 'active' AND (expires_at IS NULL OR expires_at > ?) 
                         LIMIT 1",
                        [(int)$resolvedUser->id, $now]
                    );
                    return $row !== null;
                }
            } catch (\Throwable) {
                // Fail closed on error
                return false;
            }
        }

        // Fail closed: if Favorite Digital is missing, inactive, unentitled, or expired
        return false;
    }

    /**
     * URL for users to acquire a premium subscription through Favorite Digital.
     */
    public static function getSubscriptionUrl(): string
    {
        if (function_exists('apply_filters')) {
            $url = apply_filters('favorite_multimedia.subscription_url', null);
            if (is_string($url) && $url !== '') {
                return $url;
            }
        }

        return '/pricing';
    }
}


<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Models;

use FavoriteCMS\Models\BaseModel;

class Album extends BaseModel
{
    protected static string $table = 'multimedia_albums';

    public static function findBySlug(string $slug): ?self
    {
        $db = \FavoriteCMS\Core\Container::getInstance()->get(\FavoriteCMS\Core\Database::class);
        $row = $db->selectOne("SELECT * FROM multimedia_albums WHERE slug = ?", [$slug]);
        return $row ? new static((array)$row) : null;
    }

    public function getArtist(): ?Artist
    {
        if (empty($this->artist_id)) {
            return null;
        }
        return Artist::find((int)$this->artist_id);
    }

    public function getSongs(): array
    {
        $rows = $this->db->select(
            "SELECT * FROM multimedia_songs WHERE album_id = ? AND status = 'published' ORDER BY id ASC",
            [$this->id]
        );
        return array_map(fn($r) => new Song((array)$r), $rows);
    }
}


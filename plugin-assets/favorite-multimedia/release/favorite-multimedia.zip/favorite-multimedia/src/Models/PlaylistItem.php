<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Models;

use FavoriteCMS\Models\BaseModel;

class PlaylistItem extends BaseModel
{
    protected static string $table = 'multimedia_playlist_items';
}


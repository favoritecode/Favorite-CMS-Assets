<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Permissions;

use FavoriteCMS\Core\Database;
use FavoriteCMS\Models\User;

final class MultimediaPermission
{
    public const VIEW             = 'multimedia.view';
    public const CREATE           = 'multimedia.create';
    public const EDIT             = 'multimedia.edit';
    public const DELETE           = 'multimedia.delete';
    public const PUBLISH          = 'multimedia.publish';
    public const MANAGE_SOURCES   = 'multimedia.manage_sources';
    public const MANAGE_SUBTITLES = 'multimedia.manage_subtitles';
    public const MANAGE_PLAYLISTS = 'multimedia.manage_playlists';
    public const MANAGE_SETTINGS  = 'multimedia.manage_settings';
    public const MANAGE_ACCESS    = 'multimedia.manage_access';
    public const VIEW_ANALYTICS   = 'multimedia.view_analytics';
    public const MODERATE         = 'multimedia.moderate';

    public static function can(string $permission, ?User $user = null): bool
    {
        if ($user === null && function_exists('current_user')) {
            $user = current_user();
        }

        if (!$user || $user->isBanned()) {
            return false;
        }

        if ($user->hasRole('super-admin') || $user->hasRole('admin')) {
            return true;
        }

        return $user->hasPermission($permission);
    }

    /**
     * Register default multimedia permissions in the CMS permissions table.
     */
    public static function registerDefaultPermissions(?Database $db): void
    {
        if ($db === null || !$db->tableExists('permissions')) {
            return;
        }

        $definitions = [
            ['name' => 'View Multimedia',             'slug' => self::VIEW,             'description' => 'View multimedia catalog, lists and details in admin', 'group_name' => 'multimedia'],
            ['name' => 'Create Multimedia Content',    'slug' => self::CREATE,           'description' => 'Create new movies, series, episodes and songs',       'group_name' => 'multimedia'],
            ['name' => 'Edit Multimedia Content',      'slug' => self::EDIT,             'description' => 'Edit existing multimedia items and metadata',          'group_name' => 'multimedia'],
            ['name' => 'Delete Multimedia Content',    'slug' => self::DELETE,           'description' => 'Delete multimedia items and entries',                  'group_name' => 'multimedia'],
            ['name' => 'Publish Multimedia Content',   'slug' => self::PUBLISH,          'description' => 'Publish or unpublish multimedia content',              'group_name' => 'multimedia'],
            ['name' => 'Manage Media Sources',        'slug' => self::MANAGE_SOURCES,   'description' => 'Manage video, audio, HLS and embed sources',           'group_name' => 'multimedia'],
            ['name' => 'Manage Subtitles',            'slug' => self::MANAGE_SUBTITLES, 'description' => 'Manage multi-language subtitles and tracks',           'group_name' => 'multimedia'],
            ['name' => 'Manage Playlists',            'slug' => self::MANAGE_PLAYLISTS, 'description' => 'Create and curate audio playlists',                    'group_name' => 'multimedia'],
            ['name' => 'Manage Multimedia Settings',  'slug' => self::MANAGE_SETTINGS,  'description' => 'Configure global multimedia settings and downloads',   'group_name' => 'multimedia'],
            ['name' => 'Manage Multimedia Access',    'slug' => self::MANAGE_ACCESS,    'description' => 'Configure access modes, entitlements and rules',       'group_name' => 'multimedia'],
            ['name' => 'View Multimedia Analytics',   'slug' => self::VIEW_ANALYTICS,   'description' => 'View play, view and download analytics data',          'group_name' => 'multimedia'],
            ['name' => 'Moderate Multimedia Community','slug' => self::MODERATE,         'description' => 'Moderate reviews, comments and community reports',      'group_name' => 'multimedia'],
        ];

        foreach ($definitions as $def) {
            $exists = $db->selectOne("SELECT id FROM permissions WHERE slug = ? LIMIT 1", [$def['slug']]);
            if (!$exists) {
                $db->insert('permissions', $def);
            }
        }

        // Link to Admin role
        if ($db->tableExists('roles') && $db->tableExists('role_permissions')) {
            $adminRole = $db->selectOne("SELECT id FROM roles WHERE slug = 'admin' LIMIT 1");
            if ($adminRole) {
                foreach ($definitions as $def) {
                    $perm = $db->selectOne("SELECT id FROM permissions WHERE slug = ? LIMIT 1", [$def['slug']]);
                    if ($perm) {
                        $rpExists = $db->selectOne(
                            "SELECT 1 FROM role_permissions WHERE role_id = ? AND permission_id = ? LIMIT 1",
                            [$adminRole->id, $perm->id]
                        );
                        if (!$rpExists) {
                            $db->insert('role_permissions', [
                                'role_id'       => $adminRole->id,
                                'permission_id' => $perm->id,
                            ]);
                        }
                    }
                }
            }
        }
    }
}


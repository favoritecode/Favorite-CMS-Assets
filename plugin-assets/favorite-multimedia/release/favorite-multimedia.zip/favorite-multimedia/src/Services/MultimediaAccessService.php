<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Services;

use FavoriteCMS\Models\Setting;
use FavoriteCMS\Models\User;
use FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter;
use FavoriteCMS\Multimedia\Models\Episode;
use FavoriteCMS\Multimedia\Models\MediaSource;
use FavoriteCMS\Multimedia\Models\Movie;
use FavoriteCMS\Multimedia\Models\Playlist;
use FavoriteCMS\Multimedia\Models\Song;

class MultimediaAccessService
{
    public const ALLOW = 'ALLOW';
    public const LOGIN_REQUIRED = 'LOGIN_REQUIRED';
    public const PREMIUM_REQUIRED = 'PREMIUM_REQUIRED';
    public const FORBIDDEN = 'FORBIDDEN';
    public const NOT_FOUND = 'NOT_FOUND';

    /**
     * Evaluate viewing access for a given content item.
     *
     * @param User|null $user
     * @param string $contentType 'movie', 'series', 'episode', 'song', 'playlist'
     * @param int|object $content Either content ID or model instance
     * @return string One of the access constants (ALLOW, LOGIN_REQUIRED, PREMIUM_REQUIRED, FORBIDDEN, NOT_FOUND)
     */
    public static function canAccess(?User $user, string|object $content, ?int $contentId = null): bool
    {
        if (is_object($content)) {
            $contentType = match (true) {
                $content instanceof Movie => 'movie',
                $content instanceof Series => 'series',
                $content instanceof Episode => 'episode',
                $content instanceof Song => 'song',
                $content instanceof Playlist => 'playlist',
                default => 'movie',
            };
            return self::checkAccess($user, $contentType, $content) === self::ALLOW;
        }

        return self::checkAccess($user, (string)$content, $contentId ?? 0) === self::ALLOW;
    }

    public static function checkAccess(?User $user, string $contentType, int|object $content): string
    {
        // 1. Resolve content model
        $model = is_object($content) ? $content : self::findContentModel($contentType, (int)$content);
        if (!$model) {
            return self::NOT_FOUND;
        }

        // 2. Draft / Unlisted content check
        $status = $model->status ?? 'published';
        if ($status !== 'published') {
            // Only admin/super-admin can view unpublished content
            if (!$user || (!$user->hasRole('super-admin') && !$user->hasRole('admin'))) {
                return self::NOT_FOUND;
            }
        }

        // Parent hierarchy check for episodes (unreleased series hides episode)
        if ($contentType === 'episode' && $model instanceof Episode) {
            $series = $model->getSeries();
            if ($series && ($series->status ?? 'published') !== 'published') {
                if (!$user || (!$user->hasRole('super-admin') && !$user->hasRole('admin'))) {
                    return self::NOT_FOUND;
                }
            }
        }

        // 3. Super-admin and Admin always have full access
        if ($user && ($user->hasRole('super-admin') || $user->hasRole('admin'))) {
            return self::ALLOW;
        }

        // 4. Resolve effective access mode (handling inheritance for episodes)
        $accessMode = self::resolveEffectiveAccessMode($contentType, $model);

        // 5. Evaluate access modes
        switch ($accessMode) {
            case 'public':
                return self::ALLOW;

            case 'login':
                if (!$user || (int)($user->id ?? 0) <= 0) {
                    return self::LOGIN_REQUIRED;
                }
                if ($user->isBanned()) {
                    return self::FORBIDDEN;
                }
                return self::ALLOW;

            case 'premium':
                if (!$user || (int)($user->id ?? 0) <= 0) {
                    return self::LOGIN_REQUIRED;
                }
                if ($user->isBanned()) {
                    return self::FORBIDDEN;
                }

                // Check Favorite Digital entitlement (Exclusive authority for PREMIUM; fails closed)
                try {
                    $hasEntitlement = FavoriteDigitalAdapter::userHasEntitlement($user, $contentType, (int)$model->id);
                    if ($hasEntitlement) {
                        return self::ALLOW;
                    }
                } catch (\Throwable $e) {
                    \FavoriteCMS\Core\Logger::error('Favorite Multimedia: Favorite Digital entitlement evaluation failed (failing closed)', [
                        'user_id'      => (int)$user->id,
                        'content_type' => $contentType,
                        'content_id'   => (int)$model->id,
                        'error'        => $e->getMessage(),
                    ]);
                    return self::PREMIUM_REQUIRED;
                }

                return self::PREMIUM_REQUIRED;

            default:
                return self::ALLOW;
        }
    }

    /**
     * Resolve effective access mode taking hierarchy into account.
     * For Episodes: Episode access_mode ('public', 'login', 'premium') overrides Series access_mode.
     * If Episode access_mode is 'inherit', it inherits from parent Series.
     */
    public static function resolveEffectiveAccessMode(string $contentType, object $model): string
    {
        if ($contentType === 'episode' && $model instanceof Episode) {
            return strtolower($model->getResolvedAccessMode());
        }

        $mode = strtolower((string)($model->access_mode ?? 'public'));
        return in_array($mode, ['public', 'login', 'premium'], true) ? $mode : 'public';
    }

    /**
     * Resolve viewing access for a song inside a playlist.
     * Enforces BOTH playlist-level access AND individual song access.
     */
    public static function checkPlaylistTrackAccess(?User $user, Playlist $playlist, Song $song): string
    {
        // Check playlist access first
        $playlistAccess = self::checkAccess($user, 'playlist', $playlist);
        if ($playlistAccess !== self::ALLOW) {
            return $playlistAccess;
        }

        // Check individual song access
        return self::checkAccess($user, 'song', $song);
    }

    /**
     * Check download permission for a specific content item and optional source.
     * Download permission is separate from viewing permission, but requires viewing access.
     *
     * @param User|null $user
     * @param string $contentType
     * @param int|object $content
     * @param MediaSource|null $source
     * @return array{allowed: bool, reason: string, access_state: string}
     */
    public static function checkDownloadPermission(
        ?User $user,
        string $contentType,
        int|object $content,
        ?MediaSource $source = null
    ): array {
        $model = is_object($content) ? $content : self::findContentModel($contentType, (int)$content);
        if (!$model) {
            return [
                'allowed'      => false,
                'reason'       => 'Content not found.',
                'access_state' => self::NOT_FOUND,
            ];
        }

        // 1. First verify content viewing access
        $viewAccess = self::checkAccess($user, $contentType, $model);
        if ($viewAccess !== self::ALLOW) {
            $reason = match ($viewAccess) {
                self::LOGIN_REQUIRED   => 'You must log in to download this content.',
                self::PREMIUM_REQUIRED => 'A Premium subscription is required to download this media.',
                self::FORBIDDEN        => 'Your account does not have permission to download.',
                default                => 'Content access is restricted.',
            };
            return [
                'allowed'      => false,
                'reason'       => $reason,
                'access_state' => $viewAccess,
            ];
        }

        // 2. Super-admin and Admin always have download permission once published
        if ($user && ($user->hasRole('super-admin') || $user->hasRole('admin'))) {
            return [
                'allowed'      => true,
                'reason'       => 'Authorized as administrator.',
                'access_state' => self::ALLOW,
            ];
        }

        // 3. Resolve source downloadable feasibility (e.g. embeds & M3U8 cannot be downloaded as simple files)
        if ($source !== null) {
            $resolved = MediaSourceResolver::resolve(
                (string)$source->url_or_path,
                (string)$source->source_mode,
                (string)$source->source_type
            );
            if (!$resolved['is_downloadable']) {
                $reason = ($source->source_type === 'hls')
                    ? 'M3U8 streams cannot be downloaded as direct files.'
                    : 'External embedded media does not support direct downloading.';
                return [
                    'allowed'      => false,
                    'reason'       => $reason,
                    'access_state' => self::FORBIDDEN,
                ];
            }
        }

        // 4. Resolve download permission hierarchy:
        // Source allow_download -> Content download_policy -> Global setting 'enable_downloads'
        $globalSetting = Setting::get('multimedia', 'enable_downloads', 'yes');
        $isGlobalEnabled = ($globalSetting === 'yes' || $globalSetting === '1' || $globalSetting === 'true');

        $parentPolicy = (string)($model->download_policy ?? 'inherit');
        if ($contentType === 'episode' && $model instanceof Episode) {
            $parentPolicy = $model->getResolvedDownloadPolicy();
        }

        $sourcePolicy = $source ? (string)($source->allow_download ?? 'inherit') : 'inherit';

        // Direct source rule
        if ($sourcePolicy === 'deny') {
            return [
                'allowed'      => false,
                'reason'       => 'Downloads are disabled for this media source.',
                'access_state' => self::FORBIDDEN,
            ];
        }
        if ($sourcePolicy === 'allow') {
            return [
                'allowed'      => true,
                'reason'       => 'Download allowed by media source policy.',
                'access_state' => self::ALLOW,
            ];
        }

        // Content policy rule
        if ($parentPolicy === 'deny') {
            return [
                'allowed'      => false,
                'reason'       => 'Downloads are disabled for this item.',
                'access_state' => self::FORBIDDEN,
            ];
        }
        if ($parentPolicy === 'allow') {
            return [
                'allowed'      => true,
                'reason'       => 'Download allowed by content policy.',
                'access_state' => self::ALLOW,
            ];
        }

        // Global fallback
        if (!$isGlobalEnabled) {
            return [
                'allowed'      => false,
                'reason'       => 'Media downloads are currently disabled site-wide.',
                'access_state' => self::FORBIDDEN,
            ];
        }

        return [
            'allowed'      => true,
            'reason'       => 'Download allowed.',
            'access_state' => self::ALLOW,
        ];
    }

    public static function findContentModel(string $contentType, int $id): ?object
    {
        return match ($contentType) {
            'movie'    => Movie::find($id),
            'series'   => \FavoriteCMS\Multimedia\Models\Series::find($id),
            'episode'  => Episode::find($id),
            'song'     => Song::find($id),
            'playlist' => Playlist::find($id),
            default    => null,
        };
    }
}


<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Services;

use FavoriteCMS\Models\Setting;
use FavoriteCMS\Models\User;

/**
 * Canonical appearance mode resolver for Favorite Multimedia Plugin.
 *
 * Supports exactly:
 * - AUTO
 * - LIGHT
 * - DARK
 *
 * Scoped strictly to multimedia components and containers.
 * Never modifies or restyles the active theme's global shell, header, or footer.
 */
final class MultimediaAppearanceService
{
    public const MODE_AUTO  = 'auto';
    public const MODE_LIGHT = 'light';
    public const MODE_DARK  = 'dark';

    public const VALID_MODES = [
        self::MODE_AUTO,
        self::MODE_LIGHT,
        self::MODE_DARK,
    ];

    /**
     * Get the configured appearance preference.
     * Hierarchy:
     * 1. Logged in user preference if available
     * 2. Session override
     * 3. Plugin setting 'multimedia.appearance_mode'
     * 4. Default: 'auto'
     */
    public static function getPreference(?User $user = null): string
    {
        if ($user && method_exists($user, 'preference')) {
            try {
                $userPref = $user->preference('multimedia_color_mode');
                if (is_string($userPref) && in_array(strtolower(trim($userPref)), self::VALID_MODES, true)) {
                    return strtolower(trim($userPref));
                }
            } catch (\Throwable) {}
        }

        if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['fm_appearance_mode'])) {
            $sessPref = strtolower(trim((string)$_SESSION['fm_appearance_mode']));
            if (in_array($sessPref, self::VALID_MODES, true)) {
                return $sessPref;
            }
        }

        if (class_exists(Setting::class)) {
            try {
                $adminSetting = Setting::get('multimedia', 'admin_color_mode', null);
                if (is_string($adminSetting) && in_array(strtolower(trim($adminSetting)), self::VALID_MODES, true)) {
                    return strtolower(trim($adminSetting));
                }

                $setting = Setting::get('multimedia', 'appearance_mode', self::MODE_AUTO);
                if (is_string($setting) && in_array(strtolower(trim($setting)), self::VALID_MODES, true)) {
                    return strtolower(trim($setting));
                }
            } catch (\Throwable) {}
        }

        return self::MODE_AUTO;
    }

    /**
     * Save appearance preference for user, session, or global plugin setting.
     */
    public static function setPreference(string $mode, ?User $user = null): bool
    {
        $mode = strtolower(trim($mode));
        if (!in_array($mode, self::VALID_MODES, true)) {
            return false;
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['fm_appearance_mode'] = $mode;
        }

        if ($user && method_exists($user, 'setPreference')) {
            try {
                $user->setPreference('multimedia_color_mode', $mode);
            } catch (\Throwable) {}
        }

        return true;
    }

    /**
     * Resolve effective mode ('light' or 'dark').
     *
     * Resolution hierarchy:
     * 1. Explicit 'light' or 'dark' preference always wins.
     * 2. If 'auto':
     *    a. Active theme/CMS appearance preference setting if defined (e.g. appearance.theme_mode)
     *    b. Active theme declared color-scheme (Official theme defaults to light)
     *    c. Client hints (Sec-CH-Prefers-Color-Scheme) or Cookie (fm_color_mode)
     *    d. Default to 'light' (never hardcode Auto = Dark)
     */
    public static function resolveEffectiveMode(?string $preference = null): string
    {
        $pref = $preference !== null ? strtolower(trim($preference)) : self::getPreference();

        if ($pref === self::MODE_LIGHT || $pref === self::MODE_DARK) {
            return $pref;
        }

        // AUTO Resolution:
        // 1. Favorite CMS / active theme appearance preference if setting exists
        if (class_exists(Setting::class)) {
            try {
                $themeMode = Setting::get('appearance', 'theme_mode', '');
                if (is_string($themeMode) && ($themeMode === 'light' || $themeMode === 'dark')) {
                    return $themeMode;
                }
                $cmsScheme = Setting::get('general', 'color_scheme', '');
                if (is_string($cmsScheme) && ($cmsScheme === 'light' || $cmsScheme === 'dark')) {
                    return $cmsScheme;
                }
            } catch (\Throwable) {}
        }

        // 2. Client hints HTTP_SEC_CH_PREFERS_COLOR_SCHEME
        if (!empty($_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME'])) {
            $ch = strtolower(trim((string)$_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME']));
            if ($ch === 'dark') {
                return self::MODE_DARK;
            }
            if ($ch === 'light') {
                return self::MODE_LIGHT;
            }
        }

        // 3. Client cookie set by multimedia-appearance.js
        if (!empty($_COOKIE['fm_color_mode'])) {
            $cookie = strtolower(trim((string)$_COOKIE['fm_color_mode']));
            if ($cookie === 'dark') {
                return self::MODE_DARK;
            }
            if ($cookie === 'light') {
                return self::MODE_LIGHT;
            }
        }

        // 4. Default to light
        return self::MODE_LIGHT;
    }

    /**
     * Resolve effective mode for Multimedia Admin screens.
     *
     * Priority:
     * 1. Favorite CMS current admin appearance state (cookies/headers)
     * 2. Canonical CMS appearance setting/helper
     * 3. prefers-color-scheme
     * 4. Fallback light
     */
    public static function resolveAdminEffectiveMode(?User $user = null): string
    {
        $pref = self::getPreference($user);
        if ($pref === self::MODE_LIGHT || $pref === self::MODE_DARK) {
            return $pref;
        }

        // 1. Favorite CMS current admin appearance state from cookies
        foreach (['favorite-cms-admin-theme', 'admin_theme', 'fm_admin_color_mode', 'fm_color_mode'] as $cookieKey) {
            if (!empty($_COOKIE[$cookieKey])) {
                $cVal = strtolower(trim((string)$_COOKIE[$cookieKey]));
                if ($cVal === self::MODE_DARK) {
                    return self::MODE_DARK;
                }
                if ($cVal === self::MODE_LIGHT) {
                    return self::MODE_LIGHT;
                }
            }
        }

        // 2. Canonical CMS appearance settings
        if (class_exists(Setting::class)) {
            try {
                $settingKeys = [
                    ['admin', 'theme'],
                    ['appearance', 'admin_theme'],
                    ['appearance', 'theme_mode'],
                    ['general', 'admin_color_scheme'],
                    ['general', 'color_scheme'],
                ];
                foreach ($settingKeys as [$grp, $key]) {
                    $val = Setting::get($grp, $key, '');
                    if (is_string($val)) {
                        $val = strtolower(trim($val));
                        if ($val === self::MODE_DARK) {
                            return self::MODE_DARK;
                        }
                        if ($val === self::MODE_LIGHT) {
                            return self::MODE_LIGHT;
                        }
                    }
                }
            } catch (\Throwable) {}
        }

        // 3. Client hints
        if (!empty($_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME'])) {
            $ch = strtolower(trim((string)$_SERVER['HTTP_SEC_CH_PREFERS_COLOR_SCHEME']));
            if ($ch === self::MODE_DARK) {
                return self::MODE_DARK;
            }
            if ($ch === self::MODE_LIGHT) {
                return self::MODE_LIGHT;
            }
        }

        // 4. Fallback light
        return self::MODE_LIGHT;
    }

    /**
     * Get HTML attributes for multimedia root containers.
     * e.g. data-fm-color-mode="light" data-fm-configured-mode="auto"
     */
    public static function getContainerAttributes(?User $user = null): string
    {
        $pref = self::getPreference($user);
        $effective = self::resolveEffectiveMode($pref);

        return sprintf(
            'data-fm-color-mode="%s" data-fm-configured-mode="%s"',
            htmlspecialchars($effective, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($pref, ENT_QUOTES, 'UTF-8')
        );
    }

    /**
     * Get HTML attributes for Multimedia Admin root container.
     * e.g. data-fm-color-mode="dark" data-fm-configured-mode="auto" class="fav-admin-wrap fm-dark"
     */
    public static function getAdminContainerAttributes(?User $user = null): string
    {
        $pref = self::getPreference($user);
        $effective = self::resolveAdminEffectiveMode($user);

        return sprintf(
            'data-fm-color-mode="%s" data-fm-configured-mode="%s" class="fav-admin-wrap fm-%s"',
            htmlspecialchars($effective, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($pref, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($effective, ENT_QUOTES, 'UTF-8')
        );
    }
}


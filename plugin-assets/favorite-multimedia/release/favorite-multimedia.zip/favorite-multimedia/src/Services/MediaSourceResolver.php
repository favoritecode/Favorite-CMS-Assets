<?php

declare(strict_types=1);

namespace FavoriteCMS\Multimedia\Services;

class MediaSourceResolver
{
    /**
     * Resolves a media URL or local upload path into structured playback and download metadata.
     *
     * @param string $urlOrPath The source URL or local path
     * @param string $mode 'url' or 'upload' or 'auto'
     * @param string|null $manualType Optional manual override: 'video', 'hls', 'audio', 'embed'
     * @return array
     */
    public static function resolve(string $urlOrPath, string $mode = 'auto', ?string $manualType = null): array
    {
        $urlOrPath = trim($urlOrPath);
        if ($urlOrPath === '') {
            return [
                'valid'             => false,
                'source_mode'       => 'unknown',
                'source_type'       => 'unknown',
                'player_type'       => 'none',
                'playable_url'      => '',
                'mime_type'         => '',
                'is_downloadable'   => false,
                'download_method'   => 'none',
                'error'             => 'Source URL or path cannot be empty.',
            ];
        }

        // Determine mode: upload vs url
        if ($mode === 'auto') {
            $isUpload = str_starts_with($urlOrPath, '/') || str_starts_with($urlOrPath, 'uploads/') || str_starts_with($urlOrPath, 'storage/');
            $mode = $isUpload ? 'upload' : 'url';
        }

        // Validate URL security if mode is 'url'
        if ($mode === 'url') {
            $validation = self::validateUrlSecurity($urlOrPath);
            if (!$validation['safe']) {
                return [
                    'valid'             => false,
                    'source_mode'       => 'url',
                    'source_type'       => 'unknown',
                    'player_type'       => 'none',
                    'playable_url'      => '',
                    'mime_type'         => '',
                    'is_downloadable'   => false,
                    'download_method'   => 'none',
                    'error'             => $validation['reason'],
                ];
            }
        }

        // Manual type override if specified
        if ($manualType !== null && in_array($manualType, ['video', 'hls', 'audio', 'embed'], true)) {
            return self::buildResolvedResult($urlOrPath, $mode, $manualType, null);
        }

        // Automatic type detection
        $detected = self::detectSourceType($urlOrPath);

        return self::buildResolvedResult($urlOrPath, $mode, $detected['type'], $detected);
    }

    /**
     * Strictly validate URL schemes and protect against SSRF and protocol exploits.
     */
    public static function validateUrlSecurity(string $url): array
    {
        // 1. Reject control characters
        if (preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return ['safe' => false, 'reason' => 'URL contains forbidden control characters.'];
        }

        // 2. Reject dangerous schemes
        $lower = strtolower($url);
        $dangerousSchemes = ['javascript:', 'data:', 'file:', 'vbscript:', 'phar:', 'php:', 'gopher:', 'dict:', 'ldap:'];
        foreach ($dangerousSchemes as $danger) {
            if (str_starts_with($lower, $danger)) {
                return ['safe' => false, 'reason' => "Dangerous URL scheme '{$danger}' is strictly rejected."];
            }
        }

        // 3. Reject protocol-relative URLs (e.g. //evil.com)
        if (str_starts_with($url, '//')) {
            return ['safe' => false, 'reason' => 'Protocol-relative URLs are not permitted.'];
        }

        // 4. Validate parse_url
        $parsed = parse_url($url);
        if ($parsed === false || empty($parsed['scheme']) || empty($parsed['host'])) {
            return ['safe' => false, 'reason' => 'Invalid URL structure. Must be a complete HTTP/HTTPS URL.'];
        }

        $scheme = strtolower($parsed['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return ['safe' => false, 'reason' => "Only HTTP and HTTPS protocols are permitted. Found: {$scheme}."];
        }

        // 5. SSRF validation on host
        $host = strtolower($parsed['host']);

        // Check for localhost or loopback name
        if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) {
            return ['safe' => false, 'reason' => 'Access to internal or loopback hostnames is forbidden (SSRF protection).'];
        }

        // Normalize bracketed IPv6 hosts (e.g. [::1])
        $cleanHost = trim($host, '[]');

        // Check standard IP addresses
        if (filter_var($cleanHost, FILTER_VALIDATE_IP)) {
            if (self::isPrivateOrReservedIp($cleanHost)) {
                return ['safe' => false, 'reason' => 'Access to private, loopback, or cloud-metadata IP addresses is forbidden.'];
            }
        }

        // Check decimal integer hosts (e.g. 2130706433 -> 127.0.0.1)
        if (ctype_digit($cleanHost) && (float)$cleanHost <= 4294967295) {
            $decimalIp = long2ip((int)$cleanHost);
            if ($decimalIp && self::isPrivateOrReservedIp($decimalIp)) {
                return ['safe' => false, 'reason' => 'Access to private, loopback, or cloud-metadata IP addresses is forbidden.'];
            }
        }

        // Check hex hosts (e.g. 0x7f000001 -> 127.0.0.1)
        if (preg_match('/^0x[0-9a-f]+$/i', $cleanHost)) {
            $hexIp = long2ip((int)hexdec($cleanHost));
            if ($hexIp && self::isPrivateOrReservedIp($hexIp)) {
                return ['safe' => false, 'reason' => 'Access to private, loopback, or cloud-metadata IP addresses is forbidden.'];
            }
        }

        // Check octal-notation IPv4 addresses (e.g. 0177.0.0.1 -> 127.0.0.1)
        if (preg_match('/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/', $cleanHost, $octMatches)) {
            $hasOctal = false;
            $parts = [];
            for ($i = 1; $i <= 4; $i++) {
                $seg = $octMatches[$i];
                if (strlen($seg) > 1 && str_starts_with($seg, '0')) {
                    $hasOctal = true;
                    $parts[] = octdec($seg);
                } else {
                    $parts[] = (int)$seg;
                }
            }
            if ($hasOctal) {
                $normalizedOctalIp = implode('.', $parts);
                if (self::isPrivateOrReservedIp($normalizedOctalIp)) {
                    return ['safe' => false, 'reason' => 'Access to private, loopback, or cloud-metadata IP addresses is forbidden.'];
                }
            }
        }

        // Check DNS-resolved IPs to prevent SSRF DNS rebinding
        if (!filter_var($cleanHost, FILTER_VALIDATE_IP)) {
            $resolvedIps = @gethostbynamel($cleanHost);
            if (is_array($resolvedIps)) {
                foreach ($resolvedIps as $rIp) {
                    if (self::isPrivateOrReservedIp($rIp)) {
                        return ['safe' => false, 'reason' => "Hostname resolves to private/reserved IP: {$rIp} (SSRF protection)."];
                    }
                }
            }
        }

        return ['safe' => true, 'reason' => ''];
    }

    /**
     * Check if an IP address belongs to private, loopback, link-local, or cloud metadata ranges.
     */
    public static function isPrivateOrReservedIp(string $ip): bool
    {
        // Check IPv4 & IPv6 with FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return true;
        }

        // Explicit check for cloud metadata service (169.254.169.254) and link-local (169.254.0.0/16)
        if (str_starts_with($ip, '169.254.')) {
            return true;
        }

        // Explicit check for IPv6 loopback and link-local
        if ($ip === '::1' || str_starts_with(strtolower($ip), 'fe80:')) {
            return true;
        }

        return false;
    }

    /**
     * Detect media type from URL extension or known third-party embed service pattern.
     */
    public static function detectSourceType(string $urlOrPath): array
    {
        $cleanPath = parse_url($urlOrPath, PHP_URL_PATH) ?? $urlOrPath;
        $ext = strtolower(pathinfo($cleanPath, PATHINFO_EXTENSION));

        // 1. Check HLS Streaming
        if ($ext === 'm3u8' || str_contains(strtolower($urlOrPath), '.m3u8')) {
            return [
                'type'      => 'hls',
                'mime_type' => 'application/x-mpegURL',
            ];
        }

        // 2. Direct Video extensions
        $videoExtensions = [
            'mp4'  => 'video/mp4',
            'webm' => 'video/webm',
            'ogv'  => 'video/ogg',
            'mov'  => 'video/quicktime',
            'm4v'  => 'video/mp4',
        ];
        if (isset($videoExtensions[$ext])) {
            return [
                'type'      => 'video',
                'mime_type' => $videoExtensions[$ext],
            ];
        }

        // 3. Direct Audio extensions
        $audioExtensions = [
            'mp3'  => 'audio/mpeg',
            'm4a'  => 'audio/mp4',
            'aac'  => 'audio/aac',
            'wav'  => 'audio/wav',
            'ogg'  => 'audio/ogg',
            'oga'  => 'audio/ogg',
            'flac' => 'audio/flac',
            'opus' => 'audio/opus',
        ];
        if (isset($audioExtensions[$ext])) {
            return [
                'type'      => 'audio',
                'mime_type' => $audioExtensions[$ext],
            ];
        }

        // 4. Known third-party Embed services
        $embed = self::detectEmbedService($urlOrPath);
        if ($embed !== null) {
            return [
                'type'         => 'embed',
                'mime_type'    => 'text/html',
                'embed_url'    => $embed['embed_url'],
                'service'      => $embed['service'],
            ];
        }

        // 5. Inconclusive: Unknown type
        return [
            'type'      => 'unknown',
            'mime_type' => '',
        ];
    }

    /**
     * Detect known embed services (YouTube, Vimeo, Dailymotion, SoundCloud).
     */
    public static function detectEmbedService(string $url): ?array
    {
        $parsed = parse_url($url);
        $host = strtolower($parsed['host'] ?? '');
        $path = $parsed['path'] ?? '';

        // YouTube
        if (str_contains($host, 'youtube.com') || str_contains($host, 'youtu.be')) {
            $videoId = null;
            if ($host === 'youtu.be') {
                $videoId = trim($path, '/');
            } elseif (str_contains($path, '/embed/')) {
                $videoId = basename($path);
            } elseif (str_contains($path, '/watch')) {
                parse_str($parsed['query'] ?? '', $query);
                $videoId = $query['v'] ?? null;
            } elseif (str_contains($path, '/shorts/')) {
                $videoId = basename($path);
            }

            if ($videoId && preg_match('/^[a-zA-Z0-9_\-]+$/', $videoId)) {
                return [
                    'service'   => 'youtube',
                    'embed_url' => "https://www.youtube-nocookie.com/embed/{$videoId}",
                ];
            }
        }

        // Vimeo
        if (str_contains($host, 'vimeo.com')) {
            if (preg_match('/(\d{5,15})/', $path, $matches)) {
                return [
                    'service'   => 'vimeo',
                    'embed_url' => "https://player.vimeo.com/video/{$matches[1]}",
                ];
            }
        }

        // Dailymotion
        if (str_contains($host, 'dailymotion.com') || str_contains($host, 'dai.ly')) {
            $videoCode = null;
            if ($host === 'dai.ly') {
                $videoCode = trim($path, '/');
            } elseif (preg_match('#/video/([a-zA-Z0-9]+)#', $path, $matches)) {
                $videoCode = $matches[1];
            }
            if ($videoCode) {
                return [
                    'service'   => 'dailymotion',
                    'embed_url' => "https://www.dailymotion.com/embed/video/{$videoCode}",
                ];
            }
        }

        // SoundCloud
        if (str_contains($host, 'soundcloud.com')) {
            $encodedUrl = urlencode($url);
            return [
                'service'   => 'soundcloud',
                'embed_url' => "https://w.soundcloud.com/player/?url={$encodedUrl}&color=%232563eb&auto_play=false&show_artwork=true",
            ];
        }

        return null;
    }

    private static function buildResolvedResult(string $urlOrPath, string $mode, string $type, ?array $detected): array
    {
        $playableUrl = $urlOrPath;
        $mimeType = $detected['mime_type'] ?? '';

        if ($type === 'embed') {
            $playableUrl = $detected['embed_url'] ?? $urlOrPath;
            $playerType = 'embed';
            // Embeds are not directly downloadable files
            $isDownloadable = false;
            $downloadMethod = 'none';
        } elseif ($type === 'hls') {
            $playerType = 'video';
            $mimeType = 'application/x-mpegURL';
            // M3U8 is streaming manifest: do not promise arbitrary segment download
            $isDownloadable = false;
            $downloadMethod = 'none';
        } elseif ($type === 'video') {
            $playerType = 'video';
            if ($mimeType === '') {
                $mimeType = 'video/mp4';
            }
            $isDownloadable = true;
            $downloadMethod = ($mode === 'upload') ? 'direct' : 'stream_proxy';
        } elseif ($type === 'audio') {
            $playerType = 'audio';
            if ($mimeType === '') {
                $mimeType = 'audio/mpeg';
            }
            $isDownloadable = true;
            $downloadMethod = ($mode === 'upload') ? 'direct' : 'stream_proxy';
        } else {
            // unknown
            $type = 'unknown';
            $playerType = 'none';
            $isDownloadable = false;
            $downloadMethod = 'none';
        }

        return [
            'valid'             => ($type !== 'unknown'),
            'source_mode'       => $mode,
            'source_type'       => $type,
            'player_type'       => $playerType,
            'playable_url'      => $playableUrl,
            'mime_type'         => $mimeType,
            'is_downloadable'   => $isDownloadable,
            'download_method'   => $downloadMethod,
            'error'             => ($type === 'unknown') ? 'Unknown Media Type. Please select source type manually.' : null,
        ];
    }
}


/**
 * Favorite Multimedia — Audio Player & Playlist Controller
 */

document.addEventListener('DOMContentLoaded', function () {
    const audioBoxes = document.querySelectorAll('.fav-audio-player-box');
    audioBoxes.forEach(initFavoriteAudioPlayer);
});

function initFavoriteAudioPlayer(box) {
    const audio = box.querySelector('audio');
    if (!audio) return;

    const playBtn = box.querySelector('.fav-audio-btn-play');
    const prevBtn = box.querySelector('.fav-audio-btn-prev');
    const nextBtn = box.querySelector('.fav-audio-btn-next');
    const shuffleBtn = box.querySelector('.fav-audio-btn-shuffle');
    const loopBtn = box.querySelector('.fav-audio-btn-loop');
    const statusNotice = box.querySelector('.fav-audio-status-notice');

    const progressContainer = box.querySelector('.fav-progress-bar-container');
    const progressBar = box.querySelector('.fav-progress-filled');
    const timeDisplay = box.querySelector('.fav-time-display');
    const volumeSlider = box.querySelector('.fav-volume-slider');

    const titleEl = box.querySelector('.fav-audio-title');
    const artistEl = box.querySelector('.fav-audio-artist');
    const artworkEl = box.querySelector('.fav-audio-artwork');
    const downloadLink = box.querySelector('.fav-audio-download-link');

    const playlistRows = box.querySelectorAll('.fav-playlist-row');
    let currentIndex = 0;
    let isShuffle = false;
    let isLoop = false;

    // Toggle Shuffle
    if (shuffleBtn) {
        shuffleBtn.addEventListener('click', () => {
            isShuffle = !isShuffle;
            shuffleBtn.style.opacity = isShuffle ? '1' : '0.6';
            shuffleBtn.style.color = isShuffle ? '#38bdf8' : '';
        });
    }

    // Toggle Loop
    if (loopBtn) {
        loopBtn.addEventListener('click', () => {
            isLoop = !isLoop;
            loopBtn.style.opacity = isLoop ? '1' : '0.6';
            loopBtn.style.color = isLoop ? '#38bdf8' : '';
        });
    }

    // Load initial track (find first accessible track if available)
    if (playlistRows.length > 0) {
        let firstIndex = 0;
        for (let i = 0; i < playlistRows.length; i++) {
            if (playlistRows[i].getAttribute('data-stream-url') && playlistRows[i].getAttribute('data-video-only') !== '1') {
                firstIndex = i;
                break;
            }
        }
        loadTrack(firstIndex, false);
    }

    // Play / Pause
    if (playBtn) {
        playBtn.addEventListener('click', () => {
            const row = playlistRows[currentIndex];
            const access = row ? (row.getAttribute('data-access') || 'ALLOW') : 'ALLOW';
            const streamUrl = row ? (row.getAttribute('data-stream-url') || '') : '';
            const isVideoOnly = row ? (row.getAttribute('data-video-only') === '1') : false;

            if (isVideoOnly) {
                showNotice('🎬 This track is a Music Video. Open the song page to watch.');
                return;
            }

            if (access !== 'ALLOW' || !streamUrl) {
                showNotice('🔒 Premium Membership required to play this track.');
                return;
            }

            if (audio.paused) {
                audio.play().catch(() => {});
                playBtn.innerHTML = '&#10074;&#10074;';
            } else {
                audio.pause();
                playBtn.innerHTML = '&#9654;';
            }
        });
    }

    audio.addEventListener('play', () => {
        if (playBtn) playBtn.innerHTML = '&#10074;&#10074;';
    });

    audio.addEventListener('pause', () => {
        if (playBtn) playBtn.innerHTML = '&#9654;';
    });

    // Auto next track
    audio.addEventListener('ended', () => {
        if (isLoop) {
            audio.currentTime = 0;
            audio.play().catch(() => {});
            return;
        }

        if (isShuffle && playlistRows.length > 1) {
            let nextIndex;
            do {
                nextIndex = Math.floor(Math.random() * playlistRows.length);
            } while (nextIndex === currentIndex);
            loadTrack(nextIndex, true);
            return;
        }

        if (currentIndex < playlistRows.length - 1) {
            loadTrack(currentIndex + 1, true);
        } else {
            loadTrack(0, false);
        }
    });

    // Next / Prev
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (isShuffle && playlistRows.length > 1) {
                const nextIndex = Math.floor(Math.random() * playlistRows.length);
                loadTrack(nextIndex, true);
                return;
            }

            if (currentIndex < playlistRows.length - 1) {
                loadTrack(currentIndex + 1, true);
            } else {
                loadTrack(0, true);
            }
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentIndex > 0) {
                loadTrack(currentIndex - 1, true);
            } else {
                loadTrack(playlistRows.length - 1, true);
            }
        });
    }

    // Playlist row click
    playlistRows.forEach((row, idx) => {
        row.addEventListener('click', () => {
            loadTrack(idx, true);
        });
    });

    function showNotice(msg) {
        if (statusNotice) {
            statusNotice.textContent = msg;
            statusNotice.style.display = 'block';
        }
    }

    function hideNotice() {
        if (statusNotice) {
            statusNotice.style.display = 'none';
        }
    }

    function loadTrack(index, autoPlay = true) {
        if (index < 0 || index >= playlistRows.length) return;
        currentIndex = index;

        playlistRows.forEach(r => r.classList.remove('fav-active-track'));
        const row = playlistRows[index];
        row.classList.add('fav-active-track');

        const streamUrl = row.getAttribute('data-stream-url') || '';
        const title = row.getAttribute('data-title') || '';
        const artist = row.getAttribute('data-artist') || '';
        const cover = row.getAttribute('data-cover') || '';
        const downloadUrl = row.getAttribute('data-download-url') || '';
        const canDownload = row.getAttribute('data-can-download') === '1';
        const access = row.getAttribute('data-access') || 'ALLOW';
        const isVideoOnly = row.getAttribute('data-video-only') === '1';

        if (titleEl) titleEl.textContent = title;
        if (artistEl) artistEl.textContent = artist;
        if (artworkEl && cover) artworkEl.src = cover;

        if (downloadLink) {
            if (canDownload && downloadUrl && !isVideoOnly) {
                downloadLink.style.display = 'inline-flex';
                downloadLink.href = downloadUrl;
            } else {
                downloadLink.style.display = 'none';
            }
        }

        if (isVideoOnly) {
            showNotice('🎬 "' + title + '" is a Music Video. Open song page to watch.');
            audio.pause();
            audio.src = '';
            if (playBtn) playBtn.innerHTML = '&#9654;';
            if (progressBar) progressBar.style.width = '0%';
            if (timeDisplay) timeDisplay.textContent = '0:00 / 0:00';
            if (autoPlay) {
                setTimeout(() => {
                    if (currentIndex < playlistRows.length - 1) {
                        loadTrack(currentIndex + 1, true);
                    } else {
                        loadTrack(0, false);
                    }
                }, 1200);
            }
            return;
        }

        if (access !== 'ALLOW' || !streamUrl) {
            showNotice('🔒 Premium Membership required to stream this track.');
            audio.pause();
            audio.src = '';
            if (playBtn) playBtn.innerHTML = '&#9654;';
            if (progressBar) progressBar.style.width = '0%';
            if (timeDisplay) timeDisplay.textContent = '0:00 / 0:00';
            return;
        }

        hideNotice();
        audio.src = streamUrl;
        if (autoPlay) {
            audio.play().catch(() => {});
        }
    }

    // Progress & Time
    audio.addEventListener('timeupdate', () => {
        if (audio.duration) {
            const percent = (audio.currentTime / audio.duration) * 100;
            if (progressBar) progressBar.style.width = percent + '%';
            if (timeDisplay) {
                const cur = formatTime(audio.currentTime);
                const dur = formatTime(audio.duration);
                timeDisplay.textContent = `${cur} / ${dur}`;
            }
        }
    });

    if (progressContainer) {
        progressContainer.addEventListener('click', (e) => {
            const rect = progressContainer.getBoundingClientRect();
            const pos = (e.clientX - rect.left) / rect.width;
            if (audio.duration) {
                audio.currentTime = pos * audio.duration;
            }
        });
    }

    // Volume
    if (volumeSlider) {
        volumeSlider.addEventListener('input', (e) => {
            audio.volume = parseFloat(e.target.value);
        });
    }

    function formatTime(sec) {
        sec = Math.floor(sec || 0);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    // Song Playback Progress Reporting (Phase 5)
    let lastSongPing = 0;
    function reportSongProgress(isCompleted = false) {
        const row = playlistRows[currentIndex];
        if (!row) return;
        const songId = parseInt(row.getAttribute('data-song-id'), 10);
        if (!songId || isNaN(songId)) return;

        const currentPos = audio.currentTime || 0;
        const totalDuration = audio.duration || 0;

        fetch('/multimedia/api/progress', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                content_type: 'song',
                content_id: songId,
                position: currentPos,
                duration: totalDuration,
                is_completed: isCompleted ? 1 : 0
            })
        }).catch(() => {});
    }

    audio.addEventListener('timeupdate', () => {
        const now = audio.currentTime;
        if (Math.abs(now - lastSongPing) >= 15) {
            lastSongPing = now;
            reportSongProgress(false);
        }
    });

    audio.addEventListener('pause', () => {
        if (!audio.ended) {
            reportSongProgress(false);
        }
    });

    audio.addEventListener('ended', () => {
        reportSongProgress(true);
    });
}

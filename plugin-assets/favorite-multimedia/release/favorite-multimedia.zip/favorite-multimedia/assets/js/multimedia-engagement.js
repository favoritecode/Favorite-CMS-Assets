/**
 * Favorite Multimedia — Community Engagement Client
 *
 * Manages star rating, reviews, discussion comments, and community reporting.
 */
document.addEventListener('DOMContentLoaded', function() {
    const container = document.querySelector('.fav-engagement-container');
    if (!container) return;

    const contentType = container.dataset.contentType;
    const contentId = parseInt(container.dataset.contentId, 10);
    const csrfToken = container.dataset.csrf || '';

    function getCsrf() {
        return csrfToken || (document.querySelector('input[name="_token"]') ? document.querySelector('input[name="_token"]').value : '');
    }

    // 1. Star Rating
    const starBtns = container.querySelectorAll('.fav-star-btn');
    starBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const star = parseInt(this.dataset.star, 10);
            if (!star || isNaN(star)) return;

            fetch('/multimedia/api/rate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    content_type: contentType,
                    content_id: contentId,
                    rating: star
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    starBtns.forEach(b => {
                        const s = parseInt(b.dataset.star, 10);
                        if (s <= data.user_rating) {
                            b.classList.add('active');
                        } else {
                            b.classList.remove('active');
                        }
                    });

                    const avgEl = document.getElementById('fmm-avg-rating');
                    const cntEl = document.getElementById('fmm-rating-count');
                    if (avgEl) avgEl.textContent = data.average_rating ? Number(data.average_rating).toFixed(1) : '—';
                    if (cntEl) cntEl.textContent = data.rating_count === 1 ? '1 rating' : data.rating_count + ' ratings';

                    // Add clear button if missing
                    let clearBtn = document.getElementById('fmm-clear-rating');
                    if (!clearBtn) {
                        clearBtn = document.createElement('button');
                        clearBtn.id = 'fmm-clear-rating';
                        clearBtn.type = 'button';
                        clearBtn.className = 'fav-clear-rate-btn';
                        clearBtn.title = 'Remove rating';
                        clearBtn.innerHTML = '&times;';
                        btn.parentElement.appendChild(clearBtn);
                        attachClearHandler(clearBtn);
                    }
                } else if (data.status === 'unauthenticated') {
                    window.location.href = '/login?return=' + encodeURIComponent(window.location.pathname);
                } else {
                    alert(data.error || 'Failed to update rating.');
                }
            })
            .catch(() => alert('Network error submitting rating.'));
        });
    });

    function attachClearHandler(btn) {
        btn.addEventListener('click', function() {
            fetch('/multimedia/api/rate/remove', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    content_type: contentType,
                    content_id: contentId
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    starBtns.forEach(b => b.classList.remove('active'));
                    const avgEl = document.getElementById('fmm-avg-rating');
                    const cntEl = document.getElementById('fmm-rating-count');
                    if (avgEl) avgEl.textContent = data.average_rating ? Number(data.average_rating).toFixed(1) : '—';
                    if (cntEl) cntEl.textContent = data.rating_count === 1 ? '1 rating' : data.rating_count + ' ratings';
                    btn.remove();
                }
            });
        });
    }

    const initialClearBtn = document.getElementById('fmm-clear-rating');
    if (initialClearBtn) attachClearHandler(initialClearBtn);

    // 2. Reviews Toggle Form & Submission
    const toggleReviewBtn = document.getElementById('fmm-toggle-review-form');
    const reviewFormCard = document.getElementById('fmm-review-form');
    const cancelReviewBtn = document.getElementById('fmm-cancel-review');

    if (toggleReviewBtn && reviewFormCard) {
        toggleReviewBtn.addEventListener('click', () => {
            reviewFormCard.style.display = (reviewFormCard.style.display === 'none') ? 'block' : 'none';
        });
    }

    if (cancelReviewBtn && reviewFormCard) {
        cancelReviewBtn.addEventListener('click', () => {
            reviewFormCard.style.display = 'none';
        });
    }

    const reviewForm = document.getElementById('fmm-submit-review');
    if (reviewForm) {
        reviewForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const title = reviewForm.querySelector('input[name="title"]').value.trim();
            const body = reviewForm.querySelector('textarea[name="body"]').value.trim();
            const isSpoiler = reviewForm.querySelector('input[name="contains_spoiler"]').checked;

            if (body.length < 3) {
                alert('Review body must be at least 3 characters.');
                return;
            }

            fetch('/multimedia/api/review', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    content_type: contentType,
                    content_id: contentId,
                    title: title,
                    body: body,
                    contains_spoiler: isSpoiler
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message || 'Review submitted successfully!');
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to submit review.');
                }
            })
            .catch(() => alert('Network error submitting review.'));
        });
    }

    // 3. Spoilers Reveal
    container.addEventListener('click', function(e) {
        if (e.target.classList.contains('fav-reveal-spoiler-btn')) {
            const card = e.target.closest('.fav-review-card');
            if (card) {
                const banner = card.querySelector('.fav-spoiler-banner');
                const content = card.querySelector('.fav-spoiler-content');
                if (banner) banner.style.display = 'none';
                if (content) content.style.display = 'block';
            }
        }
    });

    // 4. Helpful Vote
    container.addEventListener('click', function(e) {
        const btn = e.target.closest('.fav-helpful-btn');
        if (!btn) return;
        const reviewId = btn.dataset.id;
        if (!reviewId) return;

        fetch('/multimedia/api/review/' + reviewId + '/helpful', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': getCsrf()
            },
            body: JSON.stringify({ _token: getCsrf() })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.voted) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
                const countSpan = btn.querySelector('.fmm-helpful-count');
                if (countSpan) countSpan.textContent = data.helpful_count;
            } else if (data.status === 'unauthenticated') {
                window.location.href = '/login?return=' + encodeURIComponent(window.location.pathname);
            }
        });
    });

    // 5. Delete Review
    container.addEventListener('click', function(e) {
        const btn = e.target.closest('.fmm-delete-review');
        if (!btn) return;
        const id = btn.dataset.id;
        if (!id || !confirm('Are you sure you want to delete your review?')) return;

        fetch('/multimedia/api/review/' + id + '/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': getCsrf()
            },
            body: JSON.stringify({ _token: getCsrf() })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const card = btn.closest('.fav-review-card');
                if (card) card.remove();
            } else {
                alert(data.error || 'Failed to delete review.');
            }
        });
    });

    // 6. Discussion Comments
    const commentForm = document.getElementById('fmm-post-comment-form');
    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const bodyInput = commentForm.querySelector('textarea[name="body"]');
            const body = bodyInput.value.trim();
            if (!body) return;

            fetch('/multimedia/api/comment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    content_type: contentType,
                    content_id: contentId,
                    body: body
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to post comment.');
                }
            });
        });
    }

    // 7. Comment Reply
    container.addEventListener('click', function(e) {
        const btn = e.target.closest('.fmm-reply-trigger');
        if (!btn) return;
        const parentId = btn.dataset.parentId;
        const thread = btn.closest('.fav-comment-thread');
        if (!thread || !parentId) return;

        let existingForm = thread.querySelector('.fav-reply-composer');
        if (existingForm) {
            existingForm.remove();
            return;
        }

        const composer = document.createElement('form');
        composer.className = 'fav-reply-composer';
        composer.innerHTML = `
            <textarea name="reply_body" placeholder="Write a reply..." class="fav-form-textarea" rows="2" required maxlength="1000"></textarea>
            <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:6px;">
                <button type="button" class="fav-btn-secondary fmm-cancel-reply">Cancel</button>
                <button type="submit" class="fav-btn-primary">Post Reply</button>
            </div>
        `;
        thread.appendChild(composer);

        composer.querySelector('.fmm-cancel-reply').addEventListener('click', () => composer.remove());
        composer.addEventListener('submit', function(ev) {
            ev.preventDefault();
            const replyText = composer.querySelector('textarea').value.trim();
            if (!replyText) return;

            fetch('/multimedia/api/comment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    content_type: contentType,
                    content_id: contentId,
                    parent_id: parseInt(parentId, 10),
                    body: replyText
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to post reply.');
                }
            });
        });
    });

    // 8. Delete Comment
    container.addEventListener('click', function(e) {
        const btn = e.target.closest('.fmm-delete-comment');
        if (!btn) return;
        const id = btn.dataset.id;
        if (!id || !confirm('Are you sure you want to delete this comment?')) return;

        fetch('/multimedia/api/comment/' + id + '/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': getCsrf()
            },
            body: JSON.stringify({ _token: getCsrf() })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const card = btn.closest('.fav-comment-card') || btn.closest('.fav-comment-thread');
                if (card) card.remove();
            } else {
                alert(data.error || 'Failed to delete comment.');
            }
        });
    });

    // 9. Reporting Modal
    const reportModal = document.getElementById('fmm-report-modal');
    const reportForm = document.getElementById('fmm-report-form');
    const closeReportBtn = document.getElementById('fmm-close-report-modal');

    container.addEventListener('click', function(e) {
        const btn = e.target.closest('.fmm-report-btn');
        if (!btn || !reportModal) return;
        const targetType = btn.dataset.targetType;
        const targetId = btn.dataset.targetId;

        document.getElementById('fmm-report-target-type').value = targetType;
        document.getElementById('fmm-report-target-id').value = targetId;
        reportModal.style.display = 'flex';
    });

    if (closeReportBtn && reportModal) {
        closeReportBtn.addEventListener('click', () => {
            reportModal.style.display = 'none';
        });
    }

    if (reportForm && reportModal) {
        reportForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const targetType = document.getElementById('fmm-report-target-type').value;
            const targetId = parseInt(document.getElementById('fmm-report-target-id').value, 10);
            const reason = reportForm.querySelector('select[name="reason"]').value;
            const notes = reportForm.querySelector('textarea[name="notes"]').value.trim();

            fetch('/multimedia/api/report', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    target_type: targetType,
                    target_id: targetId,
                    reason: reason,
                    notes: notes
                })
            })
            .then(res => res.json())
            .then(data => {
                reportModal.style.display = 'none';
                if (data.success) {
                    alert('Thank you for reporting this. Our moderation team will inspect it.');
                } else if (data.duplicate) {
                    alert('You have already reported this item.');
                } else {
                    alert(data.error || 'Failed to submit report.');
                }
            });
        });
    }
});

/* -------------------------------------------------------------
   Phase 8: Subscriptions & Notifications Handlers
------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function() {
    function getCsrf() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        if (meta && meta.content) return meta.content;
        const input = document.querySelector('input[name="_token"]');
        if (input && input.value) return input.value;
        const container = document.querySelector('.fav-engagement-container');
        if (container && container.dataset.csrf) return container.dataset.csrf;
        return '';
    }

    // 1. Follow / Subscribe Toggle Buttons
    document.querySelectorAll('[data-fmm-subscribe-toggle]').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const targetType = this.dataset.targetType;
            const targetId = parseInt(this.dataset.targetId, 10);
            if (!targetType || !targetId) return;

            const iconEl = this.querySelector('.fmm-follow-icon');
            const labelEl = this.querySelector('.fmm-follow-label');
            const wasActive = this.classList.contains('active');

            fetch('/multimedia/api/subscribe/toggle', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({
                    _token: getCsrf(),
                    target_type: targetType,
                    target_id: targetId
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (data.is_following) {
                        btn.classList.add('active');
                        if (iconEl) iconEl.textContent = '✓';
                        if (labelEl) labelEl.textContent = 'Following';
                    } else {
                        btn.classList.remove('active');
                        if (iconEl) iconEl.textContent = '+';
                        const typeLabel = targetType.charAt(0).toUpperCase() + targetType.slice(1);
                        if (labelEl) labelEl.textContent = 'Follow ' + typeLabel;
                    }
                } else if (data.status === 'unauthenticated') {
                    window.location.href = '/login';
                } else {
                    alert(data.error || 'Failed to update follow status.');
                }
            })
            .catch(() => alert('Network error. Please try again.'));
        });
    });

    // 2. Mark Single Notification Read
    document.querySelectorAll('[data-fmm-read-action]').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const notifId = parseInt(this.dataset.fmmReadAction, 10);
            if (!notifId) return;

            const itemEl = this.closest('.fmm-notification-item');

            fetch('/multimedia/api/notifications/' + notifId + '/read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({ _token: getCsrf() })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (itemEl) {
                        itemEl.classList.remove('unread');
                        itemEl.classList.add('read');
                    }
                    btn.remove();
                    updateBadge(data.unread_badge);
                }
            });
        });
    });

    // 3. Mark All Notifications Read
    const markAllBtn = document.getElementById('fmm-mark-all-read-btn');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (!confirm('Mark all notifications as read?')) return;

            fetch('/multimedia/api/notifications/mark-all-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': getCsrf()
                },
                body: JSON.stringify({ _token: getCsrf() })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.querySelectorAll('.fmm-notification-item.unread').forEach(el => {
                        el.classList.remove('unread');
                        el.classList.add('read');
                    });
                    document.querySelectorAll('[data-fmm-read-action]').forEach(b => b.remove());
                    markAllBtn.remove();
                    updateBadge('0');
                }
            });
        });
    }

    // 4. Preferences Modal
    const prefsModal = document.getElementById('fmm-prefs-modal');
    const openPrefsBtn = document.getElementById('fmm-open-prefs-btn');
    const closePrefsBtn = document.getElementById('fmm-close-prefs-btn');
    const cancelPrefsBtn = document.getElementById('fmm-cancel-prefs-btn');
    const prefsForm = document.getElementById('fmm-prefs-form');

    if (prefsModal && openPrefsBtn) {
        openPrefsBtn.addEventListener('click', () => { prefsModal.style.display = 'flex'; });
        if (closePrefsBtn) closePrefsBtn.addEventListener('click', () => { prefsModal.style.display = 'none'; });
        if (cancelPrefsBtn) cancelPrefsBtn.addEventListener('click', () => { prefsModal.style.display = 'none'; });

        if (prefsForm) {
            prefsForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(prefsForm);
                const prefs = {
                    notify_content_updates: formData.has('notify_content_updates'),
                    notify_engagement_replies: formData.has('notify_engagement_replies'),
                    notify_moderation_updates: formData.has('notify_moderation_updates')
                };

                fetch('/multimedia/api/notification-preferences', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': getCsrf()
                    },
                    body: JSON.stringify({
                        _token: getCsrf(),
                        preferences: prefs
                    })
                })
                .then(res => res.json())
                .then(data => {
                    prefsModal.style.display = 'none';
                    if (data.success) {
                        alert('Notification preferences saved.');
                    } else {
                        alert('Failed to save preferences.');
                    }
                });
            });
        }
    }

    function updateBadge(badgeText) {
        const badge = document.getElementById('fmm-main-unread-badge');
        if (badge) {
            if (!badgeText || badgeText === '0') {
                badge.style.display = 'none';
            } else {
                badge.style.display = 'inline-flex';
                badge.textContent = badgeText;
            }
        }
    }
});

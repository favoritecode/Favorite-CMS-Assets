/**
 * Favorite Multimedia — Responsive Video Player Engine
 */

document.addEventListener('DOMContentLoaded', function () {
    const players = document.querySelectorAll('.fav-video-wrapper');
    players.forEach(initFavoriteVideoPlayer);
});

function initFavoriteVideoPlayer(wrapper) {
    let sources = [];
    try {
        const rawSources = wrapper.getAttribute('data-sources');
        if (rawSources) {
            sources = JSON.parse(rawSources);
        }
    } catch (e) {
        sources = [];
    }

    let activeSource = (sources.length > 0)
        ? (sources.find(s => s.is_default) || sources[0])
        : null;
    const triedSourceIds = new Set();
    if (activeSource) triedSourceIds.add(activeSource.id);

    let video = wrapper.querySelector('video.fav-video-element');
    let iframe = wrapper.querySelector('iframe.fav-embed-element');
    const controls = wrapper.querySelector('.fav-player-controls');

    if (!video && !iframe && sources.length === 0) return;

    let hlsInstance = null;

    const playBtn = wrapper.querySelector('.fav-btn-play');
    const playIcon = playBtn ? playBtn.querySelector('.fav-icon-play') : null;
    const pauseIcon = playBtn ? playBtn.querySelector('.fav-icon-pause') : null;

    const progressContainer = wrapper.querySelector('.fav-progress-bar-container');
    const progressBar = wrapper.querySelector('.fav-progress-filled');
    const timeDisplay = wrapper.querySelector('.fav-time-display');

    const volumeBtn = wrapper.querySelector('.fav-btn-volume');
    const volumeSlider = wrapper.querySelector('.fav-volume-slider');
    const speedSelect = wrapper.querySelector('.fav-speed-select');
    const qualitySelect = wrapper.querySelector('.fav-quality-select');
    const sourceSelect = wrapper.querySelector('.fav-source-select');
    const subtitleSelect = wrapper.querySelector('.fav-subtitle-select');
    const fullscreenBtn = wrapper.querySelector('.fav-btn-fullscreen');

    let isSeeking = false;
    let hideControlsTimeout = null;

    // 1. Play / Pause
    if (playBtn) {
        playBtn.addEventListener('click', togglePlay);
    }
    if (video) {
        video.addEventListener('click', togglePlay);
    }

    function togglePlay() {
        if (!video) return;
        if (video.paused || video.ended) {
            video.play().catch(() => {});
        } else {
            video.pause();
        }
    }

    if (video) {
        video.addEventListener('play', () => {
            if (playIcon) playIcon.style.display = 'none';
            if (pauseIcon) pauseIcon.style.display = 'inline-block';
            resetHideTimer();
        });

        video.addEventListener('pause', () => {
            if (playIcon) playIcon.style.display = 'inline-block';
            if (pauseIcon) pauseIcon.style.display = 'none';
            wrapper.classList.remove('fav-controls-hidden');
        });

        // 2. Progress & Time
        video.addEventListener('timeupdate', () => {
            if (!isSeeking && video.duration) {
                const percent = (video.currentTime / video.duration) * 100;
                if (progressBar) progressBar.style.width = percent + '%';
                updateTimeDisplay();
            }
        });

        video.addEventListener('loadedmetadata', () => {
            updateTimeDisplay();
        });
    }

    function updateTimeDisplay() {
        if (!timeDisplay || !video) return;
        const cur = formatTime(video.currentTime || 0);
        const dur = formatTime(video.duration || 0);
        timeDisplay.textContent = `${cur} / ${dur}`;
    }

    function formatTime(sec) {
        sec = Math.floor(sec);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        const h = Math.floor(m / 60);
        const remainM = m % 60;
        if (h > 0) {
            return `${h}:${remainM < 10 ? '0' : ''}${remainM}:${s < 10 ? '0' : ''}${s}`;
        }
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    // Scrubbing / Seek
    if (progressContainer && video) {
        progressContainer.addEventListener('click', (e) => {
            const rect = progressContainer.getBoundingClientRect();
            const pos = (e.clientX - rect.left) / rect.width;
            if (video.duration) {
                video.currentTime = pos * video.duration;
            }
        });
    }

    // 3. Volume
    if (volumeSlider && video) {
        volumeSlider.addEventListener('input', (e) => {
            video.volume = parseFloat(e.target.value);
            video.muted = (video.volume === 0);
        });
    }
    if (volumeBtn && video) {
        volumeBtn.addEventListener('click', () => {
            video.muted = !video.muted;
            if (volumeSlider) {
                volumeSlider.value = video.muted ? 0 : video.volume;
            }
        });
    }

    // 4. Speed
    if (speedSelect && video) {
        speedSelect.addEventListener('change', (e) => {
            video.playbackRate = parseFloat(e.target.value);
        });
    }

    // 5. Playback Source Switcher & Quality Switcher (v1.0.3)
    if (sourceSelect) {
        if (sources.length <= 1) {
            sourceSelect.style.display = 'none';
        } else {
            sourceSelect.style.display = 'inline-block';
            sourceSelect.addEventListener('change', (e) => {
                switchPlaybackSource(parseInt(e.target.value, 10), true);
            });
        }
    }

    if (qualitySelect && video) {
        qualitySelect.addEventListener('change', (e) => {
            const newUrl = e.target.value;
            const currentTime = video.currentTime;
            const wasPlaying = !video.paused;

            video.src = newUrl;
            video.currentTime = currentTime;
            if (wasPlaying) {
                video.play();
            }
        });
    }

    // 6. Subtitles & Language Preferences
    if (subtitleSelect && video) {
        subtitleSelect.addEventListener('change', (e) => {
            const lang = e.target.value;
            for (let i = 0; i < video.textTracks.length; i++) {
                const track = video.textTracks[i];
                if (lang === 'off') {
                    track.mode = 'disabled';
                } else if (track.language === lang || track.label === lang) {
                    track.mode = 'showing';
                } else {
                    track.mode = 'disabled';
                }
            }
            try {
                fetch('/multimedia/api/user-language-preferences', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        preferred_subtitle_language: lang === 'off' ? null : lang,
                        subtitle_enabled: lang !== 'off'
                    })
                }).catch(() => {});
            } catch (err) {}
        });
    }

    const audioSelect = wrapper.querySelector('.fav-audio-select');
    if (audioSelect) {
        audioSelect.addEventListener('change', (e) => {
            const lang = e.target.value;
            try {
                fetch('/multimedia/api/user-language-preferences', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        preferred_audio_language: lang
                    })
                }).catch(() => {});
            } catch (err) {}
        });
    }

    // 7. Fullscreen
    if (fullscreenBtn) {
        fullscreenBtn.addEventListener('click', () => {
            if (!document.fullscreenElement) {
                if (wrapper.requestFullscreen) {
                    wrapper.requestFullscreen();
                } else if (video && video.webkitEnterFullscreen) {
                    video.webkitEnterFullscreen();
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
            }
        });
    }

    // 8. Auto-hide controls
    wrapper.addEventListener('mousemove', resetHideTimer);
    wrapper.addEventListener('touchstart', resetHideTimer);

    function resetHideTimer() {
        wrapper.classList.remove('fav-controls-hidden');
        clearTimeout(hideControlsTimeout);
        if (video && !video.paused) {
            hideControlsTimeout = setTimeout(() => {
                wrapper.classList.add('fav-controls-hidden');
            }, 3000);
        }
    }

    // 9. Keyboard Controls
    wrapper.setAttribute('tabindex', '0');
    wrapper.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;
        if (!video) return;
        switch (e.key) {
            case ' ':
            case 'k':
            case 'K':
                e.preventDefault();
                togglePlay();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                video.currentTime = Math.max(0, video.currentTime - 5);
                break;
            case 'ArrowRight':
                e.preventDefault();
                if (video.duration) {
                    video.currentTime = Math.min(video.duration, video.currentTime + 5);
                }
                break;
            case 'ArrowUp':
                e.preventDefault();
                video.volume = Math.min(1, Math.round((video.volume + 0.1) * 10) / 10);
                if (volumeSlider) volumeSlider.value = video.volume;
                break;
            case 'ArrowDown':
                e.preventDefault();
                video.volume = Math.max(0, Math.round((video.volume - 0.1) * 10) / 10);
                if (volumeSlider) volumeSlider.value = video.volume;
                break;
            case 'm':
            case 'M':
                video.muted = !video.muted;
                if (volumeSlider) volumeSlider.value = video.muted ? 0 : video.volume;
                break;
            case 'f':
            case 'F':
                if (fullscreenBtn) fullscreenBtn.click();
                break;
        }
    });

    // 10. Multi-Source Streaming, Embed Switching & Failover (v1.0.3)
    function showFailoverBanner(message) {
        let toast = wrapper.querySelector('.fav-failover-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'fav-failover-toast';
            toast.style.cssText = 'position: absolute; top: 16px; left: 50%; transform: translateX(-50%); background: rgba(30, 58, 138, 0.95); color: #fff; padding: 8px 18px; border-radius: 6px; font-size: 13px; font-weight: 600; z-index: 100; box-shadow: 0 4px 14px rgba(0,0,0,0.4); pointer-events: none; transition: opacity 0.4s ease; border: 1px solid #3b82f6;';
            wrapper.appendChild(toast);
        }
        toast.textContent = message;
        toast.style.opacity = '1';
        toast.style.display = 'block';
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => { toast.style.display = 'none'; }, 400);
        }, 5000);
    }

    function showExhaustionBanner() {
        let card = wrapper.querySelector('.fav-exhaustion-card');
        if (!card) {
            card = document.createElement('div');
            card.className = 'fav-exhaustion-card';
            card.style.cssText = 'position: absolute; inset: 0; background: rgba(15, 23, 42, 0.96); display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 90; padding: 24px; text-align: center;';
            card.innerHTML = `
                <div style="font-size: 38px; margin-bottom: 8px;">⚠️</div>
                <h3 style="color: #f8fafc; font-size: 18px; margin: 0 0 8px 0; font-weight: 700;">This video is temporarily unavailable</h3>
                <p style="color: #94a3b8; font-size: 14px; max-width: 440px; margin: 0;">We were unable to load playback from available servers. Try another source or check back later.</p>
            `;
            wrapper.appendChild(card);
        }
        card.style.display = 'flex';
    }

    function ensureFloatingSourceSwitcher(currentId) {
        if (sources.length <= 1) return;
        let floatBar = wrapper.querySelector('.fav-embed-source-switcher');
        if (!floatBar) {
            floatBar = document.createElement('div');
            floatBar.className = 'fav-embed-source-switcher';
            floatBar.style.cssText = 'position: absolute; top: 12px; right: 12px; z-index: 80; background: rgba(15,23,42,0.85); padding: 4px 8px; border-radius: 6px; border: 1px solid #334155; display: flex; align-items: center; gap: 6px;';
            floatBar.innerHTML = `<span style="font-size:11px; font-weight:600; color:#94a3b8;">Source:</span><select class="fav-float-select" style="background:#1e293b; color:#f8fafc; border:1px solid #475569; font-size:12px; padding:2px 6px; border-radius:4px; cursor:pointer;"></select>`;
            wrapper.appendChild(floatBar);
            const sel = floatBar.querySelector('.fav-float-select');
            sources.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id;
                opt.textContent = s.label;
                sel.appendChild(opt);
            });
            sel.addEventListener('change', (e) => {
                switchPlaybackSource(parseInt(e.target.value, 10), true);
            });
        }
        const sel = floatBar.querySelector('.fav-float-select');
        if (sel) sel.value = currentId;
        floatBar.style.display = 'flex';
    }

    function removeFloatingSourceSwitcher() {
        const floatBar = wrapper.querySelector('.fav-embed-source-switcher');
        if (floatBar) floatBar.style.display = 'none';
    }

    function failoverToNextSource(reason) {
        if (!sources || sources.length === 0) return;
        const candidate = sources.find(s => !triedSourceIds.has(s.id) && s.can_auto_failover !== false);
        if (candidate) {
            triedSourceIds.add(candidate.id);
            showFailoverBanner(`Main source unavailable. Switched to ${candidate.label}`);
            switchPlaybackSource(candidate.id, false);
        } else {
            showExhaustionBanner();
        }
    }

    function attachHls(url, seekTime = 0) {
        if (!video) return;
        if (hlsInstance) {
            hlsInstance.destroy();
            hlsInstance = null;
        }

        if (video.canPlayType('application/vnd.apple.mpegurl')) {
            video.src = url;
            if (seekTime > 0) {
                video.addEventListener('loadedmetadata', function onMeta() {
                    video.currentTime = seekTime;
                    video.removeEventListener('loadedmetadata', onMeta);
                }, { once: true });
            }
        } else if (window.Hls && window.Hls.isSupported()) {
            hlsInstance = new window.Hls();
            hlsInstance.loadSource(url);
            hlsInstance.attachMedia(video);
            hlsInstance.on(window.Hls.Events.MANIFEST_PARSED, () => {
                if (seekTime > 0) {
                    video.currentTime = seekTime;
                }
            });
            hlsInstance.on(window.Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    switch (data.type) {
                        case window.Hls.ErrorTypes.NETWORK_ERROR:
                            hlsInstance.startLoad();
                            break;
                        case window.Hls.ErrorTypes.MEDIA_ERROR:
                            hlsInstance.recoverMediaError();
                            break;
                        default:
                            hlsInstance.destroy();
                            hlsInstance = null;
                            failoverToNextSource('HLS fatal playback error');
                            break;
                    }
                }
            });
        } else {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/hls.js@latest';
            script.onload = () => {
                if (window.Hls && window.Hls.isSupported()) {
                    attachHls(url, seekTime);
                }
            };
            document.head.appendChild(script);
        }
    }

    function switchPlaybackSource(targetId, userInitiated) {
        const target = sources.find(s => s.id === targetId);
        if (!target) return;

        const currentTime = (video && !isNaN(video.currentTime)) ? video.currentTime : 0;
        const wasPlaying = (video && !video.paused && !video.ended);

        if (hlsInstance) {
            hlsInstance.destroy();
            hlsInstance = null;
        }

        if (target.player_type === 'embed') {
            if (video) {
                video.pause();
                video.style.display = 'none';
            }
            if (controls) controls.style.display = 'none';

            if (!iframe) {
                iframe = document.createElement('iframe');
                iframe.className = 'fav-embed-element';
                iframe.setAttribute('allowfullscreen', '');
                iframe.setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');
                iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation allow-fullscreen');
                wrapper.prepend(iframe);
            }
            iframe.style.display = 'block';
            iframe.src = target.url;
            ensureFloatingSourceSwitcher(target.id);
        } else {
            if (iframe) {
                iframe.style.display = 'none';
                iframe.src = '';
            }
            if (video) {
                video.style.display = 'block';
            }
            if (controls) controls.style.display = 'block';

            removeFloatingSourceSwitcher();

            if (target.player_type === 'hls') {
                attachHls(target.url, currentTime);
                if (wasPlaying || userInitiated) {
                    video.play().catch(() => {});
                }
            } else {
                if (video) {
                    video.src = target.url;
                    video.load();
                    if (currentTime > 0) {
                        video.addEventListener('loadedmetadata', function onMeta() {
                            video.currentTime = currentTime;
                            video.removeEventListener('loadedmetadata', onMeta);
                        }, { once: true });
                    }
                    if (wasPlaying || userInitiated) {
                        video.play().catch(() => {});
                    }
                }
            }
        }

        activeSource = target;
        if (sourceSelect) {
            sourceSelect.value = target.id;
        }
        const floatSel = wrapper.querySelector('.fav-float-select');
        if (floatSel) {
            floatSel.value = target.id;
        }
    }

    if (video) {
        video.addEventListener('error', () => {
            if (video.error && [2, 3, 4].includes(video.error.code)) {
                failoverToNextSource(`HTML5 video error ${video.error.code}`);
            }
        });
    }

    // Initial stream load
    const hlsSrc = wrapper.getAttribute('data-hls-src') || (activeSource && activeSource.player_type === 'hls' ? activeSource.url : null);
    if (hlsSrc && video) {
        attachHls(hlsSrc, 0);
    }
    if (iframe && sources.length > 1) {
        ensureFloatingSourceSwitcher(activeSource ? activeSource.id : 0);
    }

    // 11. Playback Progress & Resuming (Phase 5)
    const contentType = wrapper.getAttribute('data-content-type');
    const contentId = parseInt(wrapper.getAttribute('data-content-id'), 10);
    const resumePosition = parseFloat(wrapper.getAttribute('data-resume-position') || 0);

    let hasResumed = false;
    const resumePrompt = document.getElementById('fmm-resume-prompt');
    const resumeAcceptBtn = document.getElementById('fmm-resume-accept-btn');
    const resumeStartOverBtn = document.getElementById('fmm-resume-start-over-btn');

    if (resumeAcceptBtn) {
        resumeAcceptBtn.addEventListener('click', () => {
            if (resumePosition > 0) {
                video.currentTime = resumePosition;
            }
            if (resumePrompt) resumePrompt.style.display = 'none';
            video.play().catch(() => {});
        });
    }

    if (resumeStartOverBtn) {
        resumeStartOverBtn.addEventListener('click', () => {
            video.currentTime = 0;
            if (resumePrompt) resumePrompt.style.display = 'none';
            video.play().catch(() => {});
        });
    }

    video.addEventListener('loadedmetadata', () => {
        if (!hasResumed && resumePosition > 0 && !resumeAcceptBtn) {
            // Auto seek if no explicit banner button is present
            video.currentTime = resumePosition;
            hasResumed = true;
        }
    });

    let lastProgressPing = 0;
    function reportProgress(isCompleted = false) {
        if (!contentType || !contentId || isNaN(contentId)) return;
        const currentPos = video.currentTime || 0;
        const totalDuration = video.duration || 0;

        fetch('/multimedia/api/progress', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                content_type: contentType,
                content_id: contentId,
                position: currentPos,
                duration: totalDuration,
                is_completed: isCompleted ? 1 : 0
            })
        }).catch(() => {});
    }

    // Ping every 15s during playback
    video.addEventListener('timeupdate', () => {
        const now = video.currentTime;
        if (Math.abs(now - lastProgressPing) >= 15) {
            lastProgressPing = now;
            reportProgress(false);
        }
    });

    video.addEventListener('pause', () => {
        if (!video.ended) {
            reportProgress(false);
        }
    });

    video.addEventListener('seeked', () => {
        reportProgress(false);
    });

    video.addEventListener('ended', () => {
        reportProgress(true);
        handleNextEpisode();
    });

    // 12. Next Episode Auto-Prompt on Ended
    function handleNextEpisode() {
        if (contentType !== 'episode') return;
        const nextUrl = wrapper.getAttribute('data-next-episode-url');
        const nextTitle = wrapper.getAttribute('data-next-episode-title');

        if (nextUrl) {
            showNextEpisodeOverlay(nextTitle || 'Next Episode', nextUrl);
            return;
        }

        // Otherwise fetch dynamically
        fetch(`/multimedia/api/next-episode/${contentId}`)
            .then(res => res.json())
            .then(data => {
                if (data.has_next && data.next_episode && data.next_episode.url) {
                    showNextEpisodeOverlay(data.next_episode.title, data.next_episode.url);
                }
            })
            .catch(() => {});
    }

    function showNextEpisodeOverlay(title, url) {
        const existing = wrapper.querySelector('.fav-next-episode-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.className = 'fav-next-episode-overlay';
        let countdown = 10;

        overlay.innerHTML = `
            <div style="font-size: 11px; text-transform: uppercase; color: #38bdf8; font-weight: 700;">Up Next in <span id="fmm-countdown">${countdown}</span>s</div>
            <div style="font-size: 14px; font-weight: 600; color: #fff; line-height: 1.3;">${title}</div>
            <div style="display: flex; gap: 8px; margin-top: 6px;">
                <a href="${url}" class="fmm-btn fmm-btn-primary" style="padding: 6px 12px; font-size: 12px; text-decoration: none;">Play Now</a>
                <button type="button" class="fmm-btn fmm-btn-secondary" id="fmm-cancel-next" style="padding: 6px 12px; font-size: 12px;">Cancel</button>
            </div>
        `;

        wrapper.appendChild(overlay);

        const timer = setInterval(() => {
            countdown--;
            const countEl = overlay.querySelector('#fmm-countdown');
            if (countEl) countEl.textContent = countdown;
            if (countdown <= 0) {
                clearInterval(timer);
                window.location.href = url;
            }
        }, 1000);

        const cancelBtn = overlay.querySelector('#fmm-cancel-next');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                clearInterval(timer);
                overlay.remove();
            });
        }
    }
}

// Global Handlers for Favorites and History
document.addEventListener('DOMContentLoaded', function () {
    // Favorite Toggle Buttons
    document.addEventListener('click', function (e) {
        const favBtn = e.target.closest('[data-fmm-fav-toggle]');
        if (!favBtn) return;
        e.preventDefault();

        const cType = favBtn.getAttribute('data-content-type');
        const cId = parseInt(favBtn.getAttribute('data-content-id'), 10);
        if (!cType || !cId) return;

        fetch('/multimedia/api/favorite/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ content_type: cType, content_id: cId })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const label = favBtn.querySelector('.fav-btn-label');
                if (data.favorited) {
                    favBtn.classList.add('active');
                    if (label) label.textContent = 'In My List';
                } else {
                    favBtn.classList.remove('active');
                    if (label) label.textContent = 'Add to My List';
                    const card = favBtn.closest('.fmm-favorite-card');
                    if (card && window.location.pathname.includes('/my-list')) {
                        card.style.opacity = '0';
                        card.style.transform = 'scale(0.95)';
                        setTimeout(() => card.remove(), 200);
                    }
                }
            } else if (data.status === 'unauthenticated') {
                window.location.href = '/admin/login?redirect=' + encodeURIComponent(window.location.pathname);
            }
        })
        .catch(() => {});
    });

    // History Remove Item
    document.addEventListener('click', function (e) {
        const removeBtn = e.target.closest('[data-fmm-history-remove]');
        if (!removeBtn) return;
        e.preventDefault();

        const cType = removeBtn.getAttribute('data-content-type');
        const cId = parseInt(removeBtn.getAttribute('data-content-id'), 10);
        if (!cType || !cId) return;

        fetch('/multimedia/api/history/remove', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ content_type: cType, content_id: cId })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const item = removeBtn.closest('.fmm-history-item, .fmm-card');
                if (item) {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.95)';
                    setTimeout(() => item.remove(), 200);
                }
            }
        })
        .catch(() => {});
    });

    // History Clear All
    document.addEventListener('click', function (e) {
        const clearBtn = e.target.closest('[data-fmm-history-clear]');
        if (!clearBtn) return;
        e.preventDefault();

        if (!confirm('Are you sure you want to clear your entire watch and listening history?')) return;

        fetch('/multimedia/api/history/clear', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            }
        })
        .catch(() => {});
    });
});

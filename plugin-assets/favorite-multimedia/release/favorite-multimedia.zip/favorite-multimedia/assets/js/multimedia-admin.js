/**
 * Favorite Multimedia — Admin Interactive Helper
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Automatic Media Type Detection for URL input
    const urlInput = document.getElementById('fav_source_url');
    const typeSelect = document.getElementById('fav_source_type');
    const detectionBox = document.getElementById('fav_detection_status');

    if (urlInput && typeSelect) {
        let debounceTimer = null;
        urlInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => detectSourceType(urlInput.value), 400);
        });

        function detectSourceType(url) {
            url = url.trim();
            if (!url) {
                if (detectionBox) detectionBox.style.display = 'none';
                return;
            }

            fetch('/multimedia/api/detect?url=' + encodeURIComponent(url))
                .then(res => res.json())
                .then(data => {
                    if (data.source_type && data.source_type !== 'unknown') {
                        typeSelect.value = data.source_type;
                        if (detectionBox) {
                            detectionBox.style.display = 'block';
                            detectionBox.style.borderColor = '#10b981';
                            detectionBox.style.color = '#065f46';
                            detectionBox.textContent = `Auto-detected: ${data.source_type.toUpperCase()} (${data.mime_type || data.player_type})`;
                        }
                    } else {
                        typeSelect.value = 'unknown';
                        if (detectionBox) {
                            detectionBox.style.display = 'block';
                            detectionBox.style.borderColor = '#f59e0b';
                            detectionBox.style.color = '#92400e';
                            detectionBox.textContent = 'Unknown Media Type. Please select source type manually.';
                        }
                    }
                })
                .catch(() => {
                    // Fallback client detection
                    clientDetect(url);
                });
        }

        function clientDetect(url) {
            const lower = url.toLowerCase();
            if (lower.includes('.m3u8')) {
                typeSelect.value = 'hls';
            } else if (lower.endsWith('.mp4') || lower.endsWith('.webm') || lower.endsWith('.ogv')) {
                typeSelect.value = 'video';
            } else if (lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.wav') || lower.endsWith('.ogg')) {
                typeSelect.value = 'audio';
            } else if (lower.includes('youtube.com') || lower.includes('youtu.be') || lower.includes('vimeo.com') || lower.includes('dailymotion.com') || lower.includes('soundcloud.com')) {
                typeSelect.value = 'embed';
            } else {
                typeSelect.value = 'unknown';
            }
        }
    }
});

<?php
/**
 * Favorite Multimedia — Movie Detail & Player View
 */
$playableSources = $playableSources ?? [];
$defaultSource = $defaultSource ?? ($sources[0] ?? null);

// Normalize sources array
$sourcesList = !empty($playableSources) ? $playableSources : array_map(function($s) {
    $embedInfo = \FavoriteCMS\Multimedia\Services\MediaSourceResolver::detectEmbedService($s->url_or_path);
    $pType = ($embedInfo !== null || $s->source_type === 'embed') ? 'embed' : (($s->source_type === 'hls') ? 'hls' : 'video');
    $playUrl = $embedInfo ? $embedInfo['embed_url'] : (($pType === 'embed') ? $s->url_or_path : "/multimedia/stream/{$s->id}");
    return [
        'id'                => (int)$s->id,
        'label'             => $s->label ?: 'Stream',
        'source_type'       => $s->source_type,
        'player_type'       => $pType,
        'url'               => $playUrl,
        'stream_url'        => "/multimedia/stream/{$s->id}",
        'mime_type'         => $s->mime_type ?: 'video/mp4',
        'is_default'        => !empty($s->is_default),
        'can_auto_failover' => ($pType !== 'embed'),
    ];
}, $sources);

$defaultItem = is_array($defaultSource) ? $defaultSource : ($sourcesList[0] ?? null);
$isHls = ($defaultItem && ($defaultItem['player_type'] ?? '') === 'hls');
$isEmbed = ($defaultItem && ($defaultItem['player_type'] ?? '') === 'embed');
$playableUrl = $defaultItem['url'] ?? '';
$playableMime = $defaultItem['mime_type'] ?? 'video/mp4';
$playableId = $defaultItem['id'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <?php if (!empty($metaDescription)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($metaDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <meta property="og:title" content="<?php echo htmlspecialchars($movie->title, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:type" content="video.movie">
    <?php if ($movie->poster): ?>
        <meta property="og:image" content="<?php echo htmlspecialchars($movie->poster, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #0f172a; color: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Navigation Header -->
        <header class="fav-mm-header" style="border-color: #1e293b;">
            <div>
                <a href="/movies" style="color: #94a3b8; text-decoration: none; font-size: 14px; font-weight: 500;">&larr; Back to Movies</a>
                <h1 style="color: #fff; font-size: 26px; margin: 8px 0 0 0;"><?php echo htmlspecialchars($movie->title, ENT_QUOTES, 'UTF-8'); ?></h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link active">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
            </nav>
        </header>

        <!-- Resume Prompt Banner -->
        <?php if (!empty($progress['should_resume'])): ?>
            <div class="fmm-resume-banner" id="fmm-resume-prompt" style="max-width: 960px; margin: 0 auto 20px auto;">
                <div class="fmm-resume-info">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
                    <span>You were watching this. Resume from <strong><?= htmlspecialchars($progress['formatted_position'] ?? '0:00') ?></strong> (<?= round($progress['percentage'] ?? 0) ?>%)?</span>
                </div>
                <div class="fmm-resume-actions">
                    <button type="button" class="fmm-btn fmm-btn-primary" id="fmm-resume-accept-btn" style="padding: 6px 14px; font-size: 13px;">Resume</button>
                    <button type="button" class="fmm-btn fmm-btn-secondary" id="fmm-resume-start-over-btn" style="padding: 6px 14px; font-size: 13px;">Start Over</button>
                </div>
            </div>
        <?php endif; ?>

        <!-- Player Stage -->
        <div style="max-width: 960px; margin: 0 auto 32px auto;">
            <div class="fav-video-wrapper" 
                 data-content-type="movie" 
                 data-content-id="<?php echo (int)$movie->id; ?>" 
                 data-resume-position="<?php echo (!empty($progress['should_resume'])) ? (float)$progress['position'] : 0; ?>"
                 data-sources='<?php echo htmlspecialchars(json_encode($sourcesList), ENT_QUOTES, 'UTF-8'); ?>'
                 <?php if ($isHls && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW): ?>data-hls-src="<?php echo htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?>>
                <?php if ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW): ?>
                    <?php if (empty($sourcesList)): ?>
                        <div class="fav-restriction-card" style="background: rgba(15, 23, 42, 0.95); border: 1px dashed #334155; padding: 48px 24px; text-align: center;">
                            <div class="fav-restriction-icon" style="font-size: 40px; margin-bottom: 12px;">🎬</div>
                            <h2 class="fav-restriction-title" style="font-size: 20px; color: #f8fafc; margin-bottom: 8px;">Media Coming Soon</h2>
                            <p class="fav-restriction-msg" style="color: #94a3b8; font-size: 14px; max-width: 440px; margin: 0 auto;">This movie is scheduled or currently being prepared. Video stream will be available soon.</p>
                        </div>
                    <?php elseif ($isEmbed): ?>
                        <iframe src="<?php echo htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8'); ?>" class="fav-embed-element" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen sandbox="allow-scripts allow-same-origin allow-presentation allow-fullscreen"></iframe>
                    <?php else: ?>
                        <video class="fav-video-element" poster="<?php echo htmlspecialchars(($movie->backdrop ?: $movie->poster) ?? '', ENT_QUOTES, 'UTF-8'); ?>" preload="metadata" playsinline>
                            <?php if (!$isHls && $playableUrl): ?>
                                <source src="<?php echo htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8'); ?>" type="<?php echo htmlspecialchars($playableMime, ENT_QUOTES, 'UTF-8'); ?>">
                            <?php endif; ?>
                            <?php foreach ($subtitles as $sub): ?>
                                <track kind="subtitles" label="<?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?>" srclang="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>" src="/multimedia/subtitle/<?php echo $sub->id; ?>" <?php echo $sub->is_default ? 'default' : ''; ?>>
                            <?php endforeach; ?>
                        </video>

                        <!-- Video Controls Overlay -->
                        <div class="fav-player-controls">
                            <div class="fav-progress-bar-container">
                                <div class="fav-progress-filled">
                                    <span class="fav-progress-scrubber"></span>
                                </div>
                            </div>
                            <div class="fav-controls-row">
                                <div class="fav-controls-left">
                                    <button type="button" class="fav-btn-control fav-btn-play" aria-label="Play">
                                        <span class="fav-icon-play">&#9654;</span>
                                        <span class="fav-icon-pause" style="display:none;">&#10074;&#10074;</span>
                                    </button>
                                    <div class="fav-volume-wrapper">
                                        <button type="button" class="fav-btn-control fav-btn-volume" aria-label="Volume">&#128266;</button>
                                        <input type="range" class="fav-volume-slider" min="0" max="1" step="0.05" value="1">
                                    </div>
                                    <div class="fav-time-display">0:00 / 0:00</div>
                                </div>
                                <div class="fav-controls-right">
                                    <?php if (count($sourcesList) > 1): ?>
                                        <select class="fav-control-select fav-source-select" title="Switch Source" aria-label="Switch Playback Source">
                                            <?php foreach ($sourcesList as $s): ?>
                                                <option value="<?php echo (int)$s['id']; ?>" <?php echo !empty($s['is_default']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($s['label'], ENT_QUOTES, 'UTF-8'); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>

                                    <?php if (!empty($subtitles)): ?>
                                        <select class="fav-control-select fav-subtitle-select" title="Subtitles">
                                            <option value="off">CC Off</option>
                                            <?php foreach ($subtitles as $sub): ?>
                                                <option value="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>

                                    <select class="fav-control-select fav-speed-select" title="Playback Speed">
                                        <option value="0.75">0.75x</option>
                                        <option value="1" selected>1x</option>
                                        <option value="1.25">1.25x</option>
                                        <option value="1.5">1.5x</option>
                                        <option value="2">2x</option>
                                    </select>

                                    <?php if ($downloadInfo['allowed'] && $defaultSource): ?>
                                        <a href="/multimedia/download/<?php echo $defaultSource->id; ?>" class="fav-btn-download" title="Download Movie File">
                                            &#8595; Download
                                        </a>
                                    <?php endif; ?>

                                    <button type="button" class="fav-btn-control fav-btn-fullscreen" aria-label="Fullscreen">&#x26F6;</button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED): ?>
                    <div class="fav-restriction-card">
                        <div class="fav-restriction-icon">🔒</div>
                        <h2 class="fav-restriction-title">Member Login Required</h2>
                        <p class="fav-restriction-msg">Please log in to your account to stream or download this movie.</p>
                        <a href="/admin/login?redirect=<?php echo urlencode('/movie/' . $movie->slug); ?>" class="fav-btn-cta">Sign In to Watch</a>
                    </div>

                <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED): ?>
                    <div class="fav-restriction-card">
                        <div class="fav-restriction-icon">⭐</div>
                        <h2 class="fav-restriction-title">Premium Subscription Required</h2>
                        <p class="fav-restriction-msg">This title is exclusive to Premium members. Upgrade your membership with Favorite Digital to unlock our full catalog.</p>
                        <a href="<?php echo \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::getSubscriptionUrl(); ?>" class="fav-btn-cta">Upgrade to Premium</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Download Button Bar (if allowed) -->
            <?php if ($downloadInfo['allowed'] && $defaultSource): ?>
                <div style="margin-top: 12px; display: flex; justify-content: flex-end;">
                    <a href="/multimedia/download/<?php echo $defaultSource->id; ?>" class="fav-btn-download" style="padding: 8px 16px; font-size: 13px;">
                        &#8595; Download Movie (<?php echo htmlspecialchars($defaultSource->label, ENT_QUOTES, 'UTF-8'); ?>)
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Movie Information -->
        <div style="max-width: 960px; margin: 0 auto; background: #1e293b; border-radius: 8px; padding: 24px;">
            <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-bottom: 16px;">
                <span class="fav-badge fav-badge-<?php echo strtolower($movie->access_mode ?? 'public'); ?>"><?php echo strtoupper($movie->access_mode ?? 'public'); ?></span>
                <?php if ($movie->release_year): ?>
                    <span style="color: #94a3b8; font-size: 14px;"><?php echo $movie->release_year; ?></span>
                <?php endif; ?>
                <?php if ($movie->getDurationFormatted()): ?>
                    <span style="color: #94a3b8; font-size: 14px;">• <?php echo $movie->getDurationFormatted(); ?></span>
                <?php endif; ?>
                <?php if ($movie->language): ?>
                    <span style="color: #94a3b8; font-size: 14px;">• <?php echo htmlspecialchars($movie->language, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
                <?php foreach ($movie->getGenres() as $g): ?>
                    <a href="/movies?genre=<?php echo urlencode($g->slug); ?>" style="background: rgba(255,255,255,0.1); color: #e2e8f0; font-size: 12px; padding: 2px 8px; border-radius: 4px; text-decoration: none;">
                        <?php echo htmlspecialchars($g->name, ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                <?php endforeach; ?>

                <?php if (!empty($user)): ?>
                    <button type="button" class="fav-btn-favorite <?= !empty($isFavorite) ? 'active' : '' ?>" data-fmm-fav-toggle data-content-type="movie" data-content-id="<?= (int)$movie->id ?>" style="margin-left: auto;">
                        <span class="fav-icon-star">★</span>
                        <span class="fav-btn-label"><?= !empty($isFavorite) ? 'In My List' : 'Add to My List' ?></span>
                    </button>
                <?php endif; ?>
            </div>

            <?php if (!empty($movie->description)): ?>
                <div style="line-height: 1.7; color: #cbd5e1; margin-bottom: 20px;">
                    <?php echo nl2br(htmlspecialchars($movie->description, ENT_QUOTES, 'UTF-8')); ?>
                </div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; font-size: 13px; color: #94a3b8; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px;">
                <?php if ($movie->director): ?>
                    <div><strong style="color: #fff;">Director:</strong> <?php echo htmlspecialchars($movie->director, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php if ($movie->cast): ?>
                    <div><strong style="color: #fff;">Cast:</strong> <?php echo htmlspecialchars($movie->cast, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <?php if ($movie->country): ?>
                    <div><strong style="color: #fff;">Country:</strong> <?php echo htmlspecialchars($movie->country, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
            </div>

            <?php
            $contentType = 'movie';
            $contentId = (int)$movie->id;
            include __DIR__ . '/_engagement_section.php';
            ?>

            <?php if (!empty($relatedMovies)): ?>
                <div style="margin-top: 40px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 24px;">
                    <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 16px 0;">🎬 Related Movies You May Like</h3>
                    <div class="fav-mm-grid">
                        <?php foreach ($relatedMovies as $item): ?>
                            <?php include __DIR__ . '/_discovery_card.php'; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="/plugins/favorite-multimedia/assets/js/multimedia-player.js"></script>
</body>
</html>


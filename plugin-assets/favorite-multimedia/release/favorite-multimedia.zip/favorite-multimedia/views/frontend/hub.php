<?php
/**
 * Favorite Multimedia — Frontend Catalog Hub
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Hub Header & Navigation -->
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🎬 Multimedia</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Watch movies &amp; series, stream music, and enjoy playlists</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link active">Hub</a>
                <a href="/multimedia/discover" class="fav-mm-nav-link">Discover</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
                <?php if (!empty($user)): ?>
                    <a href="/multimedia/library" class="fav-mm-nav-link" style="background:#2563eb; color:#fff;">My Library</a>
                    <a href="/multimedia/my-list" class="fav-mm-nav-link">My List</a>
                    <a href="/multimedia/history" class="fav-mm-nav-link">History</a>
                <?php endif; ?>
            </nav>
        </header>

        <!-- Search Bar -->
        <form method="GET" action="/multimedia/search" class="fav-mm-filter-bar">
            <input type="text" name="q" class="fav-mm-search-input" placeholder="Search movies, series, songs, artists..." required>
            <button type="submit" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Search</button>
        </form>

        <?php if (!empty($continueWatching)): ?>
            <!-- Continue Watching Section -->
            <section style="margin-bottom: 40px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                    <h2 style="font-size: 20px; font-weight: 700; margin: 0; display:flex; align-items:center; gap:8px;">
                        <span>▶</span> Continue Watching
                    </h2>
                    <a href="/multimedia/library" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All in Library &rarr;</a>
                </div>

                <div class="fmm-grid fmm-grid-4">
                    <?php foreach ($continueWatching as $cw): ?>
                        <?php
                            $cData = $cw['content'] ?? [];
                            $cTitle = htmlspecialchars($cData['title'] ?? 'Untitled', ENT_QUOTES, 'UTF-8');
                            $cThumb = htmlspecialchars($cData['thumbnail'] ?? ($cData['poster_image'] ?? ''), ENT_QUOTES, 'UTF-8');
                            $pct = (float)($cw['percentage'] ?? 0);
                            $fPos = $cw['formatted_position'] ?? '0:00';
                            $targetUrl = $cw['url'] ?? '#';
                            $subLabel = ($cw['content_type'] === 'episode') ? htmlspecialchars($cData['series_title'] ?? '', ENT_QUOTES, 'UTF-8') : 'Movie';
                        ?>
                        <div class="fmm-card">
                            <div class="fmm-card-media">
                                <?php if ($cThumb): ?>
                                    <img src="<?= $cThumb ?>" alt="<?= $cTitle ?>" loading="lazy">
                                <?php else: ?>
                                    <div class="fmm-card-placeholder">
                                        <span>▶</span>
                                    </div>
                                <?php endif; ?>
                                <span class="fmm-badge fmm-badge-<?= $cw['content_type'] ?>"><?= ucfirst($cw['content_type']) ?></span>
                                <div class="fmm-card-progress">
                                    <div class="fmm-progress-fill" style="width: <?= min(100, $pct) ?>%;"></div>
                                </div>
                            </div>
                            <div class="fmm-card-body">
                                <h4 class="fmm-card-title">
                                    <a href="<?= htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') ?>"><?= $cTitle ?></a>
                                </h4>
                                <div class="fmm-card-subtitle"><?= $subLabel ?></div>
                                <div class="fmm-card-meta">
                                    <span><?= $fPos ?> watched</span>
                                    <a href="<?= htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') ?>" class="fmm-resume-link">Resume &rarr;</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($myList)): ?>
            <!-- My List Section -->
            <section style="margin-bottom: 40px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                    <h2 style="font-size: 20px; font-weight: 700; margin: 0; display:flex; align-items:center; gap:8px;">
                        <span>★</span> My List
                    </h2>
                    <a href="/multimedia/my-list" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All (<?= count($myList) ?>) &rarr;</a>
                </div>

                <div class="fmm-grid fmm-grid-5">
                    <?php foreach (array_slice($myList, 0, 5) as $ml): ?>
                        <?php
                            $mData = $ml['content'] ?? [];
                            $mTitle = htmlspecialchars($mData['title'] ?? 'Untitled', ENT_QUOTES, 'UTF-8');
                            $mPoster = htmlspecialchars($mData['poster_image'] ?? '', ENT_QUOTES, 'UTF-8');
                            $mUrl = $ml['url'] ?? '#';
                            $mType = $ml['content_type'] ?? 'item';
                        ?>
                        <div class="fmm-card fmm-favorite-card">
                            <div class="fmm-card-media">
                                <?php if ($mPoster): ?>
                                    <img src="<?= $mPoster ?>" alt="<?= $mTitle ?>" loading="lazy">
                                <?php else: ?>
                                    <div class="fmm-card-placeholder">
                                        <span><?= strtoupper(substr($mTitle, 0, 2)) ?></span>
                                    </div>
                                <?php endif; ?>
                                <span class="fmm-badge fmm-badge-<?= $mType ?>"><?= ucfirst($mType) ?></span>
                            </div>
                            <div class="fmm-card-body">
                                <h4 class="fmm-card-title">
                                    <a href="<?= htmlspecialchars($mUrl, ENT_QUOTES, 'UTF-8') ?>"><?= $mTitle ?></a>
                                </h4>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($becauseYouWatched['items'])): ?>
            <!-- Because You Watched Shelf -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>💡</span> Because you watched <em><?= htmlspecialchars($becauseYouWatched['anchor']['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></em>
                    </h2>
                    <a href="/multimedia/discover" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">Discover More &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($becauseYouWatched['items'] as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($becauseYouLiked['items'])): ?>
            <!-- Because You Liked Shelf -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>❤️</span> Because you liked <em><?= htmlspecialchars($becauseYouLiked['anchor']['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></em>
                    </h2>
                    <a href="/multimedia/discover" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">Discover More &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($becauseYouLiked['items'] as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($personalizedFeed)): ?>
            <!-- Recommended For You Shelf -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>🎯</span> Recommended For You
                    </h2>
                    <a href="/multimedia/discover" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View All &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($personalizedFeed as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($trending)): ?>
            <!-- Trending Now Shelf -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>🔥</span> Trending Now
                    </h2>
                    <a href="/multimedia/discover?tab=trending" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View Trending &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($trending as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($recentlyAdded)): ?>
            <!-- Recently Added Shelf -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>✨</span> Recently Added
                    </h2>
                    <a href="/multimedia/discover?tab=recent" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View All &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($recentlyAdded as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- Featured Movies Section -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0;">Featured Movies</h2>
                <a href="/movies" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All &rarr;</a>
            </div>

            <div class="fav-mm-grid">
                <?php if (empty($movies)): ?>
                    <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                        <span class="fav-mm-empty-icon">🎬</span>
                        <div class="fav-mm-empty-title">No Movies Available</div>
                        <p class="fav-mm-empty-desc">Check back soon or explore our music and web series collection.</p>
                    </div>
                <?php else: foreach ($movies as $m): ?>
                    <a href="/movie/<?php echo htmlspecialchars($m->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                        <div class="fav-mm-poster-wrap">
                            <span class="fav-badge fav-badge-<?php echo strtolower($m->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($m->access_mode ?? 'public'); ?></span>
                            <?php if ($m->poster): ?>
                                <img src="<?php echo htmlspecialchars($m->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                            <?php else: ?>
                                <div class="fav-mm-placeholder fav-mm-placeholder-movie">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M19.82 2H4.18C2.97 2 2 2.97 2 4.18v15.64C2 21.03 2.97 22 4.18 22h15.64c1.21 0 2.18-.97 2.18-2.18V4.18C22 2.97 21.03 2 19.82 2zM7 2v20M17 2v20M2 12h20M2 7h5M2 17h5M17 17h5M17 7h5"/></svg>
                                    <span>Movie</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="fav-mm-card-body">
                            <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                            <div class="fav-mm-card-meta">
                                <span><?php echo $m->release_year ?: '—'; ?></span>
                                <span><?php echo $m->getDurationFormatted(); ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; endif; ?>
            </div>
        </section>

        <!-- Web Series Section -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0;">Popular Web Series</h2>
                <a href="/series" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All &rarr;</a>
            </div>

            <div class="fav-mm-grid">
                <?php if (empty($series)): ?>
                    <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                        <span class="fav-mm-empty-icon">📺</span>
                        <div class="fav-mm-empty-title">No Series Available</div>
                        <p class="fav-mm-empty-desc">New series will appear here once published.</p>
                    </div>
                <?php else: foreach ($series as $s): ?>
                    <a href="/series/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                        <div class="fav-mm-poster-wrap">
                            <span class="fav-badge fav-badge-<?php echo strtolower($s->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($s->access_mode ?? 'public'); ?></span>
                            <?php if ($s->poster): ?>
                                <img src="<?php echo htmlspecialchars($s->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                            <?php else: ?>
                                <div class="fav-mm-placeholder fav-mm-placeholder-series">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></svg>
                                    <span>Series</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="fav-mm-card-body">
                            <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                            <div class="fav-mm-card-meta">
                                <span><?php echo $s->release_year ?: '—'; ?></span>
                                <span><?php echo count($s->getSeasons()); ?> Seasons</span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; endif; ?>
            </div>
        </section>

        <!-- Songs & Audio Playlists Section -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0;">Featured Songs &amp; Playlists</h2>
                <a href="/songs" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">Explore Music &rarr;</a>
            </div>

            <div class="fav-mm-grid">
                <?php if (empty($playlists) && empty($songs)): ?>
                    <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                        <span class="fav-mm-empty-icon">🎵</span>
                        <div class="fav-mm-empty-title">No Music Available Yet</div>
                        <p class="fav-mm-empty-desc">Check back soon for new songs and curated playlists.</p>
                    </div>
                <?php endif; ?>

                <?php if (!empty($playlists)): foreach ($playlists as $pl): ?>
                    <a href="/playlist/<?php echo htmlspecialchars($pl->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                        <div class="fav-mm-poster-wrap fav-mm-poster-square">
                            <span class="fav-badge fav-badge-<?php echo strtolower($pl->access_mode ?? 'public'); ?> fav-mm-card-badge">PLAYLIST</span>
                            <?php if ($pl->cover): ?>
                                <img src="<?php echo htmlspecialchars($pl->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($pl->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                            <?php else: ?>
                                <div class="fav-mm-placeholder fav-mm-placeholder-playlist">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                                    <span>Playlist</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="fav-mm-card-body">
                            <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($pl->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                            <div class="fav-mm-card-meta">
                                <span><?php echo count($pl->getSongs()); ?> Tracks</span>
                                <span>Play All &rarr;</span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; endif; ?>

                <?php if (!empty($songs)): foreach (array_slice($songs, 0, 4) as $sg): ?>
                    <a href="/song/<?php echo htmlspecialchars($sg->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                        <div class="fav-mm-poster-wrap fav-mm-poster-square">
                            <span class="fav-badge fav-badge-<?php echo strtolower($sg->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($sg->access_mode ?? 'public'); ?></span>
                            <?php if ($sg->cover): ?>
                                <img src="<?php echo htmlspecialchars($sg->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($sg->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                            <?php else: ?>
                                <div class="fav-mm-placeholder fav-mm-placeholder-audio">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                                    <span>Song</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="fav-mm-card-body">
                            <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($sg->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                            <div class="fav-mm-card-meta">
                                <span><?php echo htmlspecialchars($sg->getArtist()?->name ?: 'Various', ENT_QUOTES, 'UTF-8'); ?></span>
                                <span><?php echo $sg->getDurationFormatted(); ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; endif; ?>
            </div>
        </section>
    </div>

</body>
</html>


<?php
/**
 * Favorite Multimedia — Personal User Library
 */
$cw = $dashboard['continue_watching'] ?? [];
$cl = $dashboard['continue_listening'] ?? [];
$myList = $dashboard['my_list'] ?? [];
$recentHistory = $dashboard['recent_history'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
    <style>
        .fav-lib-card-progress {
            position: relative;
            background: #e2e8f0;
            height: 5px;
            border-radius: 0 0 8px 8px;
            overflow: hidden;
            margin-top: -5px;
            z-index: 2;
        }
        .fav-lib-card-fill {
            background: #2563eb;
            height: 100%;
            transition: width 0.3s ease;
        }
        .fav-badge-time {
            position: absolute;
            bottom: 12px;
            right: 8px;
            background: rgba(15, 23, 42, 0.85);
            color: #fff;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: 500;
        }
        .fav-lib-btn {
            background: #f1f5f9;
            color: #334155;
            border: 1px solid #cbd5e1;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
        }
        .fav-lib-btn:hover {
            background: #e2e8f0;
            color: #0f172a;
        }
        .fav-lib-btn-danger:hover {
            background: #fee2e2;
            color: #dc2626;
            border-color: #fca5a5;
        }
    </style>
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Header & Nav -->
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">👤 My Personal Library</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Welcome back, <strong><?php echo htmlspecialchars($user->username ?? 'User', ENT_QUOTES, 'UTF-8'); ?></strong>! Continue your entertainment where you left off.</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
                <a href="/multimedia/library" class="fav-mm-nav-link active">My Library</a>
            </nav>
        </header>

        <!-- Secondary Action Bar -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding: 12px 18px; background: #fff; border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.02);">
            <div style="display: flex; gap: 12px;">
                <a href="/multimedia/library" class="fav-lib-btn" style="background:#2563eb; color:#fff; border-color:#2563eb;">Overview</a>
                <a href="/multimedia/my-list" class="fav-lib-btn">My List (<?php echo (int)($dashboard['favorites_count'] ?? 0); ?>)</a>
                <a href="/multimedia/history" class="fav-lib-btn">Full History (<?php echo (int)($dashboard['history_count'] ?? 0); ?>)</a>
            </div>
            <?php if (!empty($recentHistory)): ?>
                <button type="button" class="fav-lib-btn fav-lib-btn-danger" onclick="clearFullHistory()">🗑️ Clear History</button>
            <?php endif; ?>
        </div>

        <!-- 1. Continue Watching Section -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0; color: #0f172a;">▶️ Continue Watching</h2>
                <?php if (count($cw) >= 8): ?>
                    <a href="/multimedia/history?type=video" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All &rarr;</a>
                <?php endif; ?>
            </div>

            <?php if (empty($cw)): ?>
                <div class="fav-mm-empty">
                    <span class="fav-mm-empty-icon">📺</span>
                    <div class="fav-mm-empty-title">Nothing in Continue Watching</div>
                    <p class="fav-mm-empty-desc">Start watching any movie or web series, and your resume position will appear here automatically.</p>
                </div>
            <?php else: ?>
                <div class="fav-mm-grid">
                    <?php foreach ($cw as $item): ?>
                        <div class="fav-mm-card" style="position: relative;">
                            <a href="<?php echo htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8'); ?>" style="text-decoration: none; color: inherit;">
                                <div class="fav-mm-poster-wrap">
                                    <span class="fav-badge fav-badge-public fav-mm-card-badge"><?php echo strtoupper($item['content_type']); ?></span>
                                    <?php if ($item['poster']): ?>
                                        <img src="<?php echo htmlspecialchars($item['poster'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                                    <?php else: ?>
                                        <div class="fav-mm-placeholder fav-mm-placeholder-movie">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($item['remaining_formatted']): ?>
                                        <span class="fav-badge-time"><?php echo htmlspecialchars($item['remaining_formatted'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="fav-lib-card-progress" title="<?php echo (float)$item['percentage']; ?>% watched">
                                    <div class="fav-lib-card-fill" style="width: <?php echo (float)$item['percentage']; ?>%;"></div>
                                </div>
                                <div class="fav-mm-card-body">
                                    <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                                    <div class="fav-mm-card-meta">
                                        <span><?php echo (float)$item['percentage']; ?>% watched</span>
                                        <span style="color: #2563eb; font-weight: 600;">Resume &rarr;</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- 2. Continue Listening Section -->
        <?php if (!empty($cl)): ?>
            <section style="margin-bottom: 40px;">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                    <h2 style="font-size: 20px; font-weight: 700; margin: 0; color: #0f172a;">🎧 Continue Listening</h2>
                    <a href="/songs" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">Explore Music &rarr;</a>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
                    <?php foreach ($cl as $songItem): ?>
                        <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; display: flex; align-items: center; gap: 12px;">
                            <?php if ($songItem['poster']): ?>
                                <img src="<?php echo htmlspecialchars($songItem['poster'], ENT_QUOTES, 'UTF-8'); ?>" alt="" style="width: 52px; height: 52px; border-radius: 6px; object-fit: cover;">
                            <?php else: ?>
                                <div style="width: 52px; height: 52px; border-radius: 6px; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-size: 20px;">🎵</div>
                            <?php endif; ?>
                            <div style="flex: 1; min-width: 0;">
                                <a href="<?php echo htmlspecialchars($songItem['url'], ENT_QUOTES, 'UTF-8'); ?>" style="font-weight: 600; font-size: 14px; text-decoration: none; color: #0f172a; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo htmlspecialchars($songItem['title'], ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                                <div style="font-size: 12px; color: #64748b; margin-top: 2px;"><?php echo htmlspecialchars($songItem['artist_name'] ?: 'Unknown Artist', ENT_QUOTES, 'UTF-8'); ?></div>
                                <div style="background: #e2e8f0; height: 4px; border-radius: 2px; margin-top: 6px; overflow: hidden;">
                                    <div style="background: #2563eb; height: 100%; width: <?php echo (float)$songItem['percentage']; ?>%;"></div>
                                </div>
                            </div>
                            <a href="<?php echo htmlspecialchars($songItem['url'], ENT_QUOTES, 'UTF-8'); ?>" style="background: #2563eb; color: #fff; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 14px;">▶</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- 3. My List (Favorites Preview) -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0; color: #0f172a;">⭐ My List</h2>
                <a href="/multimedia/my-list" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">View All (<?php echo (int)($dashboard['favorites_count'] ?? 0); ?>) &rarr;</a>
            </div>

            <?php if (empty($myList)): ?>
                <div class="fav-mm-empty">
                    <span class="fav-mm-empty-icon">🔖</span>
                    <div class="fav-mm-empty-title">Your List is Empty</div>
                    <p class="fav-mm-empty-desc">Click "Add to My List" on any Movie, Series, Song, or Playlist to bookmark it for later.</p>
                </div>
            <?php else: ?>
                <div class="fav-mm-grid">
                    <?php foreach ($myList as $fav): ?>
                        <div class="fav-mm-card" style="position: relative;">
                            <a href="<?php echo htmlspecialchars($fav['url'], ENT_QUOTES, 'UTF-8'); ?>" style="text-decoration: none; color: inherit;">
                                <div class="fav-mm-poster-wrap">
                                    <span class="fav-badge fav-badge-<?php echo strtolower($fav['access_state'] ?? 'allow'); ?> fav-mm-card-badge">
                                        <?php echo strtoupper($fav['content_type']); ?>
                                    </span>
                                    <?php if ($fav['poster']): ?>
                                        <img src="<?php echo htmlspecialchars($fav['poster'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($fav['title'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                                    <?php else: ?>
                                        <div class="fav-mm-placeholder fav-mm-placeholder-movie">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="fav-mm-card-body">
                                    <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($fav['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                                    <div class="fav-mm-card-meta">
                                        <span><?php echo $fav['is_accessible'] ? 'Accessible' : '🔒 Requires Upgrade'; ?></span>
                                        <button type="button" class="fav-lib-btn" style="padding: 2px 8px; font-size: 11px;" onclick="event.preventDefault(); removeFavorite('<?php echo htmlspecialchars($fav['content_type'], ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$fav['content_id']; ?>, this)">Remove</button>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- 4. Recent Watch History -->
        <section style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                <h2 style="font-size: 20px; font-weight: 700; margin: 0; color: #0f172a;">🕒 Recent Activity</h2>
                <a href="/multimedia/history" style="color: #2563eb; font-weight: 600; font-size: 14px; text-decoration: none;">Full History &rarr;</a>
            </div>

            <?php if (empty($recentHistory)): ?>
                <div class="fav-mm-empty">
                    <span class="fav-mm-empty-icon">⌛</span>
                    <div class="fav-mm-empty-title">No Recent Playback Activity</div>
                    <p class="fav-mm-empty-desc">Your playback history will appear here once you begin streaming.</p>
                </div>
            <?php else: ?>
                <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
                    <?php foreach ($recentHistory as $h): ?>
                        <div style="display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; border-bottom: 1px solid #f1f5f9; gap: 16px;">
                            <div style="display: flex; align-items: center; gap: 14px; min-width: 0;">
                                <span style="font-size: 18px;"><?php echo ($h['content_type'] === 'song') ? '🎵' : '🎬'; ?></span>
                                <div style="min-width: 0;">
                                    <a href="<?php echo htmlspecialchars($h['url'], ENT_QUOTES, 'UTF-8'); ?>" style="font-weight: 600; font-size: 14px; color: #0f172a; text-decoration: none;">
                                        <?php echo htmlspecialchars($h['title'], ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                    <div style="font-size: 12px; color: #64748b; margin-top: 2px;">
                                        <span><?php echo ucfirst($h['content_type']); ?></span> &bull;
                                        <span><?php echo $h['is_completed'] ? '✅ Completed' : round((float)$h['percentage']) . '% played'; ?></span> &bull;
                                        <span>Played on <?php echo date('M d, Y H:i', strtotime($h['last_played_at'])); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div style="display: flex; gap: 8px; flex-shrink: 0;">
                                <a href="<?php echo htmlspecialchars($h['url'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-lib-btn" style="color: #2563eb;">Play</a>
                                <button type="button" class="fav-lib-btn fav-lib-btn-danger" onclick="removeHistoryItem('<?php echo htmlspecialchars($h['content_type'], ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$h['content_id']; ?>, this)">Delete</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <script>
    function removeFavorite(type, id, btn) {
        fetch('/multimedia/api/favorite/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content_type: type, content_id: id })
        }).then(r => r.json()).then(data => {
            if (data.success) {
                window.location.reload();
            }
        });
    }

    function removeHistoryItem(type, id, btn) {
        if (!confirm('Remove this item from your playback history?')) return;
        fetch('/multimedia/api/history/remove', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content_type: type, content_id: id })
        }).then(r => r.json()).then(data => {
            if (data.success) {
                window.location.reload();
            }
        });
    }

    function clearFullHistory() {
        if (!confirm('Are you sure you want to clear your entire playback history?')) return;
        fetch('/multimedia/api/history/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        }).then(r => r.json()).then(data => {
            if (data.success) {
                window.location.reload();
            }
        });
    }
    </script>
</body>
</html>


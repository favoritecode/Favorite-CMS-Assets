<?php
/**
 * Favorite Multimedia — Playback History View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🕒 Playback History</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Your watch and listening timeline (<?php echo (int)$total; ?> items).</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/multimedia/library" class="fav-mm-nav-link">My Library</a>
                <a href="/multimedia/my-list" class="fav-mm-nav-link">My List</a>
                <a href="/multimedia/history" class="fav-mm-nav-link active">History</a>
            </nav>
        </header>

        <!-- Filter tabs & Clear button -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
            <div class="fav-mm-genres">
                <a href="/multimedia/history" class="fav-mm-genre-pill <?php echo empty($currentType) ? 'active' : ''; ?>">All</a>
                <a href="/multimedia/history?type=movie" class="fav-mm-genre-pill <?php echo $currentType === 'movie' ? 'active' : ''; ?>">Movies</a>
                <a href="/multimedia/history?type=episode" class="fav-mm-genre-pill <?php echo $currentType === 'episode' ? 'active' : ''; ?>">Episodes</a>
                <a href="/multimedia/history?type=song" class="fav-mm-genre-pill <?php echo $currentType === 'song' ? 'active' : ''; ?>">Songs</a>
            </div>
            <?php if (!empty($items)): ?>
                <button type="button" style="background:#fee2e2; color:#dc2626; border:1px solid #fca5a5; padding:6px 14px; border-radius:6px; font-size:13px; font-weight:600; cursor:pointer;" onclick="clearHistory('<?php echo htmlspecialchars($currentType ?? '', ENT_QUOTES, 'UTF-8'); ?>')">Clear History</button>
            <?php endif; ?>
        </div>

        <?php if (empty($items)): ?>
            <div class="fav-mm-empty">
                <span class="fav-mm-empty-icon">⌛</span>
                <div class="fav-mm-empty-title">No History Found</div>
                <p class="fav-mm-empty-desc">Items you play will be recorded here for easy access.</p>
            </div>
        <?php else: ?>
            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; margin-bottom: 24px;">
                <?php foreach ($items as $h): ?>
                    <div style="display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; border-bottom: 1px solid #f1f5f9; gap: 16px;">
                        <div style="display: flex; align-items: center; gap: 14px; min-width: 0;">
                            <span style="font-size: 18px;"><?php echo ($h['content_type'] === 'song') ? '🎵' : '🎬'; ?></span>
                            <div style="min-width: 0;">
                                <a href="<?php echo htmlspecialchars($h['url'], ENT_QUOTES, 'UTF-8'); ?>" style="font-weight: 600; font-size: 14px; color: #0f172a; text-decoration: none;">
                                    <?php echo htmlspecialchars($h['title'], ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                                <div style="font-size: 12px; color: #64748b; margin-top: 2px;">
                                    <span><?php echo ucfirst($h['content_type']); ?></span> &bull;
                                    <span><?php echo $h['is_completed'] ? '✅ Completed' : round((float)$h['percentage']) . '% played'; ?></span> &bull;
                                    <span>Played on <?php echo date('M d, Y H:i', strtotime($h['last_played_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                        <div style="display: flex; gap: 8px; flex-shrink: 0;">
                            <a href="<?php echo htmlspecialchars($h['url'], ENT_QUOTES, 'UTF-8'); ?>" style="background: #f1f5f9; color: #2563eb; border: 1px solid #cbd5e1; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: 600; text-decoration: none;">Play</a>
                            <button type="button" style="background: #f1f5f9; color: #dc2626; border: 1px solid #cbd5e1; padding: 6px 12px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer;" onclick="deleteItem('<?php echo htmlspecialchars($h['content_type'], ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$h['content_id']; ?>)">Delete</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="fav-mm-pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="/multimedia/history?<?php echo http_build_query(array_filter(['type' => $currentType, 'p' => $i])); ?>" class="fav-mm-page-link <?php echo $i === $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
    function deleteItem(type, id) {
        if (!confirm('Remove this item from your history?')) return;
        fetch('/multimedia/api/history/remove', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content_type: type, content_id: id })
        }).then(r => r.json()).then(d => { if (d.success) location.reload(); });
    }

    function clearHistory(type) {
        if (!confirm('Clear your history?')) return;
        fetch('/multimedia/api/history/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content_type: type })
        }).then(r => r.json()).then(d => { if (d.success) location.reload(); });
    }
    </script>
</body>
</html>


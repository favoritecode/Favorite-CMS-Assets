<?php
/**
 * Favorite Multimedia — Web Series Catalog View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">📺 Web Series</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Binge-watch seasons and episodes</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link active">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
            </nav>
        </header>

        <!-- Filter Bar -->
        <form method="GET" action="/series" class="fav-mm-filter-bar">
            <input type="text" name="q" class="fav-mm-search-input" value="<?php echo htmlspecialchars($searchQuery ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search web series...">
            <select name="genre" class="fav-mm-select" onchange="this.form.submit()">
                <option value="">All Genres</option>
                <?php foreach ($genres as $g): ?>
                    <option value="<?php echo $g->slug; ?>" <?php echo ($currentGenre === $g->slug) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($g->name, ENT_QUOTES, 'UTF-8'); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Filter</button>
        </form>

        <!-- Series Grid -->
        <div class="fav-mm-grid">
            <?php if (empty($items)): ?>
                <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                    <span class="fav-mm-empty-icon">📺</span>
                    <div class="fav-mm-empty-title">No Web Series Found</div>
                    <p class="fav-mm-empty-desc">No series matched your filter criteria. <a href="/series" style="color: #2563eb; font-weight: 600;">Reset all filters &rarr;</a></p>
                </div>
            <?php else: foreach ($items as $s): ?>
                <a href="/series/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                    <div class="fav-mm-poster-wrap">
                        <span class="fav-badge fav-badge-<?php echo strtolower($s->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($s->access_mode ?? 'public'); ?></span>
                        <?php if ($s->poster): ?>
                            <img src="<?php echo htmlspecialchars($s->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                        <?php else: ?>
                            <div class="fav-mm-placeholder fav-mm-placeholder-series">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></svg>
                                <span>Series</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="fav-mm-card-body">
                        <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                        <div class="fav-mm-card-meta">
                            <span><?php echo $s->release_year ?: '—'; ?></span>
                            <span><?php echo count($s->getSeasons()); ?> Seasons</span>
                        </div>
                    </div>
                </a>
            <?php endforeach; endif; ?>
        </div>
    </div>

</body>
</html>


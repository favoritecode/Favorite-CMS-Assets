<?php
/**
 * Favorite Multimedia — Artist Profile & Catalog
 */
$artistName = htmlspecialchars($artist->name ?? 'Artist', ENT_QUOTES, 'UTF-8');
$artistBio = htmlspecialchars($artist->biography ?? ($artist->bio ?? ''), ENT_QUOTES, 'UTF-8');
$artistPhoto = htmlspecialchars($artist->photo ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Header & Navigation -->
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🎤 Artist Profile</h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/multimedia/discover" class="fav-mm-nav-link">Discover</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
                <?php if (!empty($user)): ?>
                    <a href="/multimedia/library" class="fav-mm-nav-link">My Library</a>
                <?php endif; ?>
            </nav>
        </header>

        <!-- Artist Hero Banner -->
        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:12px; padding:28px; display:flex; gap:24px; align-items:center; flex-wrap:wrap; margin-bottom:36px;">
            <?php if ($artistPhoto): ?>
                <img src="<?= $artistPhoto ?>" alt="<?= $artistName ?>" style="width:120px; height:120px; border-radius:50%; object-fit:cover; border:3px solid #2563eb;">
            <?php else: ?>
                <div style="width:120px; height:120px; border-radius:50%; background:#2563eb; color:#fff; display:flex; align-items:center; justify-content:center; font-size:40px; font-weight:700;">
                    <?= strtoupper(substr($artistName, 0, 1)) ?>
                </div>
            <?php endif; ?>
            <div style="flex:1; min-width:260px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 8px;">
                    <h2 style="font-size:26px; font-weight:800; margin:0; color:#0f172a;"><?= $artistName ?></h2>
                    <?php if (!empty($user)): ?>
                        <button type="button" class="fmm-btn-follow <?= !empty($isFollowing) ? 'active' : '' ?>" data-fmm-subscribe-toggle data-target-type="artist" data-target-id="<?= (int)$artist->id ?>">
                            <span class="fmm-follow-icon"><?= !empty($isFollowing) ? '✓' : '+' ?></span>
                            <span class="fmm-follow-label"><?= !empty($isFollowing) ? 'Following' : 'Follow Artist' ?></span>
                        </button>
                    <?php endif; ?>
                </div>
                <?php if ($artistBio): ?>
                    <p style="margin:0; color:#475569; font-size:14px; line-height:1.6; max-width:640px;"><?= nl2br($artistBio) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Discography: Songs -->
        <?php if (!empty($songs)): ?>
            <section style="margin-bottom: 40px;">
                <h3 style="font-size:20px; font-weight:700; margin:0 0 16px 0;">🎵 Popular Tracks</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($songs as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- Discography: Albums -->
        <?php if (!empty($albums)): ?>
            <section style="margin-bottom: 40px;">
                <h3 style="font-size:20px; font-weight:700; margin:0 0 16px 0;">💿 Albums</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($albums as $alb): ?>
                        <?php
                            $albCover = htmlspecialchars($alb->cover ?? '', ENT_QUOTES, 'UTF-8');
                            $albTitle = htmlspecialchars($alb->title ?? 'Untitled Album', ENT_QUOTES, 'UTF-8');
                            $albSlug = htmlspecialchars($alb->slug ?? '', ENT_QUOTES, 'UTF-8');
                            $albYear = !empty($alb->release_date) ? substr((string)$alb->release_date, 0, 4) : 'Album';
                        ?>
                        <div class="fav-mm-card fav-discovery-card">
                            <div class="fav-discovery-poster-wrap">
                                <?php if ($albCover): ?>
                                    <img src="<?= $albCover ?>" alt="<?= $albTitle ?>" class="fav-discovery-poster" loading="lazy">
                                <?php else: ?>
                                    <div class="fav-discovery-placeholder">
                                        <span>💿</span>
                                    </div>
                                <?php endif; ?>
                                <span class="fav-type-badge">Album</span>
                            </div>
                            <div class="fav-discovery-body">
                                <h4 class="fav-discovery-title">
                                    <a href="/multimedia/album/<?= $albSlug ?>"><?= $albTitle ?></a>
                                </h4>
                                <div class="fav-discovery-meta">
                                    <span class="fav-discovery-meta-text"><?= $albYear ?></span>
                                    <a href="/multimedia/album/<?= $albSlug ?>" class="fav-discovery-play-btn">View &rarr;</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- Featured Playlists -->
        <?php if (!empty($playlists)): ?>
            <section style="margin-bottom: 40px;">
                <h3 style="font-size:20px; font-weight:700; margin:0 0 16px 0;">🎼 Playlists Featuring <?= $artistName ?></h3>
                <div class="fav-mm-grid">
                    <?php foreach ($playlists as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

    </div>

</body>
</html>

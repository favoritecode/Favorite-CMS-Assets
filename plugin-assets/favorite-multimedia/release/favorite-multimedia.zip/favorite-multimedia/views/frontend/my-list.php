<?php
/**
 * Favorite Multimedia - My List (Favorites) View
 *
 * @var array $favorites Array of favorite items
 * @var array $counts    Counts by type
 * @var string $type     Current filter type ('all', 'movie', 'series', 'song', 'playlist')
 * @var array $user      Current user array
 */
$type = $type ?? 'all';
$favorites = $favorites ?? ($items ?? []);
$counts = $counts ?? ['movie' => 0, 'series' => 0, 'song' => 0, 'playlist' => 0];
$totalCount = $total ?? (count($favorites) ?: array_sum($counts));
?>

<div class="fmm-container fmm-my-list-page">
    <div class="fmm-page-header">
        <div class="fmm-page-title-group">
            <h1 class="fmm-page-title">My List</h1>
            <p class="fmm-page-subtitle">Your saved movies, series, songs, and playlists (<?= (int)$totalCount ?> saved)</p>
        </div>
        <div class="fmm-header-actions">
            <a href="/multimedia/library" class="fmm-btn fmm-btn-secondary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to Library
            </a>
            <a href="/multimedia/history" class="fmm-btn fmm-btn-outline">Watch History</a>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div class="fmm-tabs-nav">
        <a href="/multimedia/my-list" class="fmm-tab-item <?= $type === 'all' ? 'active' : '' ?>">
            All (<?= (int)$totalCount ?>)
        </a>
        <a href="/multimedia/my-list?type=movie" class="fmm-tab-item <?= $type === 'movie' ? 'active' : '' ?>">
            Movies (<?= (int)($counts['movie'] ?? 0) ?>)
        </a>
        <a href="/multimedia/my-list?type=series" class="fmm-tab-item <?= $type === 'series' ? 'active' : '' ?>">
            Series (<?= (int)($counts['series'] ?? 0) ?>)
        </a>
        <a href="/multimedia/my-list?type=song" class="fmm-tab-item <?= $type === 'song' ? 'active' : '' ?>">
            Songs (<?= (int)($counts['song'] ?? 0) ?>)
        </a>
        <a href="/multimedia/my-list?type=playlist" class="fmm-tab-item <?= $type === 'playlist' ? 'active' : '' ?>">
            Playlists (<?= (int)($counts['playlist'] ?? 0) ?>)
        </a>
    </div>

    <?php if (empty($favorites)): ?>
        <div class="fmm-empty-state">
            <div class="fmm-empty-icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
            </div>
            <h3>Your list is empty</h3>
            <p>Save movies, shows, and music here so you can easily find and watch them anytime.</p>
            <a href="/multimedia" class="fmm-btn fmm-btn-primary">Browse Catalog</a>
        </div>
    <?php else: ?>
        <div class="fmm-grid fmm-grid-5">
            <?php foreach ($favorites as $item): ?>
                <?php
                    $cType = $item['content_type'];
                    $cId = (int)$item['content_id'];
                    $data = $item['content'] ?? [];
                    $title = htmlspecialchars($data['title'] ?? ($item['title'] ?? 'Untitled'), ENT_QUOTES, 'UTF-8');
                    $poster = !empty($data['poster_image']) ? htmlspecialchars($data['poster_image'], ENT_QUOTES, 'UTF-8') : htmlspecialchars($item['poster'] ?? '', ENT_QUOTES, 'UTF-8');
                    $detailUrl = $item['url'] ?? '#';
                    $badge = ucfirst($cType);
                    $meta = '';
                    if ($cType === 'movie' && !empty($data['release_year'])) {
                        $meta = $data['release_year'];
                    } elseif ($cType === 'series') {
                        $meta = 'Series';
                    } elseif ($cType === 'song') {
                        $meta = 'Song';
                    } elseif ($cType === 'playlist') {
                        $meta = 'Playlist';
                    }
                ?>
                <div class="fmm-card fmm-favorite-card" data-favorite-id="<?= (int)$item['id'] ?>" data-content-type="<?= htmlspecialchars($cType, ENT_QUOTES, 'UTF-8') ?>" data-content-id="<?= $cId ?>">
                    <div class="fmm-card-media">
                        <?php if ($poster): ?>
                            <img src="<?= $poster ?>" alt="<?= $title ?>" loading="lazy">
                        <?php else: ?>
                            <div class="fmm-card-placeholder">
                                <span><?= strtoupper(substr($title, 0, 2)) ?></span>
                            </div>
                        <?php endif; ?>
                        <span class="fmm-badge fmm-badge-<?= $cType ?>"><?= $badge ?></span>
                        <div class="fmm-card-actions-overlay">
                            <button type="button" class="fmm-fav-remove-btn" data-fmm-fav-toggle data-content-type="<?= htmlspecialchars($cType, ENT_QUOTES, 'UTF-8') ?>" data-content-id="<?= $cId ?>" title="Remove from My List">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                            </button>
                        </div>
                    </div>
                    <div class="fmm-card-body">
                        <h4 class="fmm-card-title">
                            <a href="<?= htmlspecialchars($detailUrl, ENT_QUOTES, 'UTF-8') ?>"><?= $title ?></a>
                        </h4>
                        <?php if ($meta): ?>
                            <div class="fmm-card-meta">
                                <span><?= htmlspecialchars($meta, ENT_QUOTES, 'UTF-8') ?></span>
                                <span class="fmm-date-added">Added <?= date('M j, Y', strtotime($item['created_at'])) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

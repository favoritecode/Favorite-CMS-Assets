<?php
/**
 * Favorite Multimedia — Playlists Catalog View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🎼 Audio Playlists</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Curated albums and continuous music collections</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link active">Playlists</a>
            </nav>
        </header>

        <div class="fav-mm-grid">
            <?php if (empty($items)): ?>
                <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                    <span class="fav-mm-empty-icon">🎼</span>
                    <div class="fav-mm-empty-title">No Playlists Available</div>
                    <p class="fav-mm-empty-desc">No curated playlists have been published yet. Check back soon!</p>
                </div>
            <?php else: foreach ($items as $pl): ?>
                <a href="/playlist/<?php echo htmlspecialchars($pl->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                    <div class="fav-mm-poster-wrap fav-mm-poster-square">
                        <span class="fav-badge fav-badge-<?php echo strtolower($pl->access_mode ?? 'public'); ?> fav-mm-card-badge">PLAYLIST</span>
                        <?php if ($pl->cover): ?>
                            <img src="<?php echo htmlspecialchars($pl->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($pl->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                        <?php else: ?>
                            <div class="fav-mm-placeholder fav-mm-placeholder-playlist">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                                <span>Playlist</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="fav-mm-card-body">
                        <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($pl->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                        <div class="fav-mm-card-meta">
                            <span><?php echo count($pl->getSongs()); ?> Tracks</span>
                            <span>Play &rarr;</span>
                        </div>
                    </div>
                </a>
            <?php endforeach; endif; ?>
        </div>
    </div>

</body>
</html>


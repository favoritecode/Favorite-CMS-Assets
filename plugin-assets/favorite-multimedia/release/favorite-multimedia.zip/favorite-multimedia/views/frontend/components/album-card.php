<?php
/**
 * 1:1 Square Music Card Component (Albums, Spotlight Songs, Playlists).
 *
 * @var object|array $item
 * @var bool $showMetadata
 */

use FavoriteCMS\Multimedia\Models\Song;
use FavoriteCMS\Multimedia\Models\Album;
use FavoriteCMS\Multimedia\Models\Artist;
use FavoriteCMS\Multimedia\Models\Playlist;

if (is_array($item)) {
    $itemObj = (object)$item;
} else {
    $itemObj = $item;
}

$id = (int)($itemObj->id ?? 0);
$title = (string)($itemObj->title ?? $itemObj->name ?? 'Untitled');
$slug = (string)($itemObj->slug ?? '');
$slugOrId = $slug !== '' ? $slug : (string)$id;

// Resolve entity type and canonical public URL
if ($item instanceof Song || isset($itemObj->playback_type) || isset($itemObj->lyrics) || isset($itemObj->duration)) {
    $cardType = 'song';
    $url = '/multimedia/song/' . $slugOrId;
} elseif ($item instanceof Playlist || isset($itemObj->is_collaborative)) {
    $cardType = 'playlist';
    $url = '/playlist/' . $slugOrId;
} elseif ($item instanceof Artist || isset($itemObj->biography)) {
    $cardType = 'artist';
    $url = '/multimedia/artist/' . $slugOrId;
} else {
    $cardType = 'album';
    $url = '/multimedia/album/' . $slugOrId;
}

$cover = (string)($itemObj->cover_image ?? $itemObj->poster_image ?? $itemObj->cover ?? $itemObj->photo ?? '');
$year = (string)($itemObj->release_year ?? $itemObj->year ?? '');
if ($year === '' && !empty($itemObj->release_date)) {
    $year = substr((string)$itemObj->release_date, 0, 4);
}

$artistName = '';
if (is_object($item) && method_exists($item, 'getArtist')) {
    $artist = $item->getArtist();
    $artistName = $artist ? (string)$artist->name : '';
} elseif (isset($itemObj->artist_name)) {
    $artistName = (string)$itemObj->artist_name;
}

$placeholderIcon = match ($cardType) {
    'album' => '💿',
    'artist' => '🎤',
    'playlist' => '📑',
    default => '🎵',
};
?>
<article class="fm-card fm-album-card fm-music-card fm-music-card-<?php echo htmlspecialchars($cardType, ENT_QUOTES, 'UTF-8'); ?>" data-id="<?php echo $id; ?>" data-entity="<?php echo htmlspecialchars($cardType, ENT_QUOTES, 'UTF-8'); ?>">
    <!-- Clickable Artwork Container -->
    <a href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>" class="fm-card-media" aria-label="<?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?>" tabindex="-1">
        <?php if ($cover !== ''): ?>
            <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?>" class="fm-card-img fm-aspect-square" loading="lazy" onerror="this.style.display='none'; if(this.nextElementSibling){this.nextElementSibling.style.display='flex';}">
            <div class="fm-card-placeholder fm-aspect-square" style="display:none;" aria-hidden="true">
                <span><?php echo $placeholderIcon; ?></span>
            </div>
        <?php else: ?>
            <div class="fm-card-placeholder fm-aspect-square" aria-hidden="true">
                <span><?php echo $placeholderIcon; ?></span>
            </div>
        <?php endif; ?>

        <!-- Hover Play Indicator -->
        <div class="fm-card-hover-overlay" aria-hidden="true">
            <div class="fm-hover-play-btn fm-btn-circle">▶</div>
        </div>
    </a>

    <!-- Card Metadata Body -->
    <div class="fm-card-body">
        <h3 class="fm-card-title">
            <a href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>" class="fm-card-link-title"><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></a>
        </h3>

        <div class="fm-card-meta">
            <?php if ($artistName !== ''): ?>
                <span class="fm-card-artist"><?php echo htmlspecialchars($artistName, ENT_QUOTES, 'UTF-8'); ?></span>
            <?php endif; ?>
            <?php if (!empty($showMetadata) && $year !== ''): ?>
                <span class="fm-meta-year"><?php echo htmlspecialchars($year, ENT_QUOTES, 'UTF-8'); ?></span>
            <?php endif; ?>
        </div>
    </div>
</article>

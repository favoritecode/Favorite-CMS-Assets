<?php
/**
 * Favorite Multimedia — Songs Catalog View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🎵 Music &amp; Songs</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Stream high quality music and audio tracks</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link active">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
            </nav>
        </header>

        <form method="GET" action="/songs" class="fav-mm-filter-bar">
            <input type="text" name="q" class="fav-mm-search-input" value="<?php echo htmlspecialchars($searchQuery ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search songs, artists, lyrics...">
            <button type="submit" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Search</button>
        </form>

        <div class="fav-mm-grid">
            <?php if (empty($items)): ?>
                <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                    <span class="fav-mm-empty-icon">🎵</span>
                    <div class="fav-mm-empty-title">No Songs Found</div>
                    <p class="fav-mm-empty-desc">No tracks matched your search query. <a href="/songs" style="color: #2563eb; font-weight: 600;">View all tracks &rarr;</a></p>
                </div>
            <?php else: foreach ($items as $s): ?>
                <a href="/song/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                    <div class="fav-mm-poster-wrap fav-mm-poster-square">
                        <span class="fav-badge fav-badge-<?php echo strtolower($s->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($s->access_mode ?? 'public'); ?></span>
                        <?php if ($s->cover): ?>
                            <img src="<?php echo htmlspecialchars($s->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                        <?php else: ?>
                            <div class="fav-mm-placeholder fav-mm-placeholder-audio">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                                <span>Song</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="fav-mm-card-body">
                        <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                        <div class="fav-mm-card-meta">
                            <span><?php echo htmlspecialchars($s->getArtist()?->name ?: 'Various', ENT_QUOTES, 'UTF-8'); ?></span>
                            <span><?php echo $s->getDurationFormatted(); ?></span>
                        </div>
                    </div>
                </a>
            <?php endforeach; endif; ?>
        </div>
    </div>

</body>
</html>


<?php
/**
 * Favorite Multimedia — Movies Catalog View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🎬 Movies</h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">Browse and stream movies</p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link active">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
            </nav>
        </header>

        <!-- Filter Bar -->
        <form method="GET" action="/movies" class="fav-mm-filter-bar">
            <input type="text" name="q" class="fav-mm-search-input" value="<?php echo htmlspecialchars($searchQuery ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search movies by title, director, cast...">
            <select name="genre" class="fav-mm-select" onchange="this.form.submit()">
                <option value="">All Genres</option>
                <?php foreach ($genres as $g): ?>
                    <option value="<?php echo $g->slug; ?>" <?php echo ($currentGenre === $g->slug) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($g->name, ENT_QUOTES, 'UTF-8'); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Filter</button>
        </form>

        <!-- Movies Grid -->
        <div class="fav-mm-grid">
            <?php if (empty($items)): ?>
                <div class="fav-mm-empty" style="grid-column: 1 / -1;">
                    <span class="fav-mm-empty-icon">🎬</span>
                    <div class="fav-mm-empty-title">No Movies Found</div>
                    <p class="fav-mm-empty-desc">No movies matched your filter criteria. <a href="/movies" style="color: #2563eb; font-weight: 600;">Reset all filters &rarr;</a></p>
                </div>
            <?php else: foreach ($items as $m): ?>
                <a href="/movie/<?php echo htmlspecialchars($m->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                    <div class="fav-mm-poster-wrap">
                        <span class="fav-badge fav-badge-<?php echo strtolower($m->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($m->access_mode ?? 'public'); ?></span>
                        <?php if ($m->poster): ?>
                            <img src="<?php echo htmlspecialchars($m->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                        <?php else: ?>
                            <div class="fav-mm-placeholder fav-mm-placeholder-movie">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M19.82 2H4.18C2.97 2 2 2.97 2 4.18v15.64C2 21.03 2.97 22 4.18 22h15.64c1.21 0 2.18-.97 2.18-2.18V4.18C22 2.97 21.03 2 19.82 2zM7 2v20M17 2v20M2 12h20M2 7h5M2 17h5M17 17h5M17 7h5"/></svg>
                                <span>Movie</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="fav-mm-card-body">
                        <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                        <div class="fav-mm-card-meta">
                            <span><?php echo $m->release_year ?: '—'; ?></span>
                            <span><?php echo $m->getDurationFormatted(); ?></span>
                        </div>
                    </div>
                </a>
            <?php endforeach; endif; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div style="display: flex; justify-content: center; gap: 8px; margin-top: 32px;">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="/movies?p=<?php echo $i; ?><?php echo $currentGenre ? '&genre=' . urlencode($currentGenre) : ''; ?><?php echo $searchQuery ? '&q=' . urlencode($searchQuery) : ''; ?>" 
                       style="padding: 8px 14px; border-radius: 4px; text-decoration: none; font-weight: 600; <?php echo ($i === $page) ? 'background: #2563eb; color: #fff;' : 'background: #fff; border: 1px solid #cbd5e1; color: #334155;'; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>


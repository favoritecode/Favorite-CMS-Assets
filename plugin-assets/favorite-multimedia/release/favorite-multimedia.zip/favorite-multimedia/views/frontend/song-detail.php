<?php
/**
 * Favorite Multimedia — Song Detail, Audio & Music Video Player View
 */
$hasAudio = !empty($hasAudio);
$hasVideo = !empty($hasVideo);
$isDualMode = ($hasAudio && $hasVideo);

$defaultVideo = $defaultVideoSource ?? ($videoSources[0] ?? null);
$videoIsHls = ($defaultVideo && ($defaultVideo['player_type'] ?? '') === 'hls');
$videoIsEmbed = ($defaultVideo && ($defaultVideo['player_type'] ?? '') === 'embed');
$videoPlayableUrl = $defaultVideo['url'] ?? '';
$videoPlayableMime = $defaultVideo['mime_type'] ?? 'video/mp4';

// Determine initial playback mode
if ($isDualMode) {
    $initialMode = ($defaultPlaybackMode === 'video') ? 'video' : 'audio';
} elseif ($hasVideo) {
    $initialMode = 'video';
} elseif ($hasAudio) {
    $initialMode = 'audio';
} else {
    $initialMode = 'none';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <?php if (!empty($metaDescription)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($metaDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
    <style>
        .fav-mode-pill {
            background: #1e293b;
            color: #94a3b8;
            border: 1px solid #334155;
            padding: 8px 20px;
            border-radius: 9999px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .fav-mode-pill:hover {
            color: #f8fafc;
            border-color: #475569;
        }
        .fav-mode-pill.active {
            background: #2563eb;
            color: #ffffff;
            border-color: #3b82f6;
            box-shadow: 0 2px 10px rgba(37, 99, 235, 0.4);
        }
    </style>
</head>
<body style="background: #0f172a; color: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header" style="border-color: #1e293b;">
            <div>
                <a href="/songs" style="color: #94a3b8; text-decoration: none; font-size: 14px;">&larr; Back to Songs</a>
                <h1 style="color: #fff; font-size: 26px; margin: 6px 0 0 0;"><?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?></h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link active">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
            </nav>
        </header>

        <!-- Access Control Gating (Fail-Closed) -->
        <?php if ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED): ?>
            <div class="fav-restriction-card" style="max-width: 680px; margin: 20px auto 40px auto; background: #1e293b; border-radius: 8px; padding: 36px 20px; text-align: center;">
                <div style="font-size: 40px; margin-bottom: 12px;">🔒</div>
                <h3 style="font-size: 20px; color: #fff; margin-bottom: 8px;">Login Required</h3>
                <p style="color: #94a3b8; font-size: 14px; max-width: 420px; margin: 0 auto 20px auto;">Sign in to unlock full audio and music video playback for this track.</p>
                <a href="/admin/login?redirect=<?php echo urlencode('/song/' . $song->slug); ?>" class="fav-btn-cta" style="display: inline-block;">Sign In to Listen</a>
            </div>
        <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED): ?>
            <div class="fav-restriction-card" style="max-width: 680px; margin: 20px auto 40px auto; background: #1e293b; border-radius: 8px; padding: 36px 20px; text-align: center;">
                <div style="font-size: 40px; margin-bottom: 12px;">⭐</div>
                <h3 style="font-size: 20px; color: #fff; margin-bottom: 8px;">Premium Membership Required</h3>
                <p style="color: #94a3b8; font-size: 14px; max-width: 420px; margin: 0 auto 20px auto;">Upgrade with Favorite Digital to stream this exclusive track and its official music video.</p>
                <a href="<?php echo \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::getSubscriptionUrl(); ?>" class="fav-btn-cta" style="display: inline-block;">Upgrade Membership</a>
            </div>
        <?php elseif ($initialMode === 'none'): ?>
            <div class="fav-restriction-card" style="max-width: 680px; margin: 20px auto 40px auto; background: #1e293b; border: 1px dashed #334155; border-radius: 8px; padding: 36px 20px; text-align: center;">
                <div style="font-size: 40px; margin-bottom: 12px;">🎵</div>
                <h3 style="font-size: 20px; color: #fff; margin-bottom: 8px;">Media Coming Soon</h3>
                <p style="color: #94a3b8; font-size: 14px; margin: 0;">Playback sources for this track are currently being processed or prepared.</p>
            </div>
        <?php else: ?>

            <!-- Dual-Mode Toggle Pills (Rendered ONLY when BOTH Audio and Video exist) -->
            <?php if ($isDualMode): ?>
                <div class="fav-mode-switch-wrapper" style="display: flex; justify-content: center; gap: 12px; margin-bottom: 24px;">
                    <button type="button" class="fav-mode-pill <?php echo ($initialMode === 'audio') ? 'active' : ''; ?>" id="fav_mode_pill_audio" onclick="switchSongPlaybackMode('audio')">
                        🎵 Audio Track
                    </button>
                    <button type="button" class="fav-mode-pill <?php echo ($initialMode === 'video') ? 'active' : ''; ?>" id="fav_mode_pill_video" onclick="switchSongPlaybackMode('video')">
                        🎬 Music Video
                    </button>
                </div>
            <?php endif; ?>

            <!-- PLAYER CONTAINER 1: Audio Player Card -->
            <div id="fav_song_audio_container" class="fav-audio-player-box" style="margin-bottom: 32px; <?php echo ($initialMode !== 'audio') ? 'display:none;' : ''; ?>">
                <?php if ($hasAudio && $defaultAudioSource): ?>
                    <audio preload="metadata" style="display: none;"></audio>

                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div class="fav-audio-now-playing" style="margin-bottom: 0;">
                            <?php if ($song->cover): ?>
                                <img src="<?php echo htmlspecialchars($song->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="fav-audio-artwork">
                            <?php else: ?>
                                <div class="fav-audio-artwork" style="display: flex; align-items: center; justify-content: center; font-size: 32px;">🎵</div>
                            <?php endif; ?>
                            <div class="fav-audio-info">
                                <h3 class="fav-audio-title"><?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                                <p class="fav-audio-artist"><?php echo htmlspecialchars($song->getArtist()?->name ?: 'Unknown Artist', ENT_QUOTES, 'UTF-8'); ?></p>
                            </div>
                        </div>

                        <!-- Audio Source Switcher (Visible if 2+ audio sources exist) -->
                        <?php if (count($audioSources) > 1): ?>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <label for="fav_audio_source_select" style="font-size: 11px; color: #94a3b8; font-weight: 500;">Server:</label>
                                <select class="fav-control-select" id="fav_audio_source_select" onchange="switchSongAudioSource(this.value)" style="background:#1e293b; color:#fff; border:1px solid #334155; padding:4px 8px; border-radius:4px; font-size:12px;">
                                    <?php foreach ($audioSources as $as): ?>
                                        <option value="<?php echo (int)$as['id']; ?>" data-url="<?php echo htmlspecialchars($as['url'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo !empty($as['is_default']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($as['label'], ENT_QUOTES, 'UTF-8'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Progress Bar -->
                    <div class="fav-progress-bar-container" style="background: rgba(255,255,255,0.15); height: 6px; border-radius: 3px; cursor: pointer;">
                        <div class="fav-progress-filled" style="background: #2563eb; height: 100%; width: 0%;"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 12px; color: #94a3b8; margin-top: 6px;">
                        <span class="fav-time-display">0:00 / <?php echo $song->getDurationFormatted(); ?></span>
                        <?php if (!empty($downloadInfo['allowed'])): ?>
                            <a href="/multimedia/download/<?php echo $defaultAudioSource['id']; ?>" class="fav-btn-download" style="padding: 2px 8px; font-size: 11px;">
                                &#8595; Download MP3
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Audio Controls -->
                    <div class="fav-audio-controls-row" style="display:flex; justify-content:center; align-items:center; gap:16px;">
                        <button type="button" class="fav-audio-btn-big fav-audio-btn-play" aria-label="Play">&#9654;</button>
                        <?php if (!empty($user)): ?>
                            <button type="button" class="fav-btn-favorite <?= !empty($isFavorite) ? 'active' : '' ?>" data-fmm-fav-toggle data-content-type="song" data-content-id="<?= (int)$song->id ?>">
                                <span class="fav-icon-star">★</span>
                                <span class="fav-btn-label"><?= !empty($isFavorite) ? 'In My List' : 'Add to My List' ?></span>
                            </button>
                        <?php endif; ?>
                    </div>

                    <!-- Hidden data row for single track player init -->
                    <table style="display: none;">
                        <tr class="fav-playlist-row" 
                            data-song-id="<?php echo (int)$song->id; ?>"
                            data-stream-url="<?php echo htmlspecialchars($defaultAudioSource['url'], ENT_QUOTES, 'UTF-8'); ?>" 
                            data-title="<?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?>" 
                            data-artist="<?php echo htmlspecialchars($song->getArtist()?->name ?: 'Unknown Artist', ENT_QUOTES, 'UTF-8'); ?>" 
                            data-cover="<?php echo htmlspecialchars($song->cover ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                            data-can-download="<?php echo (!empty($downloadInfo['allowed'])) ? '1' : '0'; ?>"
                            data-download-url="/multimedia/download/<?php echo $defaultAudioSource['id']; ?>">
                        </tr>
                    </table>
                <?php else: ?>
                    <p style="text-align: center; color: #94a3b8; margin: 20px 0;">Audio track not available.</p>
                <?php endif; ?>
            </div>

            <!-- PLAYER CONTAINER 2: Video / Music Video Player Stage -->
            <div id="fav_song_video_container" style="max-width: 960px; margin: 0 auto 32px auto; <?php echo ($initialMode !== 'video') ? 'display:none;' : ''; ?>">
                <?php if ($hasVideo && !empty($videoSources)): ?>
                    <div class="fav-video-wrapper" 
                         data-content-type="song" 
                         data-content-id="<?php echo (int)$song->id; ?>" 
                         data-resume-position="<?php echo (!empty($progress['should_resume'])) ? (float)$progress['position'] : 0; ?>"
                         data-sources='<?php echo htmlspecialchars(json_encode($videoSources), ENT_QUOTES, 'UTF-8'); ?>'
                         <?php if ($videoIsHls): ?>data-hls-src="<?php echo htmlspecialchars($videoPlayableUrl, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?>>
                        
                        <?php if ($videoIsEmbed): ?>
                            <iframe src="<?php echo htmlspecialchars($videoPlayableUrl, ENT_QUOTES, 'UTF-8'); ?>" class="fav-embed-element" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen sandbox="allow-scripts allow-same-origin allow-presentation allow-fullscreen"></iframe>
                        <?php else: ?>
                            <video class="fav-video-element" poster="<?php echo htmlspecialchars($song->cover ?? '', ENT_QUOTES, 'UTF-8'); ?>" preload="metadata" playsinline>
                                <?php if (!$videoIsHls && $videoPlayableUrl): ?>
                                    <source src="<?php echo htmlspecialchars($videoPlayableUrl, ENT_QUOTES, 'UTF-8'); ?>" type="<?php echo htmlspecialchars($videoPlayableMime, ENT_QUOTES, 'UTF-8'); ?>">
                                <?php endif; ?>
                                <?php foreach ($subtitles as $sub): ?>
                                    <track kind="subtitles" label="<?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?>" srclang="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>" src="/multimedia/subtitle/<?php echo $sub->id; ?>" <?php echo $sub->is_default ? 'default' : ''; ?>>
                                <?php endforeach; ?>
                            </video>

                            <!-- Video Controls Overlay -->
                            <div class="fav-player-controls">
                                <div class="fav-progress-bar-container">
                                    <div class="fav-progress-filled">
                                        <span class="fav-progress-scrubber"></span>
                                    </div>
                                </div>
                                <div class="fav-controls-row">
                                    <div class="fav-controls-left">
                                        <button type="button" class="fav-btn-control fav-btn-play" aria-label="Play">
                                            <span class="fav-icon-play">&#9654;</span>
                                            <span class="fav-icon-pause" style="display:none;">&#10074;&#10074;</span>
                                        </button>
                                        <div class="fav-volume-wrapper">
                                            <button type="button" class="fav-btn-control fav-btn-volume" aria-label="Volume">&#128266;</button>
                                            <input type="range" class="fav-volume-slider" min="0" max="1" step="0.05" value="1">
                                        </div>
                                        <div class="fav-time-display">0:00 / 0:00</div>
                                    </div>
                                    <div class="fav-controls-right">
                                        <?php if (count($videoSources) > 1): ?>
                                            <select class="fav-control-select fav-source-select" title="Switch Video Source" aria-label="Switch Playback Source">
                                                <?php foreach ($videoSources as $vs): ?>
                                                    <option value="<?php echo (int)$vs['id']; ?>" <?php echo !empty($vs['is_default']) ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($vs['label'], ENT_QUOTES, 'UTF-8'); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php endif; ?>

                                        <?php if (!empty($subtitles)): ?>
                                            <select class="fav-control-select fav-subtitle-select" title="Subtitles">
                                                <option value="off">CC Off</option>
                                                <?php foreach ($subtitles as $sub): ?>
                                                    <option value="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $sub->is_default ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php endif; ?>

                                        <select class="fav-control-select fav-speed-select" title="Playback Speed">
                                            <option value="0.5">0.5x</option>
                                            <option value="0.75">0.75x</option>
                                            <option value="1" selected>1x</option>
                                            <option value="1.25">1.25x</option>
                                            <option value="1.5">1.5x</option>
                                            <option value="2">2x</option>
                                        </select>
                                        <button type="button" class="fav-btn-control fav-btn-fullscreen" aria-label="Fullscreen">&#x26F6;</button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p style="text-align: center; color: #94a3b8; margin: 20px 0;">Music video stream not available.</p>
                <?php endif; ?>
            </div>

        <?php endif; ?>

        <!-- Lyrics & Liner Notes -->
        <?php if (!empty($song->lyrics)): ?>
            <div style="max-width: 680px; margin: 0 auto; background: #1e293b; border-radius: 8px; padding: 24px;">
                <h3 style="margin-top: 0; font-size: 16px; color: #fff;">Lyrics</h3>
                <div style="white-space: pre-wrap; line-height: 1.8; color: #cbd5e1; font-size: 14px;">
                    <?php echo htmlspecialchars($song->lyrics, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Community Engagement Section (Unified Song Identity) -->
        <div style="max-width: 960px; margin: 0 auto;">
            <?php
            $contentType = 'song';
            $contentId = (int)$song->id;
            include __DIR__ . '/_engagement_section.php';
            ?>
        </div>

        <?php if (!empty($relatedSongs)): ?>
            <div style="max-width: 960px; margin: 40px auto 0 auto; border-top: 1px solid #334155; padding-top: 24px;">
                <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 16px 0;">🎵 Related Tracks You May Like</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($relatedSongs as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($relatedPlaylists)): ?>
            <div style="max-width: 960px; margin: 40px auto 0 auto;">
                <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 16px 0;">🎼 Playlists Featuring This Track</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($relatedPlaylists as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Scripts -->
    <?php if ($hasVideo): ?>
        <script src="/plugins/favorite-multimedia/assets/js/multimedia-player.js"></script>
    <?php endif; ?>
    <script src="/plugins/favorite-multimedia/assets/js/multimedia-audio.js"></script>
    <script>
        function switchSongPlaybackMode(mode) {
            const audioContainer = document.getElementById('fav_song_audio_container');
            const videoContainer = document.getElementById('fav_song_video_container');
            const audioPill = document.getElementById('fav_mode_pill_audio');
            const videoPill = document.getElementById('fav_mode_pill_video');

            if (mode === 'audio') {
                if (videoContainer) {
                    videoContainer.style.display = 'none';
                    const vid = videoContainer.querySelector('video');
                    if (vid) vid.pause();
                }
                if (audioContainer) {
                    audioContainer.style.display = 'block';
                }
                if (audioPill) audioPill.classList.add('active');
                if (videoPill) videoPill.classList.remove('active');
            } else if (mode === 'video') {
                if (audioContainer) {
                    audioContainer.style.display = 'none';
                    const aud = audioContainer.querySelector('audio');
                    if (aud) aud.pause();
                    const playBtn = audioContainer.querySelector('.fav-audio-btn-play');
                    if (playBtn) playBtn.innerHTML = '&#9654;';
                }
                if (videoContainer) {
                    videoContainer.style.display = 'block';
                }
                if (videoPill) videoPill.classList.add('active');
                if (audioPill) audioPill.classList.remove('active');
            }
        }

        function switchSongAudioSource(sourceId) {
            const sel = document.getElementById('fav_audio_source_select');
            if (!sel) return;
            const opt = sel.options[sel.selectedIndex];
            const newUrl = opt ? opt.getAttribute('data-url') : '';
            const audioBox = document.querySelector('.fav-audio-player-box');
            if (audioBox && newUrl) {
                const audio = audioBox.querySelector('audio');
                const playBtn = audioBox.querySelector('.fav-audio-btn-play');
                if (audio) {
                    const wasPlaying = !audio.paused;
                    audio.src = newUrl;
                    if (wasPlaying) {
                        audio.play().catch(() => {});
                        if (playBtn) playBtn.innerHTML = '&#10074;&#10074;';
                    }
                }
            }
        }
    </script>
</body>
</html>

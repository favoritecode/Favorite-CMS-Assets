<?php
/**
 * Favorite Multimedia — Song Detail & Audio Player View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #0f172a; color: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header" style="border-color: #1e293b;">
            <div>
                <a href="/songs" style="color: #94a3b8; text-decoration: none; font-size: 14px;">&larr; Back to Songs</a>
                <h1 style="color: #fff; font-size: 26px; margin: 6px 0 0 0;"><?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?></h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/songs" class="fav-mm-nav-link active">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
            </nav>
        </header>

        <!-- Audio Player Card -->
        <div class="fav-audio-player-box" style="margin-bottom: 32px;">
            <?php if ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW && $source): ?>
                <audio preload="metadata" style="display: none;"></audio>

                <div class="fav-audio-now-playing">
                    <?php if ($song->cover): ?>
                        <img src="<?php echo htmlspecialchars($song->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="fav-audio-artwork">
                    <?php else: ?>
                        <div class="fav-audio-artwork" style="display: flex; align-items: center; justify-content: center; font-size: 32px;">🎵</div>
                    <?php endif; ?>
                    <div class="fav-audio-info">
                        <h3 class="fav-audio-title"><?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p class="fav-audio-artist"><?php echo htmlspecialchars($song->getArtist()?->name ?: 'Unknown Artist', ENT_QUOTES, 'UTF-8'); ?></p>
                    </div>
                </div>

                <!-- Progress Bar -->
                <div class="fav-progress-bar-container" style="background: rgba(255,255,255,0.15); height: 6px; border-radius: 3px; cursor: pointer;">
                    <div class="fav-progress-filled" style="background: #2563eb; height: 100%; width: 0%;"></div>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px; color: #94a3b8; margin-top: 6px;">
                    <span class="fav-time-display">0:00 / <?php echo $song->getDurationFormatted(); ?></span>
                    <?php if ($downloadInfo['allowed']): ?>
                        <a href="/multimedia/download/<?php echo $source->id; ?>" class="fav-btn-download" style="padding: 2px 8px; font-size: 11px;">
                            &#8595; Download MP3
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Audio Controls -->
                <div class="fav-audio-controls-row" style="display:flex; justify-content:center; align-items:center; gap:16px;">
                    <button type="button" class="fav-audio-btn-big fav-audio-btn-play" aria-label="Play">&#9654;</button>
                    <?php if (!empty($user)): ?>
                        <button type="button" class="fav-btn-favorite <?= !empty($isFavorite) ? 'active' : '' ?>" data-fmm-fav-toggle data-content-type="song" data-content-id="<?= (int)$song->id ?>">
                            <span class="fav-icon-star">★</span>
                            <span class="fav-btn-label"><?= !empty($isFavorite) ? 'In My List' : 'Add to My List' ?></span>
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Hidden data row for single track player init -->
                <table style="display: none;">
                    <tr class="fav-playlist-row" 
                        data-song-id="<?php echo (int)$song->id; ?>"
                        data-stream-url="/multimedia/stream/<?php echo $source->id; ?>" 
                        data-title="<?php echo htmlspecialchars($song->title, ENT_QUOTES, 'UTF-8'); ?>" 
                        data-artist="<?php echo htmlspecialchars($song->getArtist()?->name ?: 'Unknown Artist', ENT_QUOTES, 'UTF-8'); ?>" 
                        data-cover="<?php echo htmlspecialchars($song->cover ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                        data-can-download="<?php echo $downloadInfo['allowed'] ? '1' : '0'; ?>"
                        data-download-url="/multimedia/download/<?php echo $source->id; ?>">
                    </tr>
                </table>

            <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED): ?>
                <div style="text-align: center; padding: 20px;">
                    <div style="font-size: 36px; margin-bottom: 8px;">🔒</div>
                    <h3>Login Required</h3>
                    <p style="color: #94a3b8; font-size: 14px;">Sign in to listen to this song.</p>
                    <a href="/admin/login?redirect=<?php echo urlencode('/song/' . $song->slug); ?>" class="fav-btn-cta" style="display: inline-block;">Sign In</a>
                </div>
            <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED): ?>
                <div style="text-align: center; padding: 20px;">
                    <div style="font-size: 36px; margin-bottom: 8px;">⭐</div>
                    <h3>Premium Subscription Required</h3>
                    <p style="color: #94a3b8; font-size: 14px;">Upgrade with Favorite Digital to stream this exclusive track.</p>
                    <a href="<?php echo \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::getSubscriptionUrl(); ?>" class="fav-btn-cta" style="display: inline-block;">Upgrade</a>
                </div>
            <?php else: ?>
                <p style="text-align: center; color: #94a3b8;">Audio source unavailable.</p>
            <?php endif; ?>
        </div>

        <!-- Lyrics & Details -->
        <?php if (!empty($song->lyrics)): ?>
            <div style="max-width: 680px; margin: 0 auto; background: #1e293b; border-radius: 8px; padding: 24px;">
                <h3 style="margin-top: 0; font-size: 16px; color: #fff;">Lyrics</h3>
                <div style="white-space: pre-wrap; line-height: 1.8; color: #cbd5e1; font-size: 14px;">
                    <?php echo htmlspecialchars($song->lyrics, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        <?php endif; ?>

        <div style="max-width: 960px; margin: 0 auto;">
            <?php
            $contentType = 'song';
            $contentId = (int)$song->id;
            include __DIR__ . '/_engagement_section.php';
            ?>
        </div>

        <?php if (!empty($relatedSongs)): ?>
            <div style="max-width: 960px; margin: 40px auto 0 auto; border-top: 1px solid #334155; padding-top: 24px;">
                <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 16px 0;">🎵 Related Tracks You May Like</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($relatedSongs as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($relatedPlaylists)): ?>
            <div style="max-width: 960px; margin: 40px auto 0 auto;">
                <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 16px 0;">🎼 Playlists Featuring This Track</h3>
                <div class="fav-mm-grid">
                    <?php foreach ($relatedPlaylists as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="/plugins/favorite-multimedia/assets/js/multimedia-audio.js"></script>
</body>
</html>


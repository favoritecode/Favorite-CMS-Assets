<?php
/**
 * Favorite Multimedia — Search Results View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header">
            <div>
                <a href="/multimedia" style="color: #64748b; font-size: 14px; text-decoration: none;">&larr; Back to Catalog</a>
                <h1 class="fav-mm-title" style="margin-top: 8px;">Search: "<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>"</h1>
            </div>
        </header>

        <!-- Search Bar -->
        <form method="GET" action="/multimedia/search" class="fav-mm-filter-bar">
            <input type="text" name="q" class="fav-mm-search-input" value="<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>" required>
            <button type="submit" style="background:#2563eb; color:#fff; border:none; padding:10px 20px; border-radius:6px; font-weight:600; cursor:pointer;">Search</button>
        </form>

        <?php if (!empty($movies)): ?>
            <div class="fav-mm-search-group">
                <div class="fav-mm-search-group-title">
                    <span>🎬 Movies Matching "<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>"</span>
                    <span class="fav-mm-count-pill"><?php echo count($movies); ?></span>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($movies as $m): ?>
                        <a href="/movie/<?php echo htmlspecialchars($m->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                            <div class="fav-mm-poster-wrap">
                                <span class="fav-badge fav-badge-<?php echo strtolower($m->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($m->access_mode ?? 'public'); ?></span>
                                <?php if ($m->poster): ?>
                                    <img src="<?php echo htmlspecialchars($m->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                                <?php else: ?>
                                    <div class="fav-mm-placeholder fav-mm-placeholder-movie">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M19.82 2H4.18C2.97 2 2 2.97 2 4.18v15.64C2 21.03 2.97 22 4.18 22h15.64c1.21 0 2.18-.97 2.18-2.18V4.18C22 2.97 21.03 2 19.82 2zM7 2v20M17 2v20M2 12h20M2 7h5M2 17h5M17 17h5M17 7h5"/></svg>
                                        <span>Movie</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="fav-mm-card-body">
                                <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($m->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                                <div class="fav-mm-card-meta">
                                    <span><?php echo $m->release_year ?: '—'; ?></span>
                                    <span><?php echo $m->getDurationFormatted(); ?></span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($series)): ?>
            <div class="fav-mm-search-group">
                <div class="fav-mm-search-group-title">
                    <span>📺 Series Matching "<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>"</span>
                    <span class="fav-mm-count-pill"><?php echo count($series); ?></span>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($series as $s): ?>
                        <a href="/series/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                            <div class="fav-mm-poster-wrap">
                                <span class="fav-badge fav-badge-<?php echo strtolower($s->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($s->access_mode ?? 'public'); ?></span>
                                <?php if ($s->poster): ?>
                                    <img src="<?php echo htmlspecialchars($s->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                                <?php else: ?>
                                    <div class="fav-mm-placeholder fav-mm-placeholder-series">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></svg>
                                        <span>Series</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="fav-mm-card-body">
                                <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                                <div class="fav-mm-card-meta">
                                    <span><?php echo $s->release_year ?: '—'; ?></span>
                                    <span><?php echo count($s->getSeasons()); ?> Seasons</span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($songs)): ?>
            <div class="fav-mm-search-group">
                <div class="fav-mm-search-group-title">
                    <span>🎵 Songs Matching "<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>"</span>
                    <span class="fav-mm-count-pill"><?php echo count($songs); ?></span>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($songs as $sg): ?>
                        <a href="/song/<?php echo htmlspecialchars($sg->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-card">
                            <div class="fav-mm-poster-wrap fav-mm-poster-square">
                                <span class="fav-badge fav-badge-<?php echo strtolower($sg->access_mode ?? 'public'); ?> fav-mm-card-badge"><?php echo strtoupper($sg->access_mode ?? 'public'); ?></span>
                                <?php if ($sg->cover): ?>
                                    <img src="<?php echo htmlspecialchars($sg->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($sg->title, ENT_QUOTES, 'UTF-8'); ?>" class="fav-mm-poster" loading="lazy">
                                <?php else: ?>
                                    <div class="fav-mm-placeholder fav-mm-placeholder-audio">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                                        <span>Song</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="fav-mm-card-body">
                                <h3 class="fav-mm-card-title"><?php echo htmlspecialchars($sg->title, ENT_QUOTES, 'UTF-8'); ?></h3>
                                <div class="fav-mm-card-meta">
                                    <span><?php echo htmlspecialchars($sg->getArtist()?->name ?: 'Various', ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span><?php echo $sg->getDurationFormatted(); ?></span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (empty($movies) && empty($series) && empty($songs)): ?>
            <div class="fav-mm-empty">
                <span class="fav-mm-empty-icon">🔍</span>
                <div class="fav-mm-empty-title">No Results Found</div>
                <p class="fav-mm-empty-desc">We couldn't find any multimedia matching "<?php echo htmlspecialchars($query, ENT_QUOTES, 'UTF-8'); ?>". Try searching by artist, title, or genre.</p>
                <div style="margin-top: 16px;">
                    <a href="/multimedia" style="display: inline-block; background: #2563eb; color: #fff; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 600; font-size: 14px;">Browse Catalog &rarr;</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>


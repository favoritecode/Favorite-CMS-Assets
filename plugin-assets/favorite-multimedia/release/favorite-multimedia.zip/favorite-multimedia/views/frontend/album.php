<?php
/**
 * Favorite Multimedia — Album View
 * 
 * Powered by Theme Tokens & Modular Components
 *
 * @var string $metaTitle
 * @var object $album
 * @var object|null $artist
 * @var array $songs
 * @var object|null $user
 */

use FavoriteCMS\Multimedia\Theme\ThemeManager;

$themeManager = ThemeManager::getInstance();
$componentsDir = __DIR__ . '/components';
$currentNav = 'music';
$contentType = 'album';
include $componentsDir . '/content-layout.php';

$albTitle = htmlspecialchars($album->title ?? 'Album', ENT_QUOTES, 'UTF-8');
$albCover = htmlspecialchars($album->cover ?? '', ENT_QUOTES, 'UTF-8');
$albDesc = htmlspecialchars($album->description ?? '', ENT_QUOTES, 'UTF-8');
$artistName = htmlspecialchars($artist?->name ?? 'Various Artists', ENT_QUOTES, 'UTF-8');
$artistSlug = htmlspecialchars($artist?->slug ?? '', ENT_QUOTES, 'UTF-8');
$releaseYear = !empty($album->release_date) ? substr((string)$album->release_date, 0, 4) : '';

$totalSeconds = 0;
if (!empty($songs)) {
    foreach ($songs as $s) {
        $totalSeconds += (int)($s->duration ?? 0);
    }
}
$totalDurationFormatted = '';
if ($totalSeconds > 0) {
    $mins = floor($totalSeconds / 60);
    $secs = $totalSeconds % 60;
    if ($mins >= 60) {
        $hrs = floor($mins / 60);
        $remMins = $mins % 60;
        $totalDurationFormatted = sprintf('%d hr %d min', $hrs, $remMins);
    } else {
        $totalDurationFormatted = sprintf('%d min %d sec', $mins, $secs);
    }
}
$isFavorite = !empty($user) ? \FavoriteCMS\Multimedia\Models\Favorite::isFavorited((int)$user->id, 'album', (int)$album->id) : false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/theme/theme-tokens.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/theme/multimedia-frontend.css?v=1.0.7">
    <?php echo $themeManager->renderHeadTokens(); ?>
</head>
<body class="fm-theme-body">

    <!-- Global Responsive Header -->
    <?php include $componentsDir . '/header.php'; ?>

    <main class="fm-main-content">
        <div class="fav-mm-container" style="padding-top: 24px;">
            <?php if ($fmShowBackLink): ?>
                <a href="/multimedia/music" class="fm-back-link">&larr; Back to Music</a>
            <?php endif; ?>

            <div class="<?= $fmLayoutClass ?>">
                <div class="fm-content-main">
        <!-- Album Header Hero Card -->
        <div class="fm-detail-hero fm-album-hero" style="margin-bottom:32px;">
            <div class="fm-hero-cover-wrap">
                <?php if ($albCover): ?>
                    <img src="<?= $albCover ?>" alt="<?= $albTitle ?>" class="fm-hero-cover" onerror="this.style.display='none'; if(this.nextElementSibling){this.nextElementSibling.style.display='flex';}">
                    <div class="fm-hero-cover fm-hero-cover-fallback" style="display:none;" aria-hidden="true">💿</div>
                <?php else: ?>
                    <div class="fm-hero-cover fm-hero-cover-fallback" aria-hidden="true">💿</div>
                <?php endif; ?>
            </div>
            <div class="fm-hero-meta">
                <div class="fm-hero-badges">
                    <span class="fm-badge fm-badge-primary">ALBUM</span>
                    <?php if (($album->access_mode ?? '') === 'premium' || (isset($accessState) && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED)): ?>
                        <span class="fm-badge fm-badge-premium">⭐ Premium</span>
                    <?php elseif (($album->access_mode ?? '') === 'login' || (isset($accessState) && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED)): ?>
                        <span class="fm-badge fm-badge-secondary">🔒 Members Only</span>
                    <?php endif; ?>
                </div>

                <h1 class="fm-hero-title"><?= $albTitle ?></h1>

                <div class="fm-hero-subline">
                    <?php if ($artistSlug): ?>
                        <span>By <a href="/multimedia/artist/<?= $artistSlug ?>" class="fm-hero-link"><?= $artistName ?></a></span>
                    <?php else: ?>
                        <span>By <?= $artistName ?></span>
                    <?php endif; ?>

                    <?php if ($releaseYear): ?>
                        <span>&bull; <?= $releaseYear ?></span>
                    <?php endif; ?>

                    <span>&bull; <?= count($songs) ?> <?= count($songs) === 1 ? 'track' : 'tracks' ?></span>

                    <?php if ($totalDurationFormatted): ?>
                        <span>&bull; <?= $totalDurationFormatted ?></span>
                    <?php endif; ?>
                </div>

                <?php if ($albDesc): ?>
                    <p class="fm-hero-desc"><?= nl2br($albDesc) ?></p>
                <?php endif; ?>

                <div class="fm-hero-actions">
                    <?php if (!isset($accessState) || $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW): ?>
                        <button type="button" class="fm-btn fm-btn-primary" data-fm-play-all="album" data-context-id="<?= (int)($album->id ?? 0) ?>">
                            <span>▶</span> Play Album
                        </button>
                    <?php endif; ?>

                    <button type="button" class="fm-btn fm-btn-secondary fav-btn-favorite <?= !empty($isFavorite) ? 'active' : '' ?>" data-fmm-fav-toggle data-content-type="album" data-content-id="<?= (int)$album->id ?>">
                        <span class="fav-icon-star">★</span>
                        <span class="fav-btn-label"><?= !empty($isFavorite) ? 'In My List' : 'Add to My List' ?></span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Album Tracklist -->
        <section class="fm-section" style="margin-bottom: 40px;">
            <?php if (isset($accessState) && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED): ?>
                <div class="fm-access-gate-card" style="text-align: center; padding: 40px 24px; background: var(--fm-color-bg-surface); border: var(--fm-border-strength) solid var(--fm-color-border); border-radius: var(--fm-radius-card);">
                    <div style="font-size: 48px; margin-bottom: 12px;">🔒</div>
                    <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; color: var(--fm-color-text-primary);">Sign In Required</h2>
                    <p style="color: var(--fm-color-text-secondary); max-width: 480px; margin: 0 auto 20px auto;">Sign in to your account to unlock and stream this album.</p>
                    <a href="/admin/login?redirect=<?php echo urlencode('/multimedia/album/' . ($album->slug ?? (string)$album->id)); ?>" class="fm-btn fm-btn-primary" style="display: inline-block; padding: 10px 24px; border-radius: 20px; text-decoration: none;">Sign In</a>
                </div>
            <?php elseif (isset($accessState) && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED): ?>
                <div class="fm-access-gate-card" style="text-align: center; padding: 40px 24px; background: var(--fm-color-bg-surface); border: var(--fm-border-strength) solid var(--fm-color-border); border-radius: var(--fm-radius-card);">
                    <div style="font-size: 48px; margin-bottom: 12px;">⭐</div>
                    <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; color: var(--fm-color-text-primary);">Premium Album</h2>
                    <p style="color: var(--fm-color-text-secondary); max-width: 480px; margin: 0 auto 20px auto;">This album requires an active Premium membership pass from Favorite Digital.</p>
                    <a href="<?php echo \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::getSubscriptionUrl(); ?>" class="fm-btn fm-btn-primary" style="display: inline-block; padding: 10px 24px; border-radius: 20px; text-decoration: none;">Upgrade Membership</a>
                </div>
            <?php else: ?>
                <div class="fm-section-header">
                    <h2 class="fm-section-title">Tracklist</h2>
                </div>
                <?php if (empty($songs)): ?>
                    <?php 
                    $emptyIcon = '🎵';
                    $emptyTitle = 'No Tracks Available';
                    $emptyMessage = 'There are no songs in this album yet.';
                    include $componentsDir . '/empty-state.php'; 
                    ?>
                <?php else: ?>
                    <div class="fm-song-list">
                        <?php 
                        $trackNum = 1;
                        foreach ($songs as $item): 
                            $index = $trackNum++;
                            include $componentsDir . '/song-row.php';
                        endforeach; 
                        ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
                </div><!-- /.fm-content-main -->
                <?php if ($fmSidebarEnabled): ?>
                    <?php include $componentsDir . '/sticky-sidebar.php'; ?>
                <?php endif; ?>
            </div><!-- /.fm-content-layout -->
        </div><!-- /.fav-mm-container -->
    </main>

    <!-- Mobile Bottom Navigation -->
    <?php include $componentsDir . '/mobile-nav.php'; ?>

    <script src="/plugins/favorite-multimedia/assets/js/frontend/multimedia-frontend.js?v=1.0.7"></script>
</body>
</html>

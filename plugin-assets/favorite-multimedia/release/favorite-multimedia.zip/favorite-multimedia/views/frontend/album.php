<?php
/**
 * Favorite Multimedia — Album View
 */
$albTitle = htmlspecialchars($album->title ?? 'Album', ENT_QUOTES, 'UTF-8');
$albCover = htmlspecialchars($album->cover ?? '', ENT_QUOTES, 'UTF-8');
$albDesc = htmlspecialchars($album->description ?? '', ENT_QUOTES, 'UTF-8');
$artistName = htmlspecialchars($artist?->name ?? 'Various Artists', ENT_QUOTES, 'UTF-8');
$artistSlug = htmlspecialchars($artist?->slug ?? '', ENT_QUOTES, 'UTF-8');
$releaseYear = !empty($album->release_date) ? substr((string)$album->release_date, 0, 4) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Header & Navigation -->
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">💿 Album</h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/multimedia/discover" class="fav-mm-nav-link">Discover</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
                <?php if (!empty($user)): ?>
                    <a href="/multimedia/library" class="fav-mm-nav-link">My Library</a>
                <?php endif; ?>
            </nav>
        </header>

        <!-- Album Hero -->
        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:12px; padding:28px; display:flex; gap:24px; align-items:center; flex-wrap:wrap; margin-bottom:36px;">
            <?php if ($albCover): ?>
                <img src="<?= $albCover ?>" alt="<?= $albTitle ?>" style="width:160px; height:160px; border-radius:8px; object-fit:cover; box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);">
            <?php else: ?>
                <div style="width:160px; height:160px; border-radius:8px; background:#e2e8f0; display:flex; align-items:center; justify-content:center; font-size:48px;">
                    💿
                </div>
            <?php endif; ?>
            <div style="flex:1; min-width:260px;">
                <span class="fmm-badge fmm-badge-song" style="display:inline-block; margin-bottom:8px;">Album</span>
                <h2 style="font-size:28px; font-weight:800; margin:0 0 8px 0; color:#0f172a;"><?= $albTitle ?></h2>
                <div style="font-size:15px; color:#475569; margin-bottom:12px;">
                    By <a href="/multimedia/artist/<?= $artistSlug ?>" style="color:#2563eb; font-weight:600; text-decoration:none;"><?= $artistName ?></a>
                    <?php if ($releaseYear): ?> &bull; <?= $releaseYear ?><?php endif; ?>
                    &bull; <?= count($songs) ?> tracks
                </div>
                <?php if ($albDesc): ?>
                    <p style="margin:0; color:#64748b; font-size:14px; line-height:1.5; max-width:600px;"><?= nl2br($albDesc) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Album Tracklist -->
        <section style="margin-bottom: 40px;">
            <h3 style="font-size:20px; font-weight:700; margin:0 0 16px 0;">Tracklist</h3>
            <?php if (empty($songs)): ?>
                <div style="text-align:center; padding:32px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; color:#64748b;">
                    No tracks in this album yet.
                </div>
            <?php else: ?>
                <div class="fav-mm-grid">
                    <?php foreach ($songs as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

    </div>

</body>
</html>


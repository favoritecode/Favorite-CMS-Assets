<?php
/**
 * Favorite Multimedia — Inner 404 Not Found Content
 *
 * ACTIVE CMS THEME owns the outer shell, header, footer, and navigation.
 * Favorite Multimedia owns only this inner not-found content.
 *
 * @var string $heading
 * @var string $message
 * @var string|null $backUrl
 * @var string|null $backText
 */

$headingText = htmlspecialchars($heading ?? '404 — Not Found', ENT_QUOTES, 'UTF-8');
$messageText = htmlspecialchars($message ?? 'The requested item could not be found or has been removed.', ENT_QUOTES, 'UTF-8');
$actionUrl = htmlspecialchars($backUrl ?? '/multimedia/music', ENT_QUOTES, 'UTF-8');
$actionLabel = htmlspecialchars($backText ?? 'Back to Music', ENT_QUOTES, 'UTF-8');
?>
<section class="fm-not-found" style="padding: 60px 20px; text-align: center; max-width: 600px; margin: 0 auto;">
    <div style="font-size: 64px; margin-bottom: 16px;">💿</div>
    <h1 style="font-size: 2.25rem; font-weight: 800; margin-bottom: 12px; color: var(--fm-color-text-primary, #0f172a);"><?php echo $headingText; ?></h1>
    <p style="color: var(--fm-color-text-secondary, #64748b); font-size: 1.05rem; margin-bottom: 28px; line-height: 1.5;"><?php echo $messageText; ?></p>
    <div style="display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
        <a href="<?php echo $actionUrl; ?>" class="fm-btn fm-btn-primary" style="display: inline-flex; align-items: center; justify-content: center; padding: 10px 24px; border-radius: 20px; text-decoration: none; font-weight: 600; background: var(--fm-color-primary, #2563eb); color: #fff;">
            <?php echo $actionLabel; ?>
        </a>
        <a href="/multimedia" class="fm-btn" style="display: inline-flex; align-items: center; justify-content: center; padding: 10px 24px; border-radius: 20px; text-decoration: none; font-weight: 600; background: var(--fm-color-bg-surface, #f8fafc); border: 1px solid var(--fm-color-border, #e2e8f0); color: var(--fm-color-text-primary, #0f172a);">
            Multimedia Hub
        </a>
    </div>
</section>


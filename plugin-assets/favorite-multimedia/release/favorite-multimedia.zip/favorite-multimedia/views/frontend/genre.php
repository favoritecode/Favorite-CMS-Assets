<?php
/**
 * Favorite Multimedia — Browse by Genre View
 */
$genreName = htmlspecialchars($genre->name ?? 'Genre', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <!-- Header & Navigation -->
        <header class="fav-mm-header">
            <div>
                <h1 class="fav-mm-title">🏷️ <?= $genreName ?></h1>
                <p style="margin: 4px 0 0 0; color: #64748b; font-size: 14px;">
                    <?= (int)$total ?> titles tagged in <?= $genreName ?>
                </p>
            </div>
            <nav class="fav-mm-nav">
                <a href="/multimedia" class="fav-mm-nav-link">Hub</a>
                <a href="/multimedia/discover" class="fav-mm-nav-link">Discover</a>
                <a href="/movies" class="fav-mm-nav-link">Movies</a>
                <a href="/series" class="fav-mm-nav-link">Web Series</a>
                <a href="/songs" class="fav-mm-nav-link">Songs</a>
                <a href="/playlists" class="fav-mm-nav-link">Playlists</a>
                <?php if (!empty($user)): ?>
                    <a href="/multimedia/library" class="fav-mm-nav-link">My Library</a>
                <?php endif; ?>
            </nav>
        </header>

        <?php if (!empty($movies)): ?>
            <!-- Movies in this genre -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0;">🎬 Movies in <?= $genreName ?> (<?= count($movies) ?>)</h2>
                    <a href="/movies?genre=<?= urlencode($genre->slug) ?>" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View all movies &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($movies as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($series)): ?>
            <!-- Web Series in this genre -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0;">📺 Web Series in <?= $genreName ?> (<?= count($series) ?>)</h2>
                    <a href="/series?genre=<?= urlencode($genre->slug) ?>" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View all series &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($series as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($songs)): ?>
            <!-- Songs in this genre -->
            <section style="margin-bottom: 40px;">
                <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:16px;">
                    <h2 style="font-size:20px; font-weight:700; margin:0;">🎵 Music in <?= $genreName ?> (<?= count($songs) ?>)</h2>
                    <a href="/songs?genre=<?= urlencode($genre->slug) ?>" style="color:#2563eb; font-weight:600; font-size:14px; text-decoration:none;">View all songs &rarr;</a>
                </div>
                <div class="fav-mm-grid">
                    <?php foreach ($songs as $item): ?>
                        <?php include __DIR__ . '/_discovery_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (empty($items)): ?>
            <div style="text-align:center; padding:48px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; color:#64748b;">
                <p style="font-size:16px; margin:0 0 12px 0;">No published multimedia items currently tagged in this genre.</p>
                <a href="/multimedia/discover" style="color:#2563eb; font-weight:600; text-decoration:none;">Browse All Discover &rarr;</a>
            </div>
        <?php endif; ?>

    </div>

</body>
</html>


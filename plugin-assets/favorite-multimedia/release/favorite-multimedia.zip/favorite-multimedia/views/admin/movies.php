<?php
/**
 * Favorite Multimedia — Admin Movies View
 */
$isEditing = ($editMovie !== null);
$selectedGenres = $isEditing ? array_column($editMovie->getGenres(), 'id') : [];
?>
<link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-admin.css">

<div class="fav-admin-wrap">
    <div class="fav-admin-header">
        <h2 class="fav-admin-title">🎬 Movies Management</h2>
        <?php if ($isEditing): ?>
            <a href="/admin/page/multimedia-movies" class="fav-admin-btn fav-admin-btn-secondary">&larr; Back to Movies List</a>
        <?php endif; ?>
    </div>

    <!-- Quick Navigation Bar -->
    <div class="fav-admin-subnav">
        <a href="/admin/page/multimedia" class="fav-admin-subnav-link">🏠 Dashboard</a>
        <a href="/admin/page/multimedia-movies" class="fav-admin-subnav-link active">🎬 Movies</a>
        <a href="/admin/page/multimedia-series" class="fav-admin-subnav-link">📺 Web Series</a>
        <a href="/admin/page/multimedia-seasons" class="fav-admin-subnav-link">📼 Seasons</a>
        <a href="/admin/page/multimedia-episodes" class="fav-admin-subnav-link">🎞️ Episodes</a>
        <a href="/admin/page/multimedia-songs" class="fav-admin-subnav-link">🎵 Songs</a>
        <a href="/admin/page/multimedia-playlists" class="fav-admin-subnav-link">🎼 Playlists</a>
        <a href="/admin/page/multimedia-genres" class="fav-admin-subnav-link">🏷️ Genres</a>
        <a href="/admin/page/multimedia-artists" class="fav-admin-subnav-link">🎤 Artists</a>
        <a href="/admin/page/multimedia-albums" class="fav-admin-subnav-link">💿 Albums</a>
        <a href="/admin/page/multimedia-sources" class="fav-admin-subnav-link">🎛️ Sources</a>
        <a href="/admin/page/multimedia-subtitles" class="fav-admin-subnav-link">💬 Subtitles</a>
        <a href="/admin/page/multimedia-analytics" class="fav-admin-subnav-link">📊 Analytics</a>
        <a href="/admin/page/multimedia-moderation" class="fav-admin-subnav-link">🛡️ Moderation</a>
        <a href="/admin/page/multimedia-settings" class="fav-admin-subnav-link">⚙️ Settings</a>
        <a href="/admin/page/multimedia-releases" class="fav-admin-subnav-link">📅 Releases</a>
    </div>

    <?php if ($isEditing || isset($_GET['new'])): ?>
        <!-- Movie Form -->
        <div class="fav-admin-stat-card" style="margin-bottom: 28px;">
            <h3 style="margin-top:0; font-size:18px; border-bottom:1px solid #e2e8f0; padding-bottom:10px;">
                <?php echo $isEditing ? 'Edit Movie: ' . htmlspecialchars($editMovie->title, ENT_QUOTES, 'UTF-8') : 'Create New Movie'; ?>
            </h3>

            <form method="POST" action="/admin/page/multimedia-movies" id="fav_movie_form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="<?php echo $isEditing ? 'edit' : 'create'; ?>">
                <input type="hidden" name="id" value="<?php echo $editMovie->id ?? 0; ?>">

                <!-- 1. Basic Information -->
                <div class="fav-form-section">
                    <h4 class="fav-form-section-title">📌 Basic Information</h4>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Movie Title *</label>
                                <input type="text" name="title" id="fav_movie_title" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->title ?? '', ENT_QUOTES, 'UTF-8'); ?>" required placeholder="e.g. Interstellar">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">URL Slug</label>
                                <input type="text" name="slug" id="fav_movie_slug" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->slug ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="auto-generated from title">
                                <span class="fav-form-hint">Unique URL path: /movie/your-slug</span>
                            </div>
                        </div>
                    </div>

                    <div class="fav-form-group">
                        <label class="fav-form-label">Synopsis / Description</label>
                        <textarea name="description" class="fav-form-control" rows="4" placeholder="Brief summary of the movie..."><?php echo htmlspecialchars($editMovie->description ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Release Year</label>
                                <input type="number" name="release_year" class="fav-form-control" value="<?php echo $editMovie->release_year ?? date('Y'); ?>">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Release Date</label>
                                <input type="date" name="release_date" class="fav-form-control" value="<?php echo $editMovie->release_date ?? ''; ?>">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Duration (Seconds)</label>
                                <input type="number" name="duration" class="fav-form-control" value="<?php echo $editMovie->duration ?? 7200; ?>" placeholder="e.g. 7200 for 2 hours">
                                <span class="fav-form-hint"><?php echo $editMovie ? $editMovie->getDurationFormatted() : 'e.g. 7200 = 2 hours'; ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Language</label>
                                <input type="text" name="language" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->language ?? 'English', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Country</label>
                                <input type="text" name="country" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->country ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Director</label>
                                <input type="text" name="director" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->director ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Cast Members</label>
                                <input type="text" name="cast" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->cast ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Comma separated actor names">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Trailer URL</label>
                                <input type="text" name="trailer_url" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->trailer_url ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="YouTube or video URL">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. Artwork & Imagery -->
                <div class="fav-form-section">
                    <h4 class="fav-form-section-title">🎨 Artwork &amp; Imagery</h4>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Poster Image URL or Local Path</label>
                                <input type="text" name="poster" id="fav_movie_poster" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->poster ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://... or /uploads/...">
                                <span class="fav-form-hint">Recommended aspect ratio: 2:3 vertical poster</span>
                                <?php if (!empty($editMovie->poster)): ?>
                                    <img src="<?php echo htmlspecialchars($editMovie->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="fav-img-preview" id="fav_poster_preview">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Backdrop / Hero Image URL</label>
                                <input type="text" name="backdrop" id="fav_movie_backdrop" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->backdrop ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://... or /uploads/...">
                                <span class="fav-form-hint">Recommended aspect ratio: 16:9 widescreen backdrop</span>
                                <?php if (!empty($editMovie->backdrop)): ?>
                                    <img src="<?php echo htmlspecialchars($editMovie->backdrop, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="fav-img-preview" id="fav_backdrop_preview" style="max-width: 160px; max-height: 90px;">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. Access & Governance -->
                <div class="fav-form-section">
                    <h4 class="fav-form-section-title">🔐 Access Control &amp; Policies</h4>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Access Mode *</label>
                                <select name="access_mode" class="fav-form-control">
                                    <option value="public" <?php echo ($editMovie?->access_mode === 'public') ? 'selected' : ''; ?>>PUBLIC (Free for everyone)</option>
                                    <option value="login" <?php echo ($editMovie?->access_mode === 'login') ? 'selected' : ''; ?>>LOGIN REQUIRED (Logged-in users)</option>
                                    <option value="premium" <?php echo ($editMovie?->access_mode === 'premium') ? 'selected' : ''; ?>>PREMIUM (Entitlement / subscription required)</option>
                                </select>
                                <span class="fav-form-hint">Enforced authoritative access level via MultimediaAccessService</span>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Download Policy *</label>
                                <select name="download_policy" class="fav-form-control">
                                    <option value="inherit" <?php echo ($editMovie?->download_policy === 'inherit') ? 'selected' : ''; ?>>Inherit Global Setting</option>
                                    <option value="allow" <?php echo ($editMovie?->download_policy === 'allow') ? 'selected' : ''; ?>>Allow Downloads</option>
                                    <option value="deny" <?php echo ($editMovie?->download_policy === 'deny') ? 'selected' : ''; ?>>Deny Downloads</option>
                                </select>
                                <span class="fav-form-hint">Viewing permission and downloading permission are independent.</span>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Publication Status *</label>
                                <select name="status" id="fav_pub_status" class="fav-form-control" onchange="toggleSchedulingFields(this.value)">
                                    <option value="published" <?php echo ($editMovie?->status === 'published' || !$isEditing) ? 'selected' : ''; ?>>Published (Live)</option>
                                    <option value="scheduled" <?php echo ($editMovie?->status === 'scheduled') ? 'selected' : ''; ?>>Scheduled for Release</option>
                                    <option value="draft" <?php echo ($editMovie?->status === 'draft') ? 'selected' : ''; ?>>Draft (Hidden)</option>
                                    <option value="unpublished" <?php echo ($editMovie?->status === 'unpublished') ? 'selected' : ''; ?>>Unpublished (Archived)</option>
                                </select>
                                <span class="fav-form-hint">Drafts and scheduled items are hidden from public catalog and search.</span>
                            </div>
                        </div>
                    </div>

                    <!-- Scheduling Row -->
                    <?php 
                    $tz = \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::getAppTimezone();
                    $pubAtLocal = !empty($editMovie?->publish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editMovie->publish_at, 'Y-m-d\TH:i') : '';
                    $unpubAtLocal = !empty($editMovie?->unpublish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editMovie->unpublish_at, 'Y-m-d\TH:i') : '';
                    $showSched = ($editMovie?->status === 'scheduled');
                    ?>
                    <div class="fav-form-row" id="fav_scheduling_row" style="margin-top: 10px; <?php echo $showSched ? '' : 'display:none;'; ?>">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Schedule Release Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                                <input type="datetime-local" name="publish_at" class="fav-form-control" value="<?php echo htmlspecialchars($pubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="fav-form-hint">Automatically publishes when due (Timezone: <?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>).</span>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Optional Unpublish Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                                <input type="datetime-local" name="unpublish_at" class="fav-form-control" value="<?php echo htmlspecialchars($unpubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="fav-form-hint">Automatically unpublishes after this time (optional).</span>
                            </div>
                        </div>
                    </div>

                    <div class="fav-form-group" style="margin-top: 10px;">
                        <label style="font-size: 13px; font-weight: 600; cursor:pointer;">
                            <input type="checkbox" name="featured" value="1" <?php echo ($editMovie?->featured) ? 'checked' : ''; ?>>
                            ⭐ Feature this movie on frontend homepage / hero banner
                        </label>
                    </div>
                </div>

                <!-- 4. Classification (Genres) -->
                <div class="fav-form-section">
                    <h4 class="fav-form-section-title">🏷️ Genres &amp; Classification</h4>
                    <div style="display: flex; gap: 14px; flex-wrap: wrap; padding: 4px 0;">
                        <?php if (empty($genres)): ?>
                            <span style="color:#94a3b8; font-size:13px;">No genres created yet. <a href="/admin/page/multimedia-genres" target="_blank" style="color:#2563eb;">+ Add Genres</a></span>
                        <?php else: foreach ($genres as $g): ?>
                            <label style="font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; background:#fff; border:1px solid #cbd5e1; padding:4px 10px; border-radius:4px;">
                                <input type="checkbox" name="genres[]" value="<?php echo $g->id; ?>" <?php echo in_array($g->id, $selectedGenres) ? 'checked' : ''; ?>>
                                <?php echo htmlspecialchars($g->name, ENT_QUOTES, 'UTF-8'); ?>
                            </label>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

                <!-- 5. SEO Metadata -->
                <div class="fav-form-section">
                    <h4 class="fav-form-section-title">🔍 SEO &amp; Social Metadata</h4>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">SEO Page Title (Optional)</label>
                                <input type="text" name="seo_title" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->seo_title ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Defaults to Movie Title">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">SEO Meta Description (Optional)</label>
                                <input type="text" name="seo_description" class="fav-form-control" value="<?php echo htmlspecialchars($editMovie->seo_description ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Brief snippet for search engine previews">
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; align-items: center;">
                    <button type="submit" class="fav-admin-btn" style="padding: 10px 24px; font-size: 14px;"><?php echo $isEditing ? 'Save Changes' : 'Create Movie'; ?></button>
                    <?php if ($isEditing): ?>
                        <a href="/admin/page/multimedia-movies" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 18px; font-size: 14px;">Cancel</a>
                        <a href="/movie/<?php echo htmlspecialchars($editMovie->slug, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 18px; font-size: 14px;">Preview on Frontend &rarr;</a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($isEditing): ?>
                <!-- Attached Media Sources & Subtitles -->
                <hr style="margin: 28px 0; border: none; border-top: 1px solid #e2e8f0;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px;">
                    <!-- Media Sources -->
                    <div class="fav-form-section" style="margin-bottom: 0;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <h4 style="margin:0; font-size:14px; font-weight:700;">🎛️ Media Sources (<?php $movieSources = $editMovie->getSources(false); echo count($movieSources); ?>)</h4>
                            <a href="/admin/page/multimedia-sources?content_type=movie&content_id=<?php echo $editMovie->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size:11px; padding:3px 8px;">+ Manage Sources</a>
                        </div>
                        <?php if (empty($movieSources)): ?>
                            <p style="color:#94a3b8; font-size:12px; margin:0;">No stream sources attached yet. Click "+ Manage Sources" to attach MP4, HLS, or embed URL.</p>
                        <?php else: ?>
                            <table class="fav-admin-table" style="font-size:12px; margin:0;">
                                <thead><tr><th>Label</th><th>Type</th><th>Status</th></tr></thead>
                                <tbody>
                                    <?php foreach ($movieSources as $ms): ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($ms->label, ENT_QUOTES, 'UTF-8'); ?></strong> <?php if ($ms->is_default) echo '⭐'; ?></td>
                                            <td><code><?php echo strtoupper($ms->source_type); ?></code></td>
                                            <td><?php echo ucfirst($ms->status ?? 'active'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                    <!-- Subtitles -->
                    <div class="fav-form-section" style="margin-bottom: 0;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <h4 style="margin:0; font-size:14px; font-weight:700;">💬 Subtitle Tracks (<?php $movieSubs = $editMovie->getSubtitles(); echo count($movieSubs); ?>)</h4>
                            <a href="/admin/page/multimedia-subtitles?content_type=movie&content_id=<?php echo $editMovie->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size:11px; padding:3px 8px;">+ Manage Subtitles</a>
                        </div>
                        <?php if (empty($movieSubs)): ?>
                            <p style="color:#94a3b8; font-size:12px; margin:0;">No subtitles registered yet. WebVTT (.vtt) files supported.</p>
                        <?php else: ?>
                            <table class="fav-admin-table" style="font-size:12px; margin:0;">
                                <thead><tr><th>Language</th><th>Label</th><th>Default</th></tr></thead>
                                <tbody>
                                    <?php foreach ($movieSubs as $sub): ?>
                                        <tr>
                                            <td><code><?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?></code></td>
                                            <td><?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo $sub->is_default ? '⭐ Yes' : 'No'; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Movies Table -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0; font-size:16px;">All Movies</h3>
        <?php if (!$isEditing && !isset($_GET['new'])): ?>
            <a href="/admin/page/multimedia-movies?new=1" class="fav-admin-btn">+ Add New Movie</a>
        <?php endif; ?>
    </div>

    <table class="fav-admin-table">
        <thead>
            <tr>
                <th style="width: 50px;">Poster</th>
                <th>Title</th>
                <th>Year</th>
                <th>Duration</th>
                <th>Access</th>
                <th>Downloads</th>
                <th>Status</th>
                <th style="text-align: right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($items)): ?>
                <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 24px;">No movies recorded yet. Click "+ Add New Movie" to start.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td>
                        <?php if ($item->poster): ?>
                            <img src="<?php echo htmlspecialchars($item->poster, ENT_QUOTES, 'UTF-8'); ?>" alt="" style="width: 40px; height: 55px; object-fit: cover; border-radius: 4px;">
                        <?php else: ?>
                            <div style="width: 40px; height: 55px; background: #e2e8f0; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #64748b;">No Img</div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?></strong>
                        <div style="font-size: 11px; color: #64748b;">/movie/<?php echo htmlspecialchars($item->slug, ENT_QUOTES, 'UTF-8'); ?></div>
                    </td>
                    <td><?php echo $item->release_year ?: '—'; ?></td>
                    <td><?php echo $item->getDurationFormatted() ?: '—'; ?></td>
                    <td><span class="fav-badge fav-badge-<?php echo strtolower($item->access_mode ?? 'public'); ?>"><?php echo strtoupper($item->access_mode ?? 'public'); ?></span></td>
                    <td><?php echo ucfirst($item->download_policy ?? 'inherit'); ?></td>
                    <td><?php echo ucfirst($item->status ?? 'published'); ?></td>
                    <td style="text-align: right; white-space: nowrap;">
                        <a href="/admin/page/multimedia-sources?content_type=movie&content_id=<?php echo $item->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 4px 8px; font-size: 11px;">Media Sources</a>
                        <a href="/admin/page/multimedia-subtitles?content_type=movie&content_id=<?php echo $item->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 4px 8px; font-size: 11px;">Subtitles</a>
                        <a href="/movie/<?php echo htmlspecialchars($item->slug, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 4px 8px; font-size: 11px;">View</a>
                        <a href="/admin/page/multimedia-movies?edit=<?php echo $item->id; ?>" class="fav-admin-btn" style="padding: 4px 8px; font-size: 11px;">Edit</a>
                        <form method="POST" action="/admin/page/multimedia-movies" style="display:inline;" onsubmit="return confirm('Delete this movie?');">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $item->id; ?>">
                            <button type="submit" class="fav-admin-btn fav-admin-btn-danger" style="padding: 4px 8px; font-size: 11px;">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const titleInput = document.getElementById('fav_movie_title');
    const slugInput = document.getElementById('fav_movie_slug');
    if (titleInput && slugInput) {
        titleInput.addEventListener('input', function() {
            if (!slugInput.value || slugInput.dataset.autoSlug !== 'false') {
                slugInput.value = this.value
                    .toLowerCase()
                    .replace(/[^\w\s-]/g, '')
                    .trim()
                    .replace(/\s+/g, '-');
            }
        });
        slugInput.addEventListener('input', function() {
            slugInput.dataset.autoSlug = 'false';
        });
    }

    const posterInput = document.getElementById('fav_movie_poster');
    if (posterInput) {
        posterInput.addEventListener('change', function() {
            let prev = document.getElementById('fav_poster_preview');
            if (this.value) {
                if (!prev) {
                    prev = document.createElement('img');
                    prev.id = 'fav_poster_preview';
                    prev.className = 'fav-img-preview';
                    posterInput.parentNode.appendChild(prev);
                }
                prev.src = this.value;
                prev.style.display = 'block';
            } else if (prev) {
                prev.style.display = 'none';
            }
        });
    }
function toggleSchedulingFields(status) {
    const row = document.getElementById('fav_scheduling_row');
    if (row) {
        row.style.display = (status === 'scheduled') ? 'flex' : 'none';
    }
}
</script>


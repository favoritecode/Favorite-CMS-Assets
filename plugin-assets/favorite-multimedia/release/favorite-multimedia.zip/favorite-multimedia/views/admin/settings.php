<?php
/**
 * Favorite Multimedia — Admin Settings View
 */
?>
<link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-admin.css">

<div class="fav-admin-wrap">
    <div class="fav-admin-header">
        <h2 class="fav-admin-title">⚙️ Multimedia Global Settings</h2>
    </div>

    <!-- Quick Navigation Bar -->
    <div class="fav-admin-subnav">
        <a href="/admin/page/multimedia" class="fav-admin-subnav-link">🏠 Dashboard</a>
        <a href="/admin/page/multimedia-movies" class="fav-admin-subnav-link">🎬 Movies</a>
        <a href="/admin/page/multimedia-series" class="fav-admin-subnav-link">📺 Web Series</a>
        <a href="/admin/page/multimedia-seasons" class="fav-admin-subnav-link">📼 Seasons</a>
        <a href="/admin/page/multimedia-episodes" class="fav-admin-subnav-link">🎞️ Episodes</a>
        <a href="/admin/page/multimedia-songs" class="fav-admin-subnav-link">🎵 Songs</a>
        <a href="/admin/page/multimedia-playlists" class="fav-admin-subnav-link">🎼 Playlists</a>
        <a href="/admin/page/multimedia-genres" class="fav-admin-subnav-link">🏷️ Genres</a>
        <a href="/admin/page/multimedia-artists" class="fav-admin-subnav-link">🎤 Artists</a>
        <a href="/admin/page/multimedia-albums" class="fav-admin-subnav-link">💿 Albums</a>
        <a href="/admin/page/multimedia-sources" class="fav-admin-subnav-link">🎛️ Sources</a>
        <a href="/admin/page/multimedia-subtitles" class="fav-admin-subnav-link">💬 Subtitles</a>
        <a href="/admin/page/multimedia-analytics" class="fav-admin-subnav-link">📊 Analytics</a>
        <a href="/admin/page/multimedia-settings" class="fav-admin-subnav-link active">⚙️ Settings</a>
    </div>

    <div class="fav-admin-stat-card" style="max-width: 680px;">
        <form method="POST" action="/admin/page/multimedia-settings">
            <?php echo csrf_field(); ?>

            <div class="fav-form-group">
                <label class="fav-form-label">Global Downloads Feature *</label>
                <select name="enable_downloads" class="fav-form-control">
                    <option value="yes" <?php echo ($enableDownloads === 'yes') ? 'selected' : ''; ?>>Enabled (Allow users to download when content policy permits)</option>
                    <option value="no" <?php echo ($enableDownloads === 'no') ? 'selected' : ''; ?>>Disabled (Globally disable media download button site-wide)</option>
                </select>
                <small style="color:#64748b; font-size:12px; display:block; margin-top:4px;">
                    When set to Disabled, all download routes and player download buttons are denied regardless of content permissions.
                </small>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Default Video Preferred Resolution</label>
                <select name="default_video_resolution" class="fav-form-control">
                    <option value="1080p" <?php echo ($resolution === '1080p') ? 'selected' : ''; ?>>1080p Full HD</option>
                    <option value="720p" <?php echo ($resolution === '720p') ? 'selected' : ''; ?>>720p HD</option>
                    <option value="480p" <?php echo ($resolution === '480p') ? 'selected' : ''; ?>>480p SD</option>
                    <option value="4k" <?php echo ($resolution === '4k') ? 'selected' : ''; ?>>4K Ultra HD</option>
                </select>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Player Accent Brand Color</label>
                <input type="color" name="player_theme_color" value="<?php echo htmlspecialchars($themeColor, ENT_QUOTES, 'UTF-8'); ?>" style="height: 38px; width: 80px; padding: 2px; border: 1px solid #cbd5e1; border-radius: 4px; cursor: pointer;">
                <span style="font-size: 13px; color: #64748b; margin-left: 8px;">Default: #2563EB (Favorite Blue)</span>
            </div>

            <hr style="border:0; border-top:1px solid #e2e8f0; margin: 24px 0;">
            <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: #0f172a;">🧭 Content Discovery &amp; Trending Settings</h3>

            <div class="fav-form-group">
                <label class="fav-form-label">Content Discovery Engine *</label>
                <select name="enable_discovery" class="fav-form-control">
                    <option value="yes" <?php echo ($enableDiscovery === 'yes') ? 'selected' : ''; ?>>Enabled (Show related content rails, personalized feeds &amp; discovery)</option>
                    <option value="no" <?php echo ($enableDiscovery === 'no') ? 'selected' : ''; ?>>Disabled (Hide all discovery and recommendation rails)</option>
                </select>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Trending Now Feed *</label>
                <select name="enable_trending" class="fav-form-control">
                    <option value="yes" <?php echo ($enableTrending === 'yes') ? 'selected' : ''; ?>>Enabled (Calculate and display trending content based on recent engagement)</option>
                    <option value="no" <?php echo ($enableTrending === 'no') ? 'selected' : ''; ?>>Disabled (Fall back to all-time popular ranking)</option>
                </select>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Trending Window Duration (Days)</label>
                <input type="number" name="trending_window_days" value="<?php echo (int)($trendingWindowDays ?? 7); ?>" min="1" max="90" class="fav-form-control" style="max-width: 140px;">
                <small style="color:#64748b; font-size:12px; display:block; margin-top:4px;">
                    Rolling number of days considered for trending calculations (default: 7 days).
                </small>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Maximum Discovery Items Per Rail</label>
                <input type="number" name="max_discovery_items" value="<?php echo (int)($maxDiscoveryItems ?? 10); ?>" min="4" max="30" class="fav-form-control" style="max-width: 140px;">
                <small style="color:#64748b; font-size:12px; display:block; margin-top:4px;">
                    Maximum number of candidate cards shown in horizontal discovery rails (default: 10).
                </small>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">User Review Moderation Policy</label>
                <select name="review_moderation_mode" class="fav-form-control" style="max-width: 250px;">
                    <option value="auto_approve" <?php echo ($reviewModerationMode ?? 'auto_approve') === 'auto_approve' ? 'selected' : ''; ?>>Auto-Approve (Immediate publication)</option>
                    <option value="require_approval" <?php echo ($reviewModerationMode ?? '') === 'require_approval' ? 'selected' : ''; ?>>Require Moderation (Hold in queue)</option>
                </select>
                <small style="color:#64748b; font-size:12px; display:block; margin-top:4px;">
                    Choose whether user-written reviews are immediately visible or held in the moderation queue.
                </small>
            </div>

            <hr style="border:0; border-top:1px solid #e2e8f0; margin: 24px 0;">
            <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: #0f172a;">🌐 Trusted External Embed Domains</h3>
            <div class="fav-form-group">
                <label class="fav-form-label">Allowed External Player Domains (One per line)</label>
                <textarea name="trusted_embed_domains" class="fav-form-control" rows="4" placeholder="player.vimeo.com&#10;youtube.com&#10;embed.example.com"><?php echo htmlspecialchars($trustedEmbedDomains ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                <small style="color:#64748b; font-size:12px; display:block; margin-top:4px;">
                    Enter trusted third-party player domains (e.g. <code>player.twitch.tv</code>, <code>dailymotion.com</code>). Embed URLs from these domains are allowed for safe sandboxed iframe playback. (YouTube and Vimeo are always trusted by default).
                </small>
            </div>

            <div style="margin-top: 24px;">
                <button type="submit" class="fav-admin-btn">Save Settings</button>
            </div>
        </form>
    </div>
</div>


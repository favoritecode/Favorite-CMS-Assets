<?php
/**
 * Favorite Multimedia — Admin Episodes View
 */
$isEditing = ($editEpisode !== null);
?>
<link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-admin.css">

<div class="fav-admin-wrap">
    <div class="fav-admin-header">
        <h2 class="fav-admin-title">🎞️ Episodes Management</h2>
        <a href="/admin/page/multimedia-seasons" class="fav-admin-btn fav-admin-btn-secondary">&larr; Back to Seasons</a>
    </div>

    <!-- Quick Navigation Bar -->
    <div class="fav-admin-subnav">
        <a href="/admin/page/multimedia" class="fav-admin-subnav-link">🏠 Dashboard</a>
        <a href="/admin/page/multimedia-movies" class="fav-admin-subnav-link">🎬 Movies</a>
        <a href="/admin/page/multimedia-series" class="fav-admin-subnav-link">📺 Web Series</a>
        <a href="/admin/page/multimedia-seasons" class="fav-admin-subnav-link">📼 Seasons</a>
        <a href="/admin/page/multimedia-episodes" class="fav-admin-subnav-link active">🎞️ Episodes</a>
        <a href="/admin/page/multimedia-songs" class="fav-admin-subnav-link">🎵 Songs</a>
        <a href="/admin/page/multimedia-playlists" class="fav-admin-subnav-link">🎼 Playlists</a>
        <a href="/admin/page/multimedia-genres" class="fav-admin-subnav-link">🏷️ Genres</a>
        <a href="/admin/page/multimedia-artists" class="fav-admin-subnav-link">🎤 Artists</a>
        <a href="/admin/page/multimedia-albums" class="fav-admin-subnav-link">💿 Albums</a>
        <a href="/admin/page/multimedia-sources" class="fav-admin-subnav-link">🎛️ Sources</a>
        <a href="/admin/page/multimedia-subtitles" class="fav-admin-subnav-link">💬 Subtitles</a>
        <a href="/admin/page/multimedia-analytics" class="fav-admin-subnav-link">📊 Analytics</a>
        <a href="/admin/page/multimedia-moderation" class="fav-admin-subnav-link">🛡️ Moderation</a>
        <a href="/admin/page/multimedia-settings" class="fav-admin-subnav-link">⚙️ Settings</a>
        <a href="/admin/page/multimedia-releases" class="fav-admin-subnav-link">📅 Releases</a>
    </div>

    <!-- Filter by Season -->
    <div style="margin-bottom: 20px; background: #fff; padding: 12px 16px; border: 1px solid #e2e8f0; border-radius: 6px;">
        <form method="GET" action="/admin/page/multimedia-episodes" style="display:flex; align-items:center; gap:8px;">
            <label style="font-weight: 600; margin-right: 4px;">Filter by Season:</label>
            <select name="season_id" class="fav-form-control" style="width: auto; display: inline-block;" onchange="this.form.submit()">
                <option value="0">-- All Seasons --</option>
                <?php foreach ($seasons as $s): ?>
                    <option value="<?php echo $s->id; ?>" <?php echo ($s->id == $selectedSeasonId) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($s->getSeries()?->title . ' — ' . $s->title, ENT_QUOTES, 'UTF-8'); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <!-- Episode Form -->
    <div class="fav-admin-stat-card" style="margin-bottom: 24px;">
        <h3 style="margin-top:0; font-size:16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px;">
            <?php echo $isEditing ? 'Edit Episode: ' . htmlspecialchars($editEpisode->title, ENT_QUOTES, 'UTF-8') : '+ Add New Episode'; ?>
        </h3>

        <?php 
            $curSeries = $editEpisode ? $editEpisode->getSeries() : null;
            $parentSeriesAccess = $curSeries ? ($curSeries->access_mode ?? 'public') : 'public';
        ?>
        <div class="fav-hierarchy-banner">
            <strong>Parent Series Access:</strong> <span class="fav-badge fav-badge-<?php echo strtolower($parentSeriesAccess); ?>"><?php echo strtoupper($parentSeriesAccess); ?></span>
            &nbsp;|&nbsp; 
            <strong>Free Pilot Option:</strong> You can set this episode to <code>PUBLIC</code> to allow free streaming of a pilot episode even when the series is <code>PREMIUM</code>!
        </div>

        <form method="POST" action="/admin/page/multimedia-episodes">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="<?php echo $isEditing ? 'edit' : 'create'; ?>">
            <input type="hidden" name="id" value="<?php echo $editEpisode->id ?? 0; ?>">

            <div class="fav-form-row">
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Parent Season *</label>
                        <select name="season_id" class="fav-form-control" required id="fav_ep_season">
                            <?php foreach ($seasons as $s): ?>
                                <option value="<?php echo $s->id; ?>" data-series="<?php echo $s->series_id; ?>" data-series-access="<?php echo $s->getSeries()?->access_mode ?? 'public'; ?>" <?php echo (($editEpisode?->season_id ?? $selectedSeasonId) == $s->id) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($s->getSeries()?->title . ' — ' . $s->title, ENT_QUOTES, 'UTF-8'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="series_id" id="fav_ep_series" value="<?php echo $editEpisode?->series_id ?? ($seasons[0]->series_id ?? 0); ?>">
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Episode Number *</label>
                        <input type="number" name="episode_number" class="fav-form-control" value="<?php echo $editEpisode->episode_number ?? (count($episodes) + 1); ?>" required min="1">
                        <span class="fav-form-hint">Sequential episode number in season</span>
                    </div>
                </div>
            </div>

            <div class="fav-form-row">
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Episode Title *</label>
                        <input type="text" name="title" id="fav_ep_title" class="fav-form-control" value="<?php echo htmlspecialchars($editEpisode->title ?? '', ENT_QUOTES, 'UTF-8'); ?>" required placeholder="e.g. Pilot">
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Slug</label>
                        <input type="text" name="slug" id="fav_ep_slug" class="fav-form-control" value="<?php echo htmlspecialchars($editEpisode->slug ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="auto-generated from title">
                        <span class="fav-form-hint">URL: /episode/your-slug</span>
                    </div>
                </div>
            </div>

            <div class="fav-form-group">
                <label class="fav-form-label">Synopsis</label>
                <textarea name="description" class="fav-form-control" rows="3" placeholder="Episode summary..."><?php echo htmlspecialchars($editEpisode->description ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>

            <div class="fav-form-row">
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Thumbnail URL / Path</label>
                        <input type="text" name="thumbnail" id="fav_ep_thumb" class="fav-form-control" value="<?php echo htmlspecialchars($editEpisode->thumbnail ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://... or /uploads/...">
                        <span class="fav-form-hint">16:9 episode still frame image</span>
                        <?php if (!empty($editEpisode->thumbnail)): ?>
                            <img src="<?php echo htmlspecialchars($editEpisode->thumbnail, ENT_QUOTES, 'UTF-8'); ?>" alt="" class="fav-img-preview" id="fav_ep_thumb_prev" style="max-width: 140px; max-height: 80px;">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Duration (Seconds)</label>
                        <input type="number" name="duration" class="fav-form-control" value="<?php echo $editEpisode->duration ?? 2700; ?>" placeholder="e.g. 2700 for 45 min">
                        <span class="fav-form-hint"><?php echo $editEpisode ? round(($editEpisode->duration ?? 0) / 60) . ' minutes' : 'e.g. 2700 = 45m'; ?></span>
                    </div>
                </div>
            </div>

            <div class="fav-form-row">
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Access Mode (Override Behavior) *</label>
                        <select name="access_mode" class="fav-form-control" id="fav_ep_access_select">
                            <option value="inherit" <?php echo ($editEpisode?->access_mode === 'inherit') ? 'selected' : ''; ?>>
                                Inherit from Series (Current: <?php echo strtoupper($parentSeriesAccess); ?>)
                            </option>
                            <option value="public" <?php echo ($editEpisode?->access_mode === 'public') ? 'selected' : ''; ?>>
                                PUBLIC (Free for all — Free Pilot Episode Override)
                            </option>
                            <option value="login" <?php echo ($editEpisode?->access_mode === 'login') ? 'selected' : ''; ?>>
                                LOGIN REQUIRED (Logged-in members only)
                            </option>
                            <option value="premium" <?php echo ($editEpisode?->access_mode === 'premium') ? 'selected' : ''; ?>>
                                PREMIUM (Favorite Digital entitlement required)
                            </option>
                        </select>
                        <span class="fav-form-hint">Resolved effective access: <strong><?php echo strtoupper($editEpisode ? $editEpisode->getResolvedAccessMode() : $parentSeriesAccess); ?></strong></span>
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Download Policy *</label>
                        <select name="download_policy" class="fav-form-control">
                            <option value="inherit" <?php echo ($editEpisode?->download_policy === 'inherit') ? 'selected' : ''; ?>>Inherit from Series</option>
                            <option value="allow" <?php echo ($editEpisode?->download_policy === 'allow') ? 'selected' : ''; ?>>Allow Downloads</option>
                            <option value="deny" <?php echo ($editEpisode?->download_policy === 'deny') ? 'selected' : ''; ?>>Deny Downloads</option>
                        </select>
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Publication Status *</label>
                        <select name="status" id="fav_pub_status" class="fav-form-control" onchange="toggleSchedulingFields(this.value)">
                            <option value="published" <?php echo ($editEpisode?->status === 'published' || !$isEditing) ? 'selected' : ''; ?>>Published (Live)</option>
                            <option value="scheduled" <?php echo ($editEpisode?->status === 'scheduled') ? 'selected' : ''; ?>>Scheduled for Release</option>
                            <option value="draft" <?php echo ($editEpisode?->status === 'draft') ? 'selected' : ''; ?>>Draft (Hidden)</option>
                            <option value="unpublished" <?php echo ($editEpisode?->status === 'unpublished') ? 'selected' : ''; ?>>Unpublished (Archived)</option>
                        </select>
                        <span class="fav-form-hint">Drafts and scheduled items are hidden from visitors.</span>
                    </div>
                </div>
            </div>

            <!-- Scheduling Row -->
            <?php 
            $tz = \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::getAppTimezone();
            $pubAtLocal = !empty($editEpisode?->publish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editEpisode->publish_at, 'Y-m-d\TH:i') : '';
            $unpubAtLocal = !empty($editEpisode?->unpublish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editEpisode->unpublish_at, 'Y-m-d\TH:i') : '';
            $showSched = ($editEpisode?->status === 'scheduled');
            ?>
            <div class="fav-form-row" id="fav_scheduling_row" style="margin-top: 10px; <?php echo $showSched ? '' : 'display:none;'; ?>">
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Schedule Release Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                        <input type="datetime-local" name="publish_at" class="fav-form-control" value="<?php echo htmlspecialchars($pubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                        <span class="fav-form-hint">Automatically publishes when due and notifies series followers.</span>
                    </div>
                </div>
                <div class="fav-form-col">
                    <div class="fav-form-group">
                        <label class="fav-form-label">Optional Unpublish Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                        <input type="datetime-local" name="unpublish_at" class="fav-form-control" value="<?php echo htmlspecialchars($unpubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                        <span class="fav-form-hint">Automatically unpublishes after this time (optional).</span>
                    </div>
                </div>
            </div>

            <div style="display: flex; gap: 10px; align-items: center;">
                <button type="submit" class="fav-admin-btn" style="padding: 10px 22px; font-size: 14px;"><?php echo $isEditing ? 'Save Changes' : 'Create Episode'; ?></button>
                <?php if ($isEditing): ?>
                    <a href="/admin/page/multimedia-episodes?season_id=<?php echo $editEpisode->season_id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 16px; font-size: 14px;">Cancel</a>
                    <a href="/episode/<?php echo htmlspecialchars($editEpisode->slug, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 16px; font-size: 14px;">Preview Episode &rarr;</a>
                <?php endif; ?>
            </div>
        </form>

        <?php if ($isEditing): ?>
            <!-- Attached Media Sources & Subtitles for Episode -->
            <hr style="margin: 24px 0; border: none; border-top: 1px solid #e2e8f0;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px;">
                <!-- Media Sources -->
                <div class="fav-form-section" style="margin-bottom: 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h4 style="margin:0; font-size:14px; font-weight:700;">🎛️ Media Sources (<?php $epSources = $editEpisode->getSources(false); echo count($epSources); ?>)</h4>
                        <a href="/admin/page/multimedia-sources?content_type=episode&content_id=<?php echo $editEpisode->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size:11px; padding:3px 8px;">+ Manage Sources</a>
                    </div>
                    <?php if (empty($epSources)): ?>
                        <p style="color:#94a3b8; font-size:12px; margin:0;">No video stream attached yet. Click "+ Manage Sources" to attach video URL or path.</p>
                    <?php else: ?>
                        <table class="fav-admin-table" style="font-size:12px; margin:0;">
                            <thead><tr><th>Label</th><th>Format</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php foreach ($epSources as $es): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($es->label, ENT_QUOTES, 'UTF-8'); ?></strong> <?php if ($es->is_default) echo '⭐'; ?></td>
                                        <td><code><?php echo strtoupper($es->source_type); ?></code></td>
                                        <td><?php echo ucfirst($es->status ?? 'active'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- Subtitles -->
                <div class="fav-form-section" style="margin-bottom: 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h4 style="margin:0; font-size:14px; font-weight:700;">💬 Subtitle Tracks (<?php $epSubs = $editEpisode->getSubtitles(); echo count($epSubs); ?>)</h4>
                        <a href="/admin/page/multimedia-subtitles?content_type=episode&content_id=<?php echo $editEpisode->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size:11px; padding:3px 8px;">+ Manage Subtitles</a>
                    </div>
                    <?php if (empty($epSubs)): ?>
                        <p style="color:#94a3b8; font-size:12px; margin:0;">No subtitles registered yet.</p>
                    <?php else: ?>
                        <table class="fav-admin-table" style="font-size:12px; margin:0;">
                            <thead><tr><th>Language</th><th>Label</th><th>Default</th></tr></thead>
                            <tbody>
                                <?php foreach ($epSubs as $sub): ?>
                                    <tr>
                                        <td><code><?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?></code></td>
                                        <td><?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo $sub->is_default ? '⭐ Yes' : 'No'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Episodes List -->
    <table class="fav-admin-table">
        <thead>
            <tr>
                <th>Ep #</th>
                <th>Title</th>
                <th>Access Mode</th>
                <th>Duration</th>
                <th>Sources</th>
                <th>Status</th>
                <th style="text-align: right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($episodes)): ?>
                <tr><td colspan="7" style="text-align:center; color:#94a3b8;">No episodes found.</td></tr>
            <?php else: foreach ($episodes as $ep): ?>
                <tr>
                    <td><strong>E<?php echo $ep->episode_number; ?></strong></td>
                    <td>
                        <strong><?php echo htmlspecialchars($ep->title, ENT_QUOTES, 'UTF-8'); ?></strong>
                        <div style="font-size: 11px; color:#64748b;">/episode/<?php echo htmlspecialchars($ep->slug, ENT_QUOTES, 'UTF-8'); ?></div>
                    </td>
                    <td><span class="fav-badge fav-badge-<?php echo strtolower($ep->getResolvedAccessMode()); ?>"><?php echo strtoupper($ep->access_mode === 'inherit' ? 'Inherit (' . $ep->getResolvedAccessMode() . ')' : $ep->access_mode); ?></span></td>
                    <td><?php echo round(($ep->duration ?? 0) / 60); ?>m</td>
                    <td><a href="/admin/page/multimedia-sources?content_type=episode&content_id=<?php echo $ep->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 2px 8px; font-size: 11px;"><?php echo count($ep->getSources(false)); ?> Sources</a></td>
                    <td><?php echo ucfirst($ep->status ?? 'published'); ?></td>
                    <td style="text-align: right; white-space: nowrap;">
                        <a href="/episode/<?php echo htmlspecialchars($ep->slug, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 2px 8px; font-size: 11px;">View</a>
                        <a href="/admin/page/multimedia-episodes?season_id=<?php echo $ep->season_id; ?>&edit=<?php echo $ep->id; ?>" class="fav-admin-btn" style="padding: 2px 8px; font-size: 11px;">Edit</a>
                        <form method="POST" action="/admin/page/multimedia-episodes" style="display:inline;" onsubmit="return confirm('Delete episode?');">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $ep->id; ?>">
                            <input type="hidden" name="season_id" value="<?php echo $ep->season_id; ?>">
                            <button type="submit" class="fav-admin-btn fav-admin-btn-danger" style="padding: 2px 8px; font-size: 11px;">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const seasonSelect = document.getElementById('fav_ep_season');
    if (seasonSelect) {
        seasonSelect.addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            const seriesId = selected.getAttribute('data-series');
            if (seriesId) {
                document.getElementById('fav_ep_series').value = seriesId;
            }
        });
    }

    const titleInput = document.getElementById('fav_ep_title');
    const slugInput = document.getElementById('fav_ep_slug');
    if (titleInput && slugInput) {
        titleInput.addEventListener('input', function() {
            if (!slugInput.value || slugInput.dataset.autoSlug !== 'false') {
                slugInput.value = this.value
                    .toLowerCase()
                    .replace(/[^\w\s-]/g, '')
                    .trim()
                    .replace(/\s+/g, '-');
            }
        });
        slugInput.addEventListener('input', function() {
            slugInput.dataset.autoSlug = 'false';
        });
    }

    const thumbInput = document.getElementById('fav_ep_thumb');
    if (thumbInput) {
        thumbInput.addEventListener('change', function() {
            let prev = document.getElementById('fav_ep_thumb_prev');
            if (this.value) {
                if (!prev) {
                    prev = document.createElement('img');
                    prev.id = 'fav_ep_thumb_prev';
                    prev.className = 'fav-img-preview';
                    prev.style.maxWidth = '140px';
                    prev.style.maxHeight = '80px';
                    thumbInput.parentNode.appendChild(prev);
                }
                prev.src = this.value;
                prev.style.display = 'block';
            } else if (prev) {
                prev.style.display = 'none';
            }
function toggleSchedulingFields(status) {
    const row = document.getElementById('fav_scheduling_row');
    if (row) {
        row.style.display = (status === 'scheduled') ? 'flex' : 'none';
    }
}
</script>


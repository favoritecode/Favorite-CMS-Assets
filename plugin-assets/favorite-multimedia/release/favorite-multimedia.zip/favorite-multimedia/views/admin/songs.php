<?php
/**
 * Favorite Multimedia — Admin Songs View
 */
$isEditing = ($editSong !== null);
$selectedGenres = $isEditing ? array_column($editSong->getGenres(), 'id') : [];
?>
<link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-admin.css">

<div class="fav-admin-wrap">
    <div class="fav-admin-header">
        <h2 class="fav-admin-title">🎵 Songs &amp; Audio Management</h2>
        <?php if ($isEditing): ?>
            <a href="/admin/page/multimedia-songs" class="fav-admin-btn fav-admin-btn-secondary">&larr; Back to Songs List</a>
        <?php endif; ?>
    </div>

    <!-- Quick Navigation Bar -->
    <div class="fav-admin-subnav">
        <a href="/admin/page/multimedia" class="fav-admin-subnav-link">🏠 Dashboard</a>
        <a href="/admin/page/multimedia-movies" class="fav-admin-subnav-link">🎬 Movies</a>
        <a href="/admin/page/multimedia-series" class="fav-admin-subnav-link">📺 Web Series</a>
        <a href="/admin/page/multimedia-seasons" class="fav-admin-subnav-link">📼 Seasons</a>
        <a href="/admin/page/multimedia-episodes" class="fav-admin-subnav-link">🎞️ Episodes</a>
        <a href="/admin/page/multimedia-songs" class="fav-admin-subnav-link active">🎵 Songs</a>
        <a href="/admin/page/multimedia-playlists" class="fav-admin-subnav-link">🎼 Playlists</a>
        <a href="/admin/page/multimedia-genres" class="fav-admin-subnav-link">🏷️ Genres</a>
        <a href="/admin/page/multimedia-artists" class="fav-admin-subnav-link">🎤 Artists</a>
        <a href="/admin/page/multimedia-albums" class="fav-admin-subnav-link">💿 Albums</a>
        <a href="/admin/page/multimedia-sources" class="fav-admin-subnav-link">🎛️ Advanced Sources</a>
        <a href="/admin/page/multimedia-subtitles" class="fav-admin-subnav-link">💬 Subtitles</a>
        <a href="/admin/page/multimedia-analytics" class="fav-admin-subnav-link">📊 Analytics</a>
        <a href="/admin/page/multimedia-moderation" class="fav-admin-subnav-link">🛡️ Moderation</a>
        <a href="/admin/page/multimedia-settings" class="fav-admin-subnav-link">⚙️ Settings</a>
        <a href="/admin/page/multimedia-releases" class="fav-admin-subnav-link">📅 Releases</a>
    </div>

    <?php if ($isEditing || isset($_GET['new'])): ?>
        <div class="fav-admin-stat-card" style="margin-bottom: 28px;">
            <h3 style="margin-top:0; font-size:18px; border-bottom:1px solid #e2e8f0; padding-bottom:10px;">
                <?php echo $isEditing ? 'Edit Song: ' . htmlspecialchars($editSong->title, ENT_QUOTES, 'UTF-8') : '+ Create New Song'; ?>
            </h3>

            <form method="POST" action="/admin/page/multimedia-songs" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="<?php echo $isEditing ? 'edit' : 'create'; ?>">
                <input type="hidden" name="id" value="<?php echo $editSong->id ?? 0; ?>">

                <!-- SECTION 1: Basic Information -->
                <div class="fav-form-section">
                    <div class="fav-form-section-title">🎵 Track Information</div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Song Title *</label>
                                <input type="text" name="title" id="fav_song_title" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->title ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. Midnight Horizon" required>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Slug</label>
                                <input type="text" name="slug" id="fav_song_slug" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->slug ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="midnight-horizon">
                                <div class="fav-form-hint">Leave blank to auto-generate from song title.</div>
                            </div>
                        </div>
                    </div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <div style="display:flex; justify-content:space-between; align-items:center;">
                                    <label class="fav-form-label">Artist</label>
                                    <a href="/admin/page/multimedia-artists" target="_blank" style="font-size:11px; color:#2563eb; text-decoration:none;">+ New Artist</a>
                                </div>
                                <select name="artist_id" class="fav-form-control">
                                    <option value="0">-- None / Unknown --</option>
                                    <?php foreach ($artists as $a): ?>
                                        <option value="<?php echo $a->id; ?>" <?php echo (($editSong?->artist_id ?? 0) == $a->id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($a->name, ENT_QUOTES, 'UTF-8'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <div style="display:flex; justify-content:space-between; align-items:center;">
                                    <label class="fav-form-label">Album</label>
                                    <a href="/admin/page/multimedia-albums" target="_blank" style="font-size:11px; color:#2563eb; text-decoration:none;">+ New Album</a>
                                </div>
                                <select name="album_id" class="fav-form-control">
                                    <option value="0">-- Single / No Album --</option>
                                    <?php foreach ($albums as $al): ?>
                                        <option value="<?php echo $al->id; ?>" <?php echo (($editSong?->album_id ?? 0) == $al->id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($al->title, ENT_QUOTES, 'UTF-8'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Language</label>
                                <input type="text" name="language" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->language ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. English, Instrumental">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SECTION 2: Audio & Media -->
                <div class="fav-form-section" style="border: 2px solid #3b82f6; background: #f0f7ff;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid #bfdbfe; padding-bottom: 8px;">
                        <h4 style="margin:0; font-size: 15px; font-weight: 700; color: #1e40af; display: flex; align-items: center; gap: 8px;">
                            🔊 Audio Source &amp; Media
                            <?php if ($isEditing): ?>
                                <?php $curStatus = $mediaStatuses[$editSong->id] ?? ['status' => 'no_media', 'label' => 'No Media', 'class' => 'fav-badge-gray']; ?>
                                <span class="fav-badge <?= $curStatus['class'] ?>"><?= htmlspecialchars($curStatus['label'], ENT_QUOTES, 'UTF-8') ?></span>
                            <?php endif; ?>
                        </h4>
                        <?php if ($isEditing): ?>
                            <a href="/admin/page/multimedia-sources?content_type=song&content_id=<?= $editSong->id ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size: 11px; padding: 3px 8px;" target="_blank">🎛️ Advanced Sources &rarr;</a>
                        <?php endif; ?>
                    </div>

                    <?php 
                        $curDefault = $isEditing ? ($defaultSources[$editSong->id] ?? null) : null;
                        $uploadMax = ini_get('upload_max_filesize') ?: '2M';
                        $postMax = ini_get('post_max_size') ?: '8M';
                    ?>

                    <?php if ($curDefault): ?>
                        <div style="background: #fff; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px 14px; margin-bottom: 14px; font-size: 13px;">
                            <strong>Current Default Audio:</strong> <code><?= strtoupper($curDefault->source_type) ?></code> &bull;
                            <span style="color: #475569;"><?= htmlspecialchars($curDefault->label ?: 'Main Audio', ENT_QUOTES, 'UTF-8') ?></span> &bull;
                            <a href="<?= htmlspecialchars($curDefault->url_or_path, ENT_QUOTES, 'UTF-8') ?>" target="_blank" style="color: #2563eb; word-break: break-all;"><?= htmlspecialchars($curDefault->url_or_path, ENT_QUOTES, 'UTF-8') ?></a>
                        </div>
                    <?php endif; ?>

                    <div class="fav-media-tabs">
                        <button type="button" class="fav-media-tab-btn active" id="fav_tab_btn_upload" onclick="switchAudioTab('upload')">📁 Upload Audio File</button>
                        <button type="button" class="fav-media-tab-btn" id="fav_tab_btn_url" onclick="switchAudioTab('url')">🔗 Direct Audio URL</button>
                    </div>

                    <!-- Upload Pane -->
                    <div id="fav_pane_upload" style="display: block;">
                        <div class="fav-form-group">
                            <label class="fav-form-label">Select Audio File (MP3, M4A, FLAC, WAV, AAC, OGG)</label>
                            <input type="file" name="audio_file" id="fav_audio_file" class="fav-form-control" accept="audio/*,.mp3,.m4a,.flac,.wav,.aac,.ogg">
                            <span class="fav-form-hint">Server upload limit: <strong><?= htmlspecialchars($uploadMax) ?></strong> (post_max_size: <?= htmlspecialchars($postMax) ?>). Direct streaming playback supported across all modern browsers.</span>
                        </div>
                    </div>

                    <!-- URL Pane -->
                    <div id="fav_pane_url" style="display: none;">
                        <div class="fav-form-group">
                            <label class="fav-form-label">Direct Audio Stream URL</label>
                            <input type="text" name="audio_url" id="fav_source_url" class="fav-form-control" placeholder="https://example.com/audio/track.mp3 or storage/multimedia/track.mp3">
                            <span class="fav-form-hint">Direct HTTPS link to audio stream file.</span>
                        </div>
                    </div>

                    <div class="fav-form-row" style="margin-top: 10px;">
                        <div class="fav-form-col">
                            <div class="fav-form-group" style="margin-bottom: 0;">
                                <label class="fav-form-label">Audio Label (Optional)</label>
                                <input type="text" name="source_label" class="fav-form-control" placeholder="e.g. Master Audio / Studio Mix">
                            </div>
                        </div>
                    </div>

                    <!-- Cover Artwork & Metadata -->
                    <div class="fav-form-row" style="margin-top: 14px; border-top: 1px solid #bfdbfe; padding-top: 12px;">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Cover Artwork URL or Local Path</label>
                                <input type="text" name="cover" id="fav_song_cover" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->cover ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://.../cover.jpg">
                                <input type="file" name="cover_file" class="fav-form-control" accept="image/*" style="margin-top: 6px;">
                                <span class="fav-form-hint">Upload square cover image directly or paste URL above. Recommended: 1:1 square.</span>
                                <img id="fav_song_cover_preview" src="<?php echo htmlspecialchars($editSong->cover ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="fav-img-preview <?php echo empty($editSong->cover) ? 'fav-img-hidden' : ''; ?>" alt="Cover Preview" style="width: 80px; height: 80px;">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Duration (Seconds)</label>
                                <input type="number" name="duration" class="fav-form-control" value="<?php echo $editSong->duration ?? 180; ?>" min="0">
                                <div class="fav-form-hint"><?php echo $editSong ? 'Formatted: ' . ($editSong->getDurationFormatted() ?: '00:00') : 'e.g. 180 for 3:00'; ?></div>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Release Date</label>
                                <input type="date" name="release_date" class="fav-form-control" value="<?php echo $editSong->release_date ?? ''; ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SECTION 3: Access & Settings -->
                <div class="fav-form-section">
                    <div class="fav-form-section-title">🔒 Access Control &amp; Publishing</div>

                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Access Mode *</label>
                                <select name="access_mode" class="fav-form-control">
                                    <option value="public" <?php echo ($editSong?->access_mode === 'public') ? 'selected' : ''; ?>>PUBLIC (Free for all)</option>
                                    <option value="login" <?php echo ($editSong?->access_mode === 'login') ? 'selected' : ''; ?>>LOGIN REQUIRED</option>
                                    <option value="premium" <?php echo ($editSong?->access_mode === 'premium') ? 'selected' : ''; ?>>PREMIUM</option>
                                </select>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Download Policy *</label>
                                <select name="download_policy" class="fav-form-control">
                                    <option value="inherit" <?php echo ($editSong?->download_policy === 'inherit') ? 'selected' : ''; ?>>Inherit Global</option>
                                    <option value="allow" <?php echo ($editSong?->download_policy === 'allow') ? 'selected' : ''; ?>>Allow Download</option>
                                    <option value="deny" <?php echo ($editSong?->download_policy === 'deny') ? 'selected' : ''; ?>>Deny Download</option>
                                </select>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Publication Status *</label>
                                <select name="status" id="fav_pub_status" class="fav-form-control" onchange="toggleSchedulingFields(this.value)">
                                    <option value="published" <?php echo ($editSong?->status === 'published' || !$isEditing) ? 'selected' : ''; ?>>Published (Live)</option>
                                    <option value="scheduled" <?php echo ($editSong?->status === 'scheduled') ? 'selected' : ''; ?>>Scheduled for Release</option>
                                    <option value="draft" <?php echo ($editSong?->status === 'draft') ? 'selected' : ''; ?>>Draft (Hidden)</option>
                                    <option value="unpublished" <?php echo ($editSong?->status === 'unpublished') ? 'selected' : ''; ?>>Unpublished (Archived)</option>
                                </select>
                                <span class="fav-form-hint">Drafts and scheduled items are hidden from visitors.</span>
                            </div>
                        </div>
                    </div>

                    <!-- Scheduling Row -->
                    <?php 
                    $tz = \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::getAppTimezone();
                    $pubAtLocal = !empty($editSong?->publish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editSong->publish_at, 'Y-m-d\TH:i') : '';
                    $unpubAtLocal = !empty($editSong?->unpublish_at) ? \FavoriteCMS\Multimedia\Services\MultimediaReleaseService::utcToLocal($editSong->unpublish_at, 'Y-m-d\TH:i') : '';
                    $showSched = ($editSong?->status === 'scheduled');
                    ?>
                    <div class="fav-form-row" id="fav_scheduling_row" style="margin-top: 10px; <?php echo $showSched ? '' : 'display:none;'; ?>">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Schedule Release Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                                <input type="datetime-local" name="publish_at" class="fav-form-control" value="<?php echo htmlspecialchars($pubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="fav-form-hint">Automatically publishes when due and notifies artist followers.</span>
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Optional Unpublish Time (<?php echo htmlspecialchars($tz, ENT_QUOTES, 'UTF-8'); ?>)</label>
                                <input type="datetime-local" name="unpublish_at" class="fav-form-control" value="<?php echo htmlspecialchars($unpubAtLocal, ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="fav-form-hint">Automatically unpublishes after this time (optional).</span>
                            </div>
                        </div>
                    </div>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label style="font-size: 13px; font-weight: 600; padding-top: 24px; display: block;">
                                    <input type="checkbox" name="featured" value="1" <?php echo ($editSong?->featured ?? 0) ? 'checked' : ''; ?>>
                                    Featured Track ⭐
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SECTION 4: Genres & Lyrics -->
                <div class="fav-form-section">
                    <div class="fav-form-section-title">🏷️ Genres &amp; Lyrics</div>

                    <div class="fav-form-group">
                        <label class="fav-form-label">Genres</label>
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; padding: 6px 0;">
                            <?php foreach ($genres as $g): ?>
                                <label style="font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                    <input type="checkbox" name="genres[]" value="<?php echo $g->id; ?>" <?php echo in_array($g->id, $selectedGenres) ? 'checked' : ''; ?>>
                                    <?php echo htmlspecialchars($g->name, ENT_QUOTES, 'UTF-8'); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="fav-form-group">
                        <label class="fav-form-label">Description / Liner Notes</label>
                        <textarea name="description" class="fav-form-control" rows="2" placeholder="Brief notes about the track..."><?php echo htmlspecialchars($editSong->description ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>

                    <div class="fav-form-group">
                        <label class="fav-form-label">Lyrics</label>
                        <textarea name="lyrics" class="fav-form-control" rows="5" placeholder="Enter song lyrics here..."><?php echo htmlspecialchars($editSong->lyrics ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                </div>

                <!-- SECTION 5: SEO -->
                <div class="fav-form-section">
                    <div class="fav-form-section-title">🔍 Search Engine Optimization</div>
                    <div class="fav-form-row">
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">Custom SEO Title</label>
                                <input type="text" name="seo_title" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->seo_title ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Defaults to Song Title">
                            </div>
                        </div>
                        <div class="fav-form-col">
                            <div class="fav-form-group">
                                <label class="fav-form-label">SEO Meta Description</label>
                                <input type="text" name="seo_description" class="fav-form-control" value="<?php echo htmlspecialchars($editSong->seo_description ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Brief description for search engines">
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 16px;">
                    <button type="submit" name="submit_action" value="publish" class="fav-admin-btn" style="padding: 10px 22px; font-size: 14px; background: #16a34a; border-color: #16a34a;">🚀 Publish Now</button>
                    <button type="submit" name="submit_action" value="draft" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 18px; font-size: 14px;">📝 Save Draft</button>
                    <button type="submit" name="submit_action" value="schedule" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 18px; font-size: 14px;">📅 Schedule</button>
                    <?php if ($isEditing): ?>
                        <a href="/admin/page/multimedia-songs" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 10px 18px; font-size: 14px;">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($isEditing): ?>
                <!-- Attached Media Sources for Song -->
                <div style="margin-top: 32px; border-top: 2px dashed #e2e8f0; padding-top: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <h4 style="margin: 0; font-size: 15px; color: #1e40af;">🎛️ Audio Sources for this Song</h4>
                        <a href="/admin/page/multimedia-sources?content_type=song&content_id=<?php echo $editSong->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="font-size: 12px;">+ Manage Sources</a>
                    </div>
                    <?php $attachedSources = $editSong->getSources(false); ?>
                    <?php if (empty($attachedSources)): ?>
                        <p style="color: #94a3b8; font-size: 13px; margin: 0;">No audio sources attached yet. <a href="/admin/page/multimedia-sources?content_type=song&content_id=<?php echo $editSong->id; ?>" style="color: #2563eb;">Add one now &rarr;</a></p>
                    <?php else: ?>
                        <table class="fav-admin-table" style="margin: 0; font-size: 13px;">
                            <thead>
                                <tr>
                                    <th>Label</th>
                                    <th>Type</th>
                                    <th>URL / Path</th>
                                    <th>Default</th>
                                    <th>Status</th>
                                    <th style="text-align: right;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($attachedSources as $src): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($src->label, ENT_QUOTES, 'UTF-8'); ?></strong></td>
                                        <td><code><?php echo strtoupper($src->source_type); ?></code></td>
                                        <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                             <a href="<?php echo htmlspecialchars($src->url_or_path, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" style="color: #2563eb;"><?php echo htmlspecialchars($src->url_or_path, ENT_QUOTES, 'UTF-8'); ?></a>
                                        </td>
                                        <td><?php echo $src->is_default ? '⭐ Yes' : 'No'; ?></td>
                                        <td><?php echo ucfirst($src->status); ?></td>
                                        <td style="text-align: right; white-space: nowrap;">
                                            <a href="/multimedia/stream/<?php echo $src->id; ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 2px 6px; font-size: 11px;">Test</a>
                                            <a href="/admin/page/multimedia-sources?edit=<?php echo $src->id; ?>" class="fav-admin-btn" style="padding: 2px 6px; font-size: 11px;">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0; font-size:16px;">All Songs (<?php echo count($items); ?>)</h3>
        <?php if (!$isEditing && !isset($_GET['new'])): ?>
            <a href="/admin/page/multimedia-songs?new=1" class="fav-admin-btn">+ Add New Song</a>
        <?php endif; ?>
    </div>

    <table class="fav-admin-table">
        <thead>
            <tr>
                <th style="width: 45px;">Cover</th>
                <th>Title</th>
                <th>Artist</th>
                <th>Album</th>
                <th>Duration</th>
                <th>Media</th>
                <th>Access</th>
                <th>Plays</th>
                <th>Status</th>
                <th style="text-align: right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($items)): ?>
                <tr>
                    <td colspan="10" style="padding: 0;">
                        <div class="fav-empty-card">
                            <div style="font-size: 44px; margin-bottom: 10px;">🎵</div>
                            <h3 style="font-size: 18px; margin: 0 0 8px 0; color: #1e293b;">No Songs Published Yet</h3>
                            <p style="color: #64748b; font-size: 14px; margin: 0 0 18px 0;">Publish your first song by uploading an audio track or providing an audio URL.</p>
                            <a href="/admin/page/multimedia-songs?new=1" class="fav-admin-btn" style="padding: 10px 24px; font-size: 14px;">+ Add First Song</a>
                        </div>
                    </td>
                </tr>
            <?php else: foreach ($items as $s): ?>
                <tr>
                    <td>
                        <?php if ($s->cover): ?>
                            <img src="<?php echo htmlspecialchars($s->cover, ENT_QUOTES, 'UTF-8'); ?>" alt="" style="width: 36px; height: 36px; object-fit: cover; border-radius: 4px;">
                        <?php else: ?>
                            <div style="width: 36px; height: 36px; background: #e2e8f0; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 14px;">🎵</div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($s->title, ENT_QUOTES, 'UTF-8'); ?></strong>
                        <?php if ($s->featured): ?><span style="font-size: 11px; color: #f59e0b;">⭐</span><?php endif; ?>
                        <div style="font-size: 11px; color:#64748b;">/song/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?></div>
                    </td>
                    <td><?php echo htmlspecialchars($s->getArtist()?->name ?: '—', ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($s->getAlbum()?->title ?: '—', ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo $s->getDurationFormatted() ?: '—'; ?></td>
                    <td>
                        <?php $sSt = $mediaStatuses[$s->id] ?? ['status' => 'no_media', 'label' => 'No Media', 'class' => 'fav-badge-gray']; ?>
                        <span class="fav-badge <?php echo $sSt['class']; ?>"><?php echo htmlspecialchars($sSt['label'], ENT_QUOTES, 'UTF-8'); ?></span>
                    </td>
                    <td><span class="fav-badge fav-badge-<?php echo strtolower($s->access_mode ?? 'public'); ?>"><?php echo strtoupper($s->access_mode ?? 'public'); ?></span></td>
                    <td><?php echo number_format((int)($s->plays_count ?? 0)); ?></td>
                    <td><?php echo ucfirst($s->status ?? 'published'); ?></td>
                    <td style="text-align: right; white-space: nowrap;">
                        <a href="/admin/page/multimedia-sources?content_type=song&content_id=<?php echo $s->id; ?>" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 2px 8px; font-size: 11px;">Sources</a>
                        <a href="/song/<?php echo htmlspecialchars($s->slug, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="fav-admin-btn fav-admin-btn-secondary" style="padding: 2px 8px; font-size: 11px;">View</a>
                        <a href="/admin/page/multimedia-songs?edit=<?php echo $s->id; ?>" class="fav-admin-btn" style="padding: 2px 8px; font-size: 11px;">Edit</a>
                        <form method="POST" action="/admin/page/multimedia-songs" style="display:inline;" onsubmit="return confirm('Delete this song?');">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $s->id; ?>">
                            <button type="submit" class="fav-admin-btn fav-admin-btn-danger" style="padding: 2px 8px; font-size: 11px;">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto slug generation
    const titleInput = document.getElementById('fav_song_title');
    const slugInput = document.getElementById('fav_song_slug');
    if (titleInput && slugInput && !slugInput.value) {
        titleInput.addEventListener('input', function() {
            slugInput.value = titleInput.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
        });
    }

    // Cover preview
    const coverInput = document.getElementById('fav_song_cover');
    const coverPreview = document.getElementById('fav_song_cover_preview');
    if (coverInput && coverPreview) {
        coverInput.addEventListener('input', function() {
            if (coverInput.value.trim()) {
                coverPreview.src = coverInput.value.trim();
                coverPreview.classList.remove('fav-img-hidden');
            } else {
                coverPreview.classList.add('fav-img-hidden');
            }
        });
    }
});

function toggleSchedulingFields(status) {
    const row = document.getElementById('fav_scheduling_row');
    if (row) {
        row.style.display = (status === 'scheduled') ? 'flex' : 'none';
    }
}

function switchAudioTab(tab) {
    document.querySelectorAll('.fav-media-tab-btn').forEach(b => b.classList.remove('active'));
    const btn = document.getElementById('fav_tab_btn_' + tab);
    if (btn) btn.classList.add('active');

    const uploadPane = document.getElementById('fav_pane_upload');
    const urlPane = document.getElementById('fav_pane_url');
    if (tab === 'upload') {
        if (uploadPane) uploadPane.style.display = 'block';
        if (urlPane) urlPane.style.display = 'none';
    } else {
        if (uploadPane) uploadPane.style.display = 'none';
        if (urlPane) urlPane.style.display = 'block';
    }
}
</script>
<script src="/plugins/favorite-multimedia/assets/js/multimedia-admin.js"></script>


# Changelog

All notable changes to the **Favorite Multimedia** plugin for Favorite CMS are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.1] - 2026-09-07 (Simple Media Publishing UX Update)

### Added
- **Direct Media Publishing on Content Forms**:
  - Unified Video & Media Source panel on Movie and Episode create/edit screens with tabbed selectors: Upload Video File, Direct MP4/WebM URL, HLS Stream, YouTube URL, Vimeo URL.
  - Unified Audio Source panel on Song create/edit screens with tabbed selectors: Upload Audio File (MP3, M4A, FLAC, WAV, AAC, OGG), Direct Audio URL.
  - Direct artwork uploads: Poster, Backdrop, Thumbnail, and Album Cover files can now be uploaded directly from content forms without leaving the page.
  - Inline subtitle track file uploads (`.vtt`, `.srt`) directly from Movie and Episode editor forms.
  - Quick submit action controls: `🚀 Publish Now` (sets status to published and saves), `📝 Save Draft` (sets status to draft and saves), and `📅 Schedule` (sets status to scheduled with release date).
  - Clear server upload limits display (`upload_max_filesize`, `post_max_size`) and live FFmpeg background processing status indicators.
- **Empty States & Usability**:
  - Friendly, high-visibility "Add Your First..." cards for empty states across Movies, Web Series, Episodes, and Songs lists.
  - Media status badges in list tables: `Ready`, `Processing`, `No Media`, and `Failed` with color-coded pills.
  - Submenu labeled "Advanced Sources" to clarify that daily publishing happens directly on content forms while maintaining route backward compatibility.
- **No-Media Safety & Protection**:
  - Protection against broken public player pages: saving content as published with 0 attached media sources automatically reverts status to draft and issues an admin flash warning.
  - Frontend detail players render a graceful "Media Coming Soon" placeholder card if public content has no active media sources.
- **Auto-Upsert Media Sources**:
  - Automatic `MediaSource` record creation and updating when saving content forms, preventing duplicate sources on repeated edits.
  - Direct HTML5 playback fallback for uploaded MP4/WebM files and external URLs when FFmpeg is not available.

### Added
- **Migration 004**: `004_create_multimedia_subscription_notification_tables.php` creating `multimedia_subscriptions`, `multimedia_notifications`, and `multimedia_notification_preferences`.
- **Content Subscriptions**:
  - Follow/Subscribe to Series, Artists, and Playlists with idempotent toggle operations.
  - Database composite unique index `(user_id, target_type, target_id)` strictly preventing duplicate subscriptions.
  - Dedicated Following directory page at `/multimedia/following` displaying user's subscribed series, artists, and playlists.
- **Release Alerts & Notification System**:
  - In-app notification inbox at `/multimedia/notifications` with unread count badge, All/Unread filter tabs, and mark-read controls.
  - New episode alerts: automatic notification fan-out to series followers when new episodes are published.
  - New artist song alerts: automatic notification fan-out to artist followers when new tracks are published.
  - Playlist update alerts: notification to playlist followers on track additions.
  - Engagement reply alerts: notifications to parent comment authors on new discussion replies (with self-reply suppression).
  - Moderation outcome alerts: notifications to review/comment authors on approval or rejection transitions.
- **Delivery Protection & Privacy**:
  - DB-level unique `dedupe_key` constraint preventing duplicate notifications on repeat edits and multi-artist releases.
  - Notification preferences: user toggles for Content Updates, Engagement Replies, and Moderation Updates.
  - Authoritative playback entitlement: notifications never include stream URLs and never bypass `MultimediaAccessService`.
  - Author privacy: zero sensitive leakage of emails, phones, or password hashes in notification payloads.
  - Personal cache isolation: private `no-store` cache controls on all notification pages and APIs.
- **Cascade Deletion**: Automatic cleanup of subscriptions when parent series, artists, or playlists are removed.

## [1.3.0] - 2026-09-05 (Phase 7 Ratings, Reviews, Comments, Reporting & Moderation)

### Added
- **Migration 003**: `003_create_multimedia_engagement_tables.php` creating `multimedia_ratings`, `multimedia_reviews`, `multimedia_review_helpful`, `multimedia_comments`, and `multimedia_reports`.
- **Star Rating Engine**: Numeric 1–5 star ratings with unique `(user_id, content_type, content_id)` database constraints, live SQL average and count aggregation, and real-time rating updates without duplicating count.
- **Audience Reviews**:
  - Full-length reviews (3 to 3,000 characters) with optional headline title and linked rating score.
  - Strict user ownership enforcement (only author can edit or delete their review).
  - Moderator status workflow (`approved`, `pending`, `rejected`, `hidden`) with configurable auto-approval policy (`review_moderation_mode`).
  - "Contains Spoiler" flag toggle with frontend spoiler warning and click-to-reveal barrier.
  - "Helpful" feedback reactions: one helpful vote per user per review with count increments and undo support.
- **Discussion Comments**:
  - Threaded comment discussion with shallow 1-level reply nesting.
  - Strict user ownership checking for edits and deletions.
- **Community Safety & Reporting**:
  - Report modal for reviews and comments with whitelisted reasons (`spam`, `harassment`, `off_topic`, `other`) and optional notes.
  - Unique report constraint preventing duplicate reports by the same user on the same target.
- **Administrative Moderation Dashboard**:
  - Dedicated moderation queue view at `/admin/page/multimedia-moderation` protected by `MultimediaPermission::MODERATE`.
  - Tabbed queue for Pending Reviews, Reported Reviews, All Comments, and Open Reports.
  - Single and bulk moderation actions: Approve, Reject, Hide, Delete, Dismiss Report, and Action Report with session CSRF protection.
- **Privacy & Safety Protections**:
  - Author formatting strictly protects user privacy, never exposing email, phone, internal ID, or password hash.
  - Graceful "Deleted User" display when an author account is removed.
  - XSS output escaping using `htmlspecialchars()` with UTF-8 encoding across all engagement views.
  - Parameterized SQL prepared statements across all engagement queries.
  - CSRF validation on all state mutations.
- **Cascade Deletion**: Complete cleanup of ratings, reviews, comments, and reports when parent content is deleted.
- **Discovery Boost Integration**: Content items with $\ge 3$ ratings and $\ge 4.0$ star average receive a modest quality boost (+1.5 pts) in Popular discovery ranking.

## [1.2.0] - 2026-09-05 (Phase 6 Discovery Engine, Related Content & Trending)

### Added
- **Centralized Discovery Engine**: Introduced `MultimediaDiscoveryService` for deterministic, explainable, privacy-safe media discovery.
- **Related Content Rails**:
  - Related Movies: Multi-factor scoring via shared genres (+10 pts), director match (+15 pts), cast overlap (+5 pts), and logarithmic views bonus.
  - Related Series: Content-type preserving recommendations based on shared genres and director relationships.
  - Related Songs: Music affinity scoring prioritizing same artist (+30 pts), same album (+25 pts), and shared genres (+15 pts).
  - Related Playlists: Discovers published playlists containing tracks by the same artist or tagged with the genre.
- **Trending Now Feed**:
  - Time-bounded rolling engagement window (default 7 days, configurable via admin settings).
  - Weighted engagement formula: plays (3.0), views (1.0), downloads (2.0), recent favorites (4.0).
  - Manipulation resistance: Counts distinct actors `COALESCE(user_id, ip_hash)` to protect rankings against repeated flooding.
  - Cold catalog smoothing: Blends top published items when window activity is sparse.
- **All-Time Popular Ranking**: Deterministic formula aggregating views, plays, and unique favorites.
- **Recently Added Feed**: Chronological catalog arrivals by publication and release dates.
- **Personalized Recommendations**:
  - "Because You Watched [Title]": Derives recommendations from meaningful recent playback ($\ge 30$s or $\ge 5\%$).
  - "Because You Liked [Title]": Leverages user bookmarks as an explicit preference signal.
  - Personalized Discovery Feed: Synthesizes preferred genres and artists with completion exclusions and diversity caps ($\le 3$ items per primary genre).
  - Cold-Start Fallback: New users without history or likes seamlessly receive a curated discovery blend with zero broken UI.
- **Dedicated Discovery Pages & Taxonomy Routes**:
  - `/multimedia/discover`: Comprehensive discovery hub with multi-shelf overview, tab filters (Trending, Popular, Recent, Genres), and format filters.
  - `/multimedia/genre/{slug}`: Browse movies, series, and songs tagged with specific taxonomy genres.
  - `/multimedia/artist/{slug}`: Artist profile featuring discography, albums, and playlists.
  - `/multimedia/album/{slug}`: Album detail with artwork, release year, and tracklist.
- **Access Safety & Zero-Leakage**: All discovery candidates are hydrated with live `MultimediaAccessService` entitlement evaluation. Restricted items display lock badges and never leak stream URLs.
- **Admin Discovery Configuration**: Added settings for global discovery toggle, trending toggle, rolling window days, and maximum rail items.

## [1.1.0] - 2026-09-05 (Phase 5 Personal Library, Playback Progress & Favorites)

### Added
- **Playback Progress Tracking**: Lightweight, throttled (15-second intervals, pause, seek, ended) progress reporting via `/multimedia/api/progress`.
- **Completion & Resume Logic**:
  - Automatically marks content completed at $\ge 90.0\%$ completion threshold or explicit player ended event.
  - Generates intelligent resume recommendation when position is $\ge 5.0$ seconds and incomplete.
  - Completed items restart from 0:00 upon subsequent playback.
- **Continue Watching Feed**: Hydrated, access-verified continue watching shelf for movies and episodes with dynamic remaining time calculation.
- **Continue Listening Shelf**: Seamless audio playback resume for individual tracks and curated playlists.
- **Series & Episode Progress**:
  - Calculates series-level completion percentage based on published episodes across all seasons.
  - Smart Next Episode resolution: seamlessly advances across seasons or terminates cleanly at the series finale.
  - Post-play next episode auto-prompt countdown overlay on video completion.
- **Personal Library & My List**:
  - Bookmarking and favorites engine with unique `(user_id, content_type, content_id)` database constraints.
  - Comprehensive frontend user dashboard at `/multimedia/library`, dedicated `/multimedia/my-list`, and `/multimedia/history`.
  - Filterable by content type (`movie`, `series`, `song`, `playlist`).
  - Clear all history and individual item deletion with user data isolation.
- **Access Safety & Zero-Leakage**: Favorites and history feeds strictly evaluate active user entitlements via `MultimediaAccessService`. Restricted items display locked state and never leak media stream URLs.
- **Automated Test Coverage**: Added `FavoriteMultimediaPhase5Test.php` with 14 tests and 95 assertions verifying migrations, models, services, guest safety, cross-user isolation, completion rules, cascade deletions, and Bangla/Unicode titles.

---

## [1.0.0] - 2026-09-05 (Phase 4 Production Release)

### Added
- **E2E Lifecycle Verification**: Full verification of plugin installation, activation, deactivation, and reactivation with complete data preservation.
- **Operational Logging**: Integrated with `FavoriteCMS\Core\Logger` for operational visibility:
  - Security audit logging for blocked SSRF and DNS rebinding attempts.
  - Informational logging for media access denials (login required, premium membership required).
  - Error and warning logging for missing local files, path traversal attempts, and unreachable remote media hosts without logging sensitive credentials or auth tokens.
- **HTTP HEAD Request Support**: Added native handling of HTTP `HEAD` requests on media streaming and download endpoints, allowing media players and CDNs to inspect headers, content lengths, and range capabilities without transmitting message bodies.
- **Cache-Control Differentiation**: Protected media streams, downloads, and subtitle tracks strictly enforce `Cache-Control: private, no-cache, no-store, must-revalidate` and `Pragma: no-cache` to prevent upstream caching of gated media chunks, while public streams send safe public cache headers.
- **DNS Rebinding Protection**: Enhanced `MediaSourceResolver::validateUrlSecurity()` to inspect DNS-resolved IP addresses against private and reserved ranges.
- **Multibyte Unicode Support**: Verified full UTF-8/Bengali query handling across Movie, Series, Song, and Search models using parameterized PDO statements and LIMIT/OFFSET pagination.
- **Comprehensive Test Suite**: Added `FavoriteMultimediaPhase4Test.php` covering lifecycle idempotency, HEAD requests, Cache-Control protection, SSRF edge cases, and graceful missing media handling.

### Changed
- Cleaned all `console.log` invocations from frontend media player scripts (`multimedia-player.js`, `multimedia-audio.js`), replacing them with silent promise rejection handlers to keep browser developer consoles clean.
- Made `MultimediaAccessService::findContentModel()` public for cross-service inspection.

---

## [0.3.0] - 2026-09-05 (Phase 3 Content Workflow & Frontend Polish)

### Added
- Content publishing workflows: draft, published, and unlisted visibility states.
- Enhanced frontend catalog hub, movie detail, series episodes list, and continuous audio playlist player.
- Dedicated subtitle track delivery engine (`MediaDeliveryService::deliverSubtitle`).
- Granular download permission policy (`multimedia.enable_downloads`, content policy, and source policy).
- Automated test coverage in `FavoriteMultimediaPhase3Test.php`.

---

## [0.2.0] - 2026-09-05 (Phase 2 Integration Audit & Production Stabilization)

### Added
- Ecosystem integrations: `FavoriteDigitalAdapter` (membership pass entitlement) and `FavoritePayAdapter` (checkout orchestration).
- HTTP 206 Partial Content (Byte range) streaming engine with seeking support.
- Centralized 3-tier access control service (`MultimediaAccessService`): `PUBLIC`, `LOGIN`, `PREMIUM`.
- Access inheritance: Series &rarr; Season &rarr; Episode with explicit episode overrides.
- Automated test coverage in `FavoriteMultimediaPhase2Test.php`.

---

## [0.1.0] - 2026-09-05 (Phase 1 Initial Architecture & Schema)

### Added
- Core multimedia database schema (14 tables with indexes for slugs, statuses, foreign keys, and ordering).
- Models: `Movie`, `Series`, `Season`, `Episode`, `Song`, `Playlist`, `PlaylistItem`, `Genre`, `Artist`, `Album`, `MediaSource`, `Subtitle`, `AnalyticsEvent`.
- URL-first architecture: direct video/audio, HLS streaming manifests (`.m3u8`), and third-party embeds (YouTube, Vimeo, Dailymotion, SoundCloud).
- Rigorous SSRF protection blocking loopback, private RFC 1918 subnets, IPv6 loopback, and cloud metadata services.
- Admin dashboard, media management interfaces, and initial automated tests in `FavoriteMultimediaTest.php`.


<?php
/**
 * Favorite Multimedia — Episode Player View
 */
$playableSources = $playableSources ?? [];
$defaultSource = $defaultSource ?? ($sources[0] ?? null);

// Normalize sources array
$sourcesList = !empty($playableSources) ? $playableSources : array_map(function($s) {
    $embedInfo = \FavoriteCMS\Multimedia\Services\MediaSourceResolver::detectEmbedService($s->url_or_path);
    $pType = ($embedInfo !== null || $s->source_type === 'embed') ? 'embed' : (($s->source_type === 'hls') ? 'hls' : 'video');
    $playUrl = $embedInfo ? $embedInfo['embed_url'] : (($pType === 'embed') ? $s->url_or_path : "/multimedia/stream/{$s->id}");
    return [
        'id'                => (int)$s->id,
        'label'             => $s->label ?: 'Stream',
        'source_type'       => $s->source_type,
        'player_type'       => $pType,
        'url'               => $playUrl,
        'stream_url'        => "/multimedia/stream/{$s->id}",
        'mime_type'         => $s->mime_type ?: 'video/mp4',
        'is_default'        => !empty($s->is_default),
        'can_auto_failover' => ($pType !== 'embed'),
    ];
}, $sources);

$defaultItem = is_array($defaultSource) ? $defaultSource : ($sourcesList[0] ?? null);
$isHls = ($defaultItem && ($defaultItem['player_type'] ?? '') === 'hls');
$isEmbed = ($defaultItem && ($defaultItem['player_type'] ?? '') === 'embed');
$playableUrl = $defaultItem['url'] ?? '';
$playableMime = $defaultItem['mime_type'] ?? 'video/mp4';
$playableId = $defaultItem['id'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <?php if (!empty($metaDescription)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($metaDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-player.css">
    <link rel="stylesheet" href="/plugins/favorite-multimedia/assets/css/multimedia-frontend.css">
</head>
<body style="background: #0f172a; color: #f8fafc; margin: 0; padding: 0;">

    <div class="fav-mm-container">
        <header class="fav-mm-header" style="border-color: #1e293b;">
            <div>
                <?php if ($series): ?>
                    <a href="/series/<?php echo htmlspecialchars($series->slug ?? '', ENT_QUOTES, 'UTF-8'); ?>" style="color: #94a3b8; text-decoration: none; font-size: 14px;">&larr; <?php echo htmlspecialchars($series->title ?? 'Series', ENT_QUOTES, 'UTF-8'); ?></a>
                <?php else: ?>
                    <a href="/series" style="color: #94a3b8; text-decoration: none; font-size: 14px;">&larr; Web Series</a>
                <?php endif; ?>
                <h1 style="color: #fff; font-size: 24px; margin: 6px 0 0 0;">
                    <?php echo htmlspecialchars($season->title ?? 'Season', ENT_QUOTES, 'UTF-8'); ?> • Ep <?php echo (int)($episode->episode_number ?? 1); ?>: <?php echo htmlspecialchars($episode->title ?? '', ENT_QUOTES, 'UTF-8'); ?>
                </h1>
            </div>
            <nav class="fav-mm-nav">
                <a href="/series" class="fav-mm-nav-link">Series</a>
            </nav>
        </header>

        <!-- Resume Prompt Banner -->
        <?php if (!empty($progress['should_resume'])): ?>
            <div class="fmm-resume-banner" id="fmm-resume-prompt" style="max-width: 960px; margin: 0 auto 20px auto;">
                <div class="fmm-resume-info">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
                    <span>You were watching this episode. Resume from <strong><?= htmlspecialchars($progress['formatted_position'] ?? '0:00') ?></strong> (<?= round($progress['percentage'] ?? 0) ?>%)?</span>
                </div>
                <div class="fmm-resume-actions">
                    <button type="button" class="fmm-btn fmm-btn-primary" id="fmm-resume-accept-btn" style="padding: 6px 14px; font-size: 13px;">Resume</button>
                    <button type="button" class="fmm-btn fmm-btn-secondary" id="fmm-resume-start-over-btn" style="padding: 6px 14px; font-size: 13px;">Start Over</button>
                </div>
            </div>
        <?php endif; ?>

        <!-- Player Stage -->
        <div style="max-width: 960px; margin: 0 auto 32px auto;">
            <div class="fav-video-wrapper" 
                 data-content-type="episode" 
                 data-content-id="<?php echo (int)$episode->id; ?>" 
                 data-auto-play-next="<?php echo htmlspecialchars(\FavoriteCMS\Models\Setting::get('multimedia', 'auto_play_next', 'yes'), ENT_QUOTES, 'UTF-8'); ?>"
                 data-auto-next-countdown="<?php echo (int)\FavoriteCMS\Models\Setting::get('multimedia', 'auto_next_countdown', 5); ?>"
                 data-resume-position="<?php echo (!empty($progress['should_resume'])) ? (float)$progress['position'] : 0; ?>"
                 <?php if (!empty($nextEpisode)): ?>
                     data-next-episode-id="<?php echo (int)$nextEpisode->id; ?>"
                     data-next-episode-title="<?php echo htmlspecialchars($nextEpisode->title, ENT_QUOTES, 'UTF-8'); ?>"
                     data-next-episode-url="/episode/<?php echo htmlspecialchars($nextEpisode->slug, ENT_QUOTES, 'UTF-8'); ?>"
                 <?php endif; ?>
                 data-sources='<?php echo htmlspecialchars(json_encode($sourcesList), ENT_QUOTES, 'UTF-8'); ?>'
                 <?php if ($isHls && $accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW): ?>data-hls-src="<?php echo htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?>>
                <?php if ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::ALLOW): ?>
                    <?php if (empty($sourcesList)): ?>
                        <div class="fav-restriction-card" style="background: rgba(15, 23, 42, 0.95); border: 1px dashed #334155; padding: 48px 24px; text-align: center;">
                            <div class="fav-restriction-icon" style="font-size: 40px; margin-bottom: 12px;">🎞️</div>
                            <h2 class="fav-restriction-title" style="font-size: 20px; color: #f8fafc; margin-bottom: 8px;">Episode Stream Coming Soon</h2>
                            <p class="fav-restriction-msg" style="color: #94a3b8; font-size: 14px; max-width: 440px; margin: 0 auto;">This episode is scheduled or currently being prepared. Video stream will be available soon.</p>
                        </div>
                    <?php else: ?>
                        <!-- Universal Player Host: Iframe Element (for Embed, YouTube, Vimeo) -->
                        <iframe src="<?php echo $isEmbed ? htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8') : 'about:blank'; ?>" class="fav-embed-element" style="<?php echo $isEmbed ? '' : 'display:none;'; ?>" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen sandbox="allow-scripts allow-same-origin allow-presentation allow-fullscreen"></iframe>

                        <!-- Universal Player Host: Video Element (for Direct Video & HLS) -->
                        <video class="fav-video-element" poster="<?php echo htmlspecialchars(($episode->thumbnail ?: ($series?->backdrop ?: ($series?->poster ?: ''))) ?? '', ENT_QUOTES, 'UTF-8'); ?>" preload="metadata" playsinline style="<?php echo $isEmbed ? 'display:none;' : ''; ?>">
                            <?php if (!$isHls && !$isEmbed && $playableUrl): ?>
                                <source src="<?php echo htmlspecialchars($playableUrl, ENT_QUOTES, 'UTF-8'); ?>" type="<?php echo htmlspecialchars($playableMime, ENT_QUOTES, 'UTF-8'); ?>">
                            <?php endif; ?>
                            <?php foreach ($subtitles as $sub): ?>
                                <track kind="subtitles" label="<?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?>" srclang="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>" src="/multimedia/subtitle/<?php echo $sub->id; ?>" <?php echo $sub->is_default ? 'default' : ''; ?>>
                            <?php endforeach; ?>
                        </video>

                        <!-- Controls -->
                        <div class="fav-player-controls" style="<?php echo $isEmbed ? 'display:none;' : ''; ?>">
                            <div class="fav-progress-bar-container">
                                <div class="fav-progress-filled">
                                    <span class="fav-progress-scrubber"></span>
                                </div>
                            </div>
                            <div class="fav-controls-row">
                                <div class="fav-controls-left">
                                    <button type="button" class="fav-btn-control fav-btn-play" aria-label="Play">
                                        <span class="fav-icon-play">&#9654;</span>
                                        <span class="fav-icon-pause" style="display:none;">&#10074;&#10074;</span>
                                    </button>
                                    <div class="fav-volume-wrapper">
                                        <button type="button" class="fav-btn-control fav-btn-volume">&#128266;</button>
                                        <input type="range" class="fav-volume-slider" min="0" max="1" step="0.05" value="1">
                                    </div>
                                    <div class="fav-time-display">0:00 / 0:00</div>
                                </div>
                                <div class="fav-controls-right">
                                    <?php if (count($sourcesList) > 1): ?>
                                        <select class="fav-control-select fav-source-select" title="Switch Source" aria-label="Switch Playback Source">
                                            <?php foreach ($sourcesList as $s): ?>
                                                <option value="<?php echo (int)$s['id']; ?>" <?php echo !empty($s['is_default']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($s['label'], ENT_QUOTES, 'UTF-8'); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>

                                    <?php if (!empty($subtitles)): ?>
                                        <select class="fav-control-select fav-subtitle-select">
                                            <option value="off">CC Off</option>
                                            <?php foreach ($subtitles as $sub): ?>
                                                <option value="<?php echo htmlspecialchars($sub->language, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($sub->label, ENT_QUOTES, 'UTF-8'); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php endif; ?>

                                    <select class="fav-control-select fav-speed-select">
                                        <option value="0.75">0.75x</option>
                                        <option value="1" selected>1x</option>
                                        <option value="1.25">1.25x</option>
                                        <option value="1.5">1.5x</option>
                                        <option value="2">2x</option>
                                    </select>

                                    <?php if (!empty($downloadInfo['allowed']) && !empty($downloadInfo['download_url'])): ?>
                                        <?php $dlOptions = $downloadInfo['options'] ?? []; ?>
                                        <?php if (count($dlOptions) <= 1): ?>
                                            <a href="<?php echo htmlspecialchars($downloadInfo['download_url'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-btn-download">
                                                &#8595; Download
                                            </a>
                                        <?php else: ?>
                                            <div class="fav-download-dropdown">
                                                <button type="button" class="fav-btn-download" onclick="this.nextElementSibling.classList.toggle('fav-show'); event.stopPropagation();" title="Download Options">
                                                    &#8595; Download
                                                </button>
                                                <div class="fav-download-dropdown-menu" style="bottom: 100%; top: auto; margin-bottom: 8px; margin-top: 0;">
                                                    <div style="padding: 8px 12px; background: #1e293b; border-bottom: 1px solid #334155; font-size: 11px; font-weight: 700; color: #94a3b8;">Download Options (<?= count($dlOptions) ?>)</div>
                                                    <?php foreach ($dlOptions as $opt): ?>
                                                        <a href="<?php echo htmlspecialchars($opt['url'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-download-item">
                                                            <div class="fav-download-item-title"><?php echo htmlspecialchars($opt['display_title'] ?? $opt['label'], ENT_QUOTES, 'UTF-8'); ?></div>
                                                            <?php if (!empty($opt['meta'])): ?><div class="fav-download-item-meta"><?php echo htmlspecialchars($opt['meta'], ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
                                                        </a>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <button type="button" class="fav-btn-control fav-btn-fullscreen">&#x26F6;</button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::LOGIN_REQUIRED): ?>
                    <div class="fav-restriction-card">
                        <div class="fav-restriction-icon">🔒</div>
                        <h2 class="fav-restriction-title">Member Login Required</h2>
                        <p class="fav-restriction-msg">Please sign in to stream this episode.</p>
                        <a href="/admin/login?redirect=<?php echo urlencode('/episode/' . $episode->slug); ?>" class="fav-btn-cta">Sign In</a>
                    </div>
                <?php elseif ($accessState === \FavoriteCMS\Multimedia\Services\MultimediaAccessService::PREMIUM_REQUIRED): ?>
                    <div class="fav-restriction-card">
                        <div class="fav-restriction-icon">⭐</div>
                        <h2 class="fav-restriction-title">Premium Access Required</h2>
                        <p class="fav-restriction-msg">This episode is part of a premium series. Upgrade via Favorite Digital to enjoy unlimited access.</p>
                        <a href="<?php echo \FavoriteCMS\Multimedia\Integrations\FavoriteDigitalAdapter::getSubscriptionUrl(); ?>" class="fav-btn-cta">Unlock with Premium</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Download Button -->
            <?php if (!empty($downloadInfo['allowed']) && !empty($downloadInfo['download_url'])): ?>
                <?php $dlOptions = $downloadInfo['options'] ?? []; ?>
                <div style="margin-top: 12px; display: flex; justify-content: flex-end; position: relative;">
                    <?php if (count($dlOptions) <= 1): ?>
                        <a href="<?php echo htmlspecialchars($downloadInfo['download_url'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-btn-download" style="padding: 8px 16px; font-size: 13px;">
                            &#8595; Download Episode<?php if (!empty($downloadInfo['download_label'])): ?> (<?php echo htmlspecialchars($downloadInfo['download_label'], ENT_QUOTES, 'UTF-8'); ?>)<?php elseif ($defaultSource && !empty($defaultSource->label)): ?> (<?php echo htmlspecialchars($defaultSource->label, ENT_QUOTES, 'UTF-8'); ?>)<?php else: ?> File<?php endif; ?>
                        </a>
                    <?php else: ?>
                        <div class="fav-download-dropdown">
                            <button type="button" class="fav-btn-download fav-download-dropdown-btn" onclick="this.nextElementSibling.classList.toggle('fav-show'); event.stopPropagation();" style="padding: 8px 16px; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
                                <span>&#8595; Download</span>
                                <span style="font-size: 10px;">▼</span>
                            </button>
                            <div class="fav-download-dropdown-menu">
                                <div style="padding: 8px 12px; background: #1e293b; border-bottom: 1px solid #334155; font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase;">Download Options (<?= count($dlOptions) ?>)</div>
                                <?php foreach ($dlOptions as $opt): ?>
                                    <a href="<?php echo htmlspecialchars($opt['url'], ENT_QUOTES, 'UTF-8'); ?>" class="fav-download-item">
                                        <div class="fav-download-item-title"><?php echo htmlspecialchars($opt['display_title'] ?? $opt['label'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        <?php if (!empty($opt['meta'])): ?>
                                            <div class="fav-download-item-meta"><?php echo htmlspecialchars($opt['meta'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        <?php endif; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Episode Details -->
        <div style="max-width: 960px; margin: 0 auto; background: #1e293b; border-radius: 8px; padding: 24px;">
            <div style="display: flex; gap: 12px; align-items: center; margin-bottom: 12px; flex-wrap: wrap;">
                <span class="fav-badge fav-badge-<?php echo strtolower($episode->getResolvedAccessMode()); ?>"><?php echo strtoupper($episode->getResolvedAccessMode()); ?></span>
                <?php if ($episode->duration): ?>
                    <span style="color: #94a3b8; font-size: 13px;"><?php echo round($episode->duration / 60); ?> minutes</span>
                <?php endif; ?>

                <?php if (!empty($nextEpisode)): ?>
                    <a href="/episode/<?php echo htmlspecialchars($nextEpisode->slug, ENT_QUOTES, 'UTF-8'); ?>" class="fmm-btn fmm-btn-primary" style="margin-left: auto; font-size: 13px; padding: 6px 14px;">
                        Next: Ep <?php echo (int)$nextEpisode->episode_number; ?> &rarr;
                    </a>
                <?php endif; ?>

                <?php if (!empty($user)): ?>
                    <button type="button" class="fav-btn-favorite <?= !empty($isFavorite) ? 'active' : '' ?>" data-fmm-fav-toggle data-content-type="episode" data-content-id="<?= (int)$episode->id ?>" style="<?= empty($nextEpisode) ? 'margin-left: auto;' : '' ?>">
                        <span class="fav-icon-star">★</span>
                        <span class="fav-btn-label"><?= !empty($isFavorite) ? 'In My List' : 'Add to My List' ?></span>
                    </button>
                <?php endif; ?>
            </div>
            <?php if (!empty($episode->description)): ?>
                <div style="line-height: 1.6; color: #cbd5e1;">
                    <?php echo nl2br(htmlspecialchars($episode->description, ENT_QUOTES, 'UTF-8')); ?>
                </div>
            <?php endif; ?>

            <?php
            $contentType = 'episode';
            $contentId = (int)$episode->id;
            include __DIR__ . '/_engagement_section.php';
            ?>
        </div>
    </div>

    <script src="/plugins/favorite-multimedia/assets/js/multimedia-player.js"></script>
</body>
</html>


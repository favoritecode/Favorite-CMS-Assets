/**
 * Favorite Multimedia — Dynamic Appearance Mode Controller
 * Handles Auto, Light, and Dark modes scoped to Multimedia content.
 * Does NOT recolor or modify the active theme header, footer, or global shell.
 */
(function (window, document) {
    'use strict';

    const STORAGE_KEY = 'fm_appearance_mode';

    function getLocalPreference() {
        try {
            const val = localStorage.getItem(STORAGE_KEY);
            if (val && (val === 'auto' || val === 'light' || val === 'dark')) {
                return val;
            }
        } catch (e) {}

        const root = document.querySelector('[data-fm-configured-mode]');
        if (root) {
            const val = root.getAttribute('data-fm-configured-mode');
            if (val === 'auto' || val === 'light' || val === 'dark') {
                return val;
            }
        }

        return 'auto';
    }

    function resolveSystemScheme() {
        // 1. Check if active CMS theme declared theme mode on root
        const docTheme = document.documentElement.getAttribute('data-theme') ||
                         document.documentElement.getAttribute('data-color-scheme') ||
                         (document.body ? document.body.getAttribute('data-theme') : null);
        if (docTheme === 'dark') return 'dark';
        if (docTheme === 'light') return 'light';

        // 2. Check browser prefers-color-scheme
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }

        // 3. Default to light
        return 'light';
    }

    function applyEffectiveMode(forcedPref) {
        const pref = forcedPref || getLocalPreference();
        const effective = (pref === 'auto') ? resolveSystemScheme() : pref;

        // Scope to multimedia containers only. Never touch .site-header or .site-footer.
        const containers = document.querySelectorAll(
            '.fm-multimedia-root, .fm-container, .fav-mm-container, .fm-membership-wrap, [data-fm-color-mode], .fm-expanded-player, .fm-audio-queue-drawer, .fm-mini-player'
        );

        containers.forEach(el => {
            el.setAttribute('data-fm-color-mode', effective);
            el.setAttribute('data-fm-configured-mode', pref);
        });

        // Set cookie so server-side render matches on subsequent navigations
        try {
            document.cookie = 'fm_color_mode=' + effective + ';path=/;max-age=31536000;SameSite=Lax';
        } catch (e) {}

        // Dispatch custom event for media players and custom components
        window.dispatchEvent(new CustomEvent('fm:appearance:changed', {
            detail: { mode: effective, configured: pref }
        }));
    }

    // Initialize immediately
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => applyEffectiveMode());
    } else {
        applyEffectiveMode();
    }

    // Live auto-switch when system color scheme changes and mode is AUTO
    if (window.matchMedia) {
        const mql = window.matchMedia('(prefers-color-scheme: dark)');
        const handleChange = () => {
            if (getLocalPreference() === 'auto') {
                applyEffectiveMode('auto');
            }
        };

        if (typeof mql.addEventListener === 'function') {
            mql.addEventListener('change', handleChange);
        } else if (typeof mql.addListener === 'function') {
            mql.addListener(handleChange);
        }
    }

    window.FavoriteMultimediaAppearance = {
        getPreference: getLocalPreference,
        setPreference: function (mode) {
            if (!['auto', 'light', 'dark'].includes(mode)) {
                return;
            }
            try {
                localStorage.setItem(STORAGE_KEY, mode);
            } catch (e) {}

            try {
                fetch('/api/multimedia/appearance', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: mode })
                }).catch(() => {});
            } catch (e) {}

            applyEffectiveMode(mode);
        },
        resolveEffective: function () {
            const p = getLocalPreference();
            return p === 'auto' ? resolveSystemScheme() : p;
        }
    };
})(window, document);


# Universal Platform Examples

These are safe templates, not automatically activated records. Import packages are created disabled/draft so an administrator can review them before enabling.

- `text-pipeline-handler.json` — Dynamic Handler pipeline, no source edit.
- `qr-operation.json` — Dynamic Operation backed by the shared QR capability.
- `image-resize-operation.json` — GD image capability example.
- `http-operation.json` — HTTP operation with server-side secret binding.
- `dynamic-php-file-output.txt` — isolated Dynamic PHP workspace example.

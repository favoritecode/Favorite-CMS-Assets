<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Repositories;

use FavoriteCMS\Core\Database;
use FavoriteCMS\Tools\Models\DynamicHandler;

final class DynamicHandlerRepository
{
    public function __construct(private Database $db)
    {
        if (method_exists($this->db, 'registerPrefixableTables')) {
            $this->db->registerPrefixableTables(['favorite_web_tool_dynamic_handlers']);
        }
    }

    /** @return DynamicHandler[] */
    public function all(bool $activeOnly = false): array
    {
        $sql = "SELECT * FROM `favorite_web_tool_dynamic_handlers`";
        $params = [];
        if ($activeOnly) {
            $sql .= " WHERE `status` = ?";
            $params[] = 'active';
        }
        $sql .= " ORDER BY `name` ASC, `id` ASC";
        try {
            $rows = $this->db->select($sql, $params);
        } catch (\Throwable) {
            return [];
        }
        return array_map(fn($row) => DynamicHandler::fromArray($row), $rows);
    }

    public function findById(int $id): ?DynamicHandler
    {
        try {
            $row = $this->db->selectOne("SELECT * FROM `favorite_web_tool_dynamic_handlers` WHERE `id` = ? LIMIT 1", [$id]);
        } catch (\Throwable) {
            return null;
        }
        return $row ? DynamicHandler::fromArray($row) : null;
    }

    public function findByHandlerId(string $handlerId): ?DynamicHandler
    {
        try {
            $row = $this->db->selectOne("SELECT * FROM `favorite_web_tool_dynamic_handlers` WHERE `handler_id` = ? LIMIT 1", [$handlerId]);
        } catch (\Throwable) {
            return null;
        }
        return $row ? DynamicHandler::fromArray($row) : null;
    }

    public function create(array $data): DynamicHandler
    {
        $definition = is_array($data['definition'] ?? null)
            ? json_encode($data['definition'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            : (string)($data['definition'] ?? '{}');

        $this->db->execute(
            "INSERT INTO `favorite_web_tool_dynamic_handlers` (`handler_id`, `name`, `description`, `status`, `definition`) VALUES (?, ?, ?, ?, ?)",
            [
                (string)$data['handler_id'],
                (string)$data['name'],
                (string)($data['description'] ?? ''),
                strtolower((string)($data['status'] ?? 'active')),
                $definition,
            ]
        );

        $id = (int)$this->db->lastInsertId();
        return $this->findById($id) ?? DynamicHandler::fromArray(array_merge($data, ['id' => $id]));
    }

    public function update(int $id, array $data): bool
    {
        $fields = [];
        $params = [];
        foreach (['handler_id', 'name', 'description', 'status', 'definition'] as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            $fields[] = "`{$field}` = ?";
            $value = $data[$field];
            if ($field === 'definition' && is_array($value)) {
                $value = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            }
            if ($field === 'status') {
                $value = strtolower((string)$value);
            }
            $params[] = $value;
        }
        if ($fields === []) {
            return false;
        }
        $params[] = $id;
        return $this->db->execute("UPDATE `favorite_web_tool_dynamic_handlers` SET " . implode(', ', $fields) . " WHERE `id` = ?", $params);
    }

    public function delete(int $id): bool
    {
        return $this->db->execute("DELETE FROM `favorite_web_tool_dynamic_handlers` WHERE `id` = ?", [$id]);
    }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Repositories;

use FavoriteCMS\Core\Database;
use FavoriteCMS\Tools\Models\SecretRecord;
use Throwable;

final class SecretRepository
{
    public function __construct(private Database $db) { if (method_exists($db,'registerPrefixableTables')) $db->registerPrefixableTables(['favorite_web_tool_secrets']); }
    /** @return SecretRecord[] */ public function all(): array { try { return array_map(fn($r)=>SecretRecord::fromRow($r), $this->db->select("SELECT * FROM `favorite_web_tool_secrets` ORDER BY label ASC")); } catch (Throwable) { return []; } }
    public function find(int $id): ?SecretRecord { try { $r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_secrets` WHERE id=?",[$id]); return $r?SecretRecord::fromRow($r):null; } catch(Throwable){return null;} }
    public function findByKey(string $key): ?SecretRecord { try { $r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_secrets` WHERE secret_key=?",[$key]); return $r?SecretRecord::fromRow($r):null; } catch(Throwable){return null;} }
    public function save(array $data, int $id=0): SecretRecord {
        $scope=json_encode($data['scope']??[],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        if($id>0){$this->db->execute("UPDATE `favorite_web_tool_secrets` SET secret_key=?,label=?,encrypted_value=?,scope=?,status=? WHERE id=?",[$data['secret_key'],$data['label'],$data['encrypted_value'],$scope,$data['status']??'active',$id]); return $this->find($id)??new SecretRecord($data);}
        $this->db->execute("INSERT INTO `favorite_web_tool_secrets` (`secret_key`,`label`,`encrypted_value`,`scope`,`status`) VALUES (?,?,?,?,?)",[$data['secret_key'],$data['label'],$data['encrypted_value'],$scope,$data['status']??'active']);
        return $this->find((int)$this->db->lastInsertId())??new SecretRecord($data);
    }
    public function delete(int $id): bool { try{return(bool)$this->db->execute("DELETE FROM `favorite_web_tool_secrets` WHERE id=?",[$id]);}catch(Throwable){return false;} }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Repositories;

use FavoriteCMS\Core\Database;
use FavoriteCMS\Tools\Models\DynamicOperation;
use Throwable;

final class DynamicOperationRepository
{
    public function __construct(private Database $db)
    {
        if (method_exists($db, 'registerPrefixableTables')) {
            $db->registerPrefixableTables(['favorite_web_tool_dynamic_operations','favorite_web_tool_operation_revisions']);
        }
    }

    /** @return DynamicOperation[] */
    public function all(bool $activeOnly = false): array
    {
        try {
            $where = $activeOnly ? " WHERE status = 'active'" : '';
            return array_map(fn($r) => DynamicOperation::fromRow($r), $this->db->select("SELECT * FROM `favorite_web_tool_dynamic_operations`{$where} ORDER BY name ASC"));
        } catch (Throwable) { return []; }
    }

    public function find(int $id): ?DynamicOperation
    {
        try { $r = $this->db->selectOne("SELECT * FROM `favorite_web_tool_dynamic_operations` WHERE id = ?", [$id]); return $r ? DynamicOperation::fromRow($r) : null; } catch (Throwable) { return null; }
    }

    public function findByOperationId(string $operationId): ?DynamicOperation
    {
        try { $r = $this->db->selectOne("SELECT * FROM `favorite_web_tool_dynamic_operations` WHERE operation_id = ?", [$operationId]); return $r ? DynamicOperation::fromRow($r) : null; } catch (Throwable) { return null; }
    }

    public function create(array $data): DynamicOperation
    {
        $this->db->execute("INSERT INTO `favorite_web_tool_dynamic_operations` (`operation_id`,`name`,`description`,`executor_type`,`version`,`status`,`parameter_schema`,`configuration`) VALUES (?,?,?,?,?,?,?,?)", [
            $data['operation_id'], $data['name'], $data['description'] ?? '', strtoupper((string)($data['executor_type'] ?? 'BUILTIN')), (int)($data['version'] ?? 1), $data['status'] ?? 'active',
            json_encode($data['parameter_schema'] ?? [], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE), json_encode($data['configuration'] ?? [], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
        ]);
        $op = $this->find((int)$this->db->lastInsertId()) ?? new DynamicOperation($data);
        $this->snapshot($op);
        return $op;
    }

    public function update(int $id, array $data): bool
    {
        $current = $this->find($id);
        if (!$current) return false;
        $version = max($current->version + 1, (int)($data['version'] ?? 0));
        $ok = (bool)$this->db->execute("UPDATE `favorite_web_tool_dynamic_operations` SET `operation_id`=?,`name`=?,`description`=?,`executor_type`=?,`version`=?,`status`=?,`parameter_schema`=?,`configuration`=? WHERE id=?", [
            $data['operation_id'] ?? $current->operation_id, $data['name'] ?? $current->name, $data['description'] ?? $current->description,
            strtoupper((string)($data['executor_type'] ?? $current->executor_type)), $version, $data['status'] ?? $current->status,
            json_encode($data['parameter_schema'] ?? $current->parameter_schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            json_encode($data['configuration'] ?? $current->configuration, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE), $id,
        ]);
        if ($ok && ($op = $this->find($id))) $this->snapshot($op);
        return $ok;
    }

    public function delete(int $id): bool { try { return (bool)$this->db->execute("DELETE FROM `favorite_web_tool_dynamic_operations` WHERE id = ?", [$id]); } catch (Throwable) { return false; } }

    public function seedDefaults(): void
    {
        $defaults = [
            ['trim','Trim','BUILTIN',['capability'=>'transform','operation'=>'trim']],
            ['lowercase','Lowercase','BUILTIN',['capability'=>'transform','operation'=>'lowercase']],
            ['uppercase','Uppercase','BUILTIN',['capability'=>'transform','operation'=>'uppercase']],
            ['slugify','Slugify','BUILTIN',['capability'=>'transform','operation'=>'slugify']],
            ['csv_parse','CSV Parse','BUILTIN',['capability'=>'csv_parse']],
            ['csv_create','CSV Create','BUILTIN',['capability'=>'csv_create']],
            ['qr_generate','QR Generate','BUILTIN',['capability'=>'qr_generate']],
            ['file_output','Secure File Output','BUILTIN',['capability'=>'file_output']],
            ['zip_create','ZIP Create','BUILTIN',['capability'=>'zip_create']],
            ['image_resize','Image Resize/Convert','BUILTIN',['capability'=>'image_resize']],
        ];
        foreach ($defaults as [$id,$name,$type,$config]) {
            if (!$this->findByOperationId($id)) {
                try { $this->create(['operation_id'=>$id,'name'=>$name,'description'=>'Built-in reusable capability operation.','executor_type'=>$type,'status'=>'active','configuration'=>$config]); } catch (Throwable) {}
            }
        }
    }

    private function snapshot(DynamicOperation $op): void
    {
        if (!$op->id) return;
        try {
            $this->db->execute("INSERT INTO `favorite_web_tool_operation_revisions` (`operation_id`,`version`,`snapshot`) VALUES (?,?,?)", [$op->id,$op->version,json_encode($op->toArray(), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)]);
        } catch (Throwable) {}
    }
}

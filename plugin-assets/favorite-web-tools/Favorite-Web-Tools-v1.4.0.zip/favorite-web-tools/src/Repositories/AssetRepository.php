<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Repositories;
use FavoriteCMS\Core\Database; use FavoriteCMS\Tools\Models\AssetRecord; use Throwable;
final class AssetRepository {
 public function __construct(private Database $db){if(method_exists($db,'registerPrefixableTables'))$db->registerPrefixableTables(['favorite_web_tool_assets']);}
 /** @return AssetRecord[] */ public function all(bool $activeOnly=false):array{try{$w=$activeOnly?" WHERE status='active'":'';return array_map(fn($r)=>AssetRecord::fromRow($r),$this->db->select("SELECT * FROM `favorite_web_tool_assets`{$w} ORDER BY load_order,name"));}catch(Throwable){return[];}}
 public function find(int $id):?AssetRecord{try{$r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_assets` WHERE id=?",[$id]);return$r?AssetRecord::fromRow($r):null;}catch(Throwable){return null;}}
 public function findByKey(string $key):?AssetRecord{try{$r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_assets` WHERE asset_key=? AND status='active'",[$key]);return$r?AssetRecord::fromRow($r):null;}catch(Throwable){return null;}}
 public function save(array $d,int $id=0):AssetRecord{$cfg=json_encode($d['configuration']??[],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);$p=[$d['asset_key'],$d['name'],$d['asset_type']??'JS',$d['source_type']??'CDN',$d['url']??'',$d['integrity']??'',$d['crossorigin']??'',(int)($d['load_order']??100),$cfg,$d['status']??'active'];if($id>0){$p[]=$id;$this->db->execute("UPDATE `favorite_web_tool_assets` SET asset_key=?,name=?,asset_type=?,source_type=?,url=?,integrity=?,crossorigin=?,load_order=?,configuration=?,status=? WHERE id=?",$p);return$this->find($id)??new AssetRecord($d);} $this->db->execute("INSERT INTO `favorite_web_tool_assets` (`asset_key`,`name`,`asset_type`,`source_type`,`url`,`integrity`,`crossorigin`,`load_order`,`configuration`,`status`) VALUES (?,?,?,?,?,?,?,?,?,?)",$p);return$this->find((int)$this->db->lastInsertId())??new AssetRecord($d);}
 public function delete(int $id):bool{try{return(bool)$this->db->execute("DELETE FROM `favorite_web_tool_assets` WHERE id=?",[$id]);}catch(Throwable){return false;}}
}

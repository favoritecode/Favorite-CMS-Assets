<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Repositories;
use FavoriteCMS\Core\Database; use Throwable;
final class ExecutionLogRepository {
 public function __construct(private Database $db){if(method_exists($db,'registerPrefixableTables'))$db->registerPrefixableTables(['favorite_web_tool_execution_logs']);}
 public function log(array $d):void{try{$this->db->execute("INSERT INTO `favorite_web_tool_execution_logs` (`tool_id`,`tool_slug`,`engine`,`status`,`duration_ms`,`user_id`,`is_anonymous`,`error_code`,`file_count`) VALUES (?,?,?,?,?,?,?,?,?)",[$d['tool_id']??null,$d['tool_slug']??null,$d['engine']??null,$d['status']??'unknown',$d['duration_ms']??null,$d['user_id']??null,!empty($d['is_anonymous'])?1:0,$d['error_code']??null,(int)($d['file_count']??0)]);}catch(Throwable){}}
 public function recent(int $limit=200):array{try{$limit=max(1,min(1000,$limit));return $this->db->select("SELECT * FROM `favorite_web_tool_execution_logs` ORDER BY id DESC LIMIT {$limit}");}catch(Throwable){return[];}}
 public function cleanup(int $days=30):int{try{return(int)$this->db->execute("DELETE FROM `favorite_web_tool_execution_logs` WHERE created_at < ?",[date('Y-m-d H:i:s',time()-max(1,$days)*86400)]);}catch(Throwable){return 0;}}
}

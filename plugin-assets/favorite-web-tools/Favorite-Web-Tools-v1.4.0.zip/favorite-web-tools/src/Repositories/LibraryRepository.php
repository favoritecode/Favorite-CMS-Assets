<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Repositories;
use FavoriteCMS\Core\Database; use FavoriteCMS\Tools\Models\LibraryRecord; use Throwable;
final class LibraryRepository {
 public function __construct(private Database $db){if(method_exists($db,'registerPrefixableTables'))$db->registerPrefixableTables(['favorite_web_tool_libraries']);}
 /** @return LibraryRecord[] */ public function all():array{try{return array_map(fn($r)=>LibraryRecord::fromRow($r),$this->db->select("SELECT * FROM `favorite_web_tool_libraries` ORDER BY library_type,name"));}catch(Throwable){return[];}}
 public function find(int $id):?LibraryRecord{try{$r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_libraries` WHERE id=?",[$id]);return$r?LibraryRecord::fromRow($r):null;}catch(Throwable){return null;}}
 public function findByKey(string $key):?LibraryRecord{try{$r=$this->db->selectOne("SELECT * FROM `favorite_web_tool_libraries` WHERE library_key=?",[$key]);return$r?LibraryRecord::fromRow($r):null;}catch(Throwable){return null;}}
 public function save(array $d,int $id=0):LibraryRecord{$caps=json_encode($d['capabilities']??[],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);$cfg=json_encode($d['configuration']??[],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);$p=[$d['library_key'],$d['name'],$d['library_type']??'PHP',$d['package_name']??'',$d['version']??'',$caps,$cfg,$d['status']??'active'];if($id>0){$p[]=$id;$this->db->execute("UPDATE `favorite_web_tool_libraries` SET library_key=?,name=?,library_type=?,package_name=?,version=?,capabilities=?,configuration=?,status=? WHERE id=?",$p);return$this->find($id)??new LibraryRecord($d);} $this->db->execute("INSERT INTO `favorite_web_tool_libraries` (`library_key`,`name`,`library_type`,`package_name`,`version`,`capabilities`,`configuration`,`status`) VALUES (?,?,?,?,?,?,?,?)",$p);return$this->find((int)$this->db->lastInsertId())??new LibraryRecord($d);}
 public function delete(int $id):bool{try{return(bool)$this->db->execute("DELETE FROM `favorite_web_tool_libraries` WHERE id=?",[$id]);}catch(Throwable){return false;}}
}

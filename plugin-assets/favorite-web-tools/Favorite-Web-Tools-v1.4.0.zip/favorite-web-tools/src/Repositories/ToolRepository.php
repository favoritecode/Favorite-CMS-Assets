<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Repositories;

use FavoriteCMS\Core\Database;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Support\ToolStatus;
use Throwable;

class ToolRepository
{
    protected Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function find(int $id): ?Tool
    {
        return $this->findById($id);
    }

    public function findById(int $id): ?Tool
    {
        $sql = "
            SELECT t.*, c.name as category_name, c.slug as category_slug
            FROM `favorite_web_tools` t
            LEFT JOIN `favorite_web_tool_categories` c ON c.id = t.category_id
            WHERE t.id = ?
        ";
        $row = $this->db->selectOne($sql, [$id]);
        return $row ? Tool::fromArray($row) : null;
    }

    public function findBySlug(string $slug): ?Tool
    {
        $sql = "
            SELECT t.*, c.name as category_name, c.slug as category_slug
            FROM `favorite_web_tools` t
            LEFT JOIN `favorite_web_tool_categories` c ON c.id = t.category_id
            WHERE t.slug = ?
        ";
        $row = $this->db->selectOne($sql, [$slug]);
        return $row ? Tool::fromArray($row) : null;
    }

    public function all(): array
    {
        return $this->getAllAdminTools();
    }

    public function byCategory(int $catId): array
    {
        return $this->getAllAdminTools(['category' => $catId]);
    }

    public function byStatus(string $status): array
    {
        return $this->getAllAdminTools(['status' => $status]);
    }

    public function updateStatus(int $id, string $status): bool
    {
        return $this->setStatus($id, $status);
    }

    /**
     * Get active tools for the public catalog and discovery API.
     */
    public function getPublicTools(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $where = ["t.`status` = 'ACTIVE'"];
        $params = [];

        if (!empty($filters['category'])) {
            $cat = trim((string)$filters['category']);
            if (is_numeric($cat)) {
                $where[] = "t.category_id = ?";
                $params[] = (int)$cat;
            } else {
                $where[] = "c.slug = ?";
                $params[] = $cat;
            }
        } elseif (!empty($filters['category_id'])) {
            $where[] = "t.category_id = ?";
            $params[] = (int)$filters['category_id'];
        }

        if (!empty($filters['search'])) {
            $search = '%' . trim((string)$filters['search']) . '%';
            $where[] = "(t.name LIKE ? OR t.description LIKE ?)";
            $params[] = $search;
            $params[] = $search;
        }

        if (!empty($filters['engine'])) {
            $where[] = "t.engine = ?";
            $params[] = strtoupper(trim((string)$filters['engine']));
        }

        if (!empty($filters['access_mode'])) {
            $where[] = "t.access_mode = ?";
            $params[] = strtoupper(trim((string)$filters['access_mode']));
        }

        $whereClause = "WHERE " . implode(' AND ', $where);

        // Count total
        $countSql = "
            SELECT COUNT(t.id) as cnt
            FROM `favorite_web_tools` t
            LEFT JOIN `favorite_web_tool_categories` c ON c.id = t.category_id
            {$whereClause}
        ";
        $totalRow = $this->db->selectOne($countSql, $params);
        $total = is_object($totalRow) ? (int)($totalRow->cnt ?? 0) : (int)($totalRow['cnt'] ?? 0);

        $page = max(1, $page);
        $perPage = max(1, min(100, $perPage));
        $totalPages = max(1, (int)ceil($total / $perPage));
        $offset = ($page - 1) * $perPage;

        $orderBy = "ORDER BY t.display_order ASC, t.name ASC";
        if (!empty($filters['sort'])) {
            $orderBy = match ($filters['sort']) {
                'name'   => "ORDER BY t.name ASC",
                'newest' => "ORDER BY t.id DESC",
                default  => "ORDER BY t.display_order ASC, t.name ASC",
            };
        }

        $sql = "
            SELECT t.*, c.name as category_name, c.slug as category_slug
            FROM `favorite_web_tools` t
            LEFT JOIN `favorite_web_tool_categories` c ON c.id = t.category_id
            {$whereClause}
            {$orderBy}
            LIMIT {$perPage} OFFSET {$offset}
        ";

        $rows = $this->db->select($sql, $params);
        $items = array_map(fn($row) => Tool::fromArray($row), $rows);

        return [
            'items'      => $items,
            'total'      => $total,
            'page'       => $page,
            'perPage'    => $perPage,
            'totalPages' => $totalPages,
        ];
    }

    /**
     * Get all tools for Admin Management with optional filters.
     *
     * @return Tool[]
     */
    public function getAllAdminTools(array $filters = []): array
    {
        $where = [];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = "t.status = ?";
            $params[] = strtoupper(trim((string)$filters['status']));
        }

        if (!empty($filters['category'])) {
            $cat = trim((string)$filters['category']);
            if (is_numeric($cat)) {
                $where[] = "t.category_id = ?";
                $params[] = (int)$cat;
            } else {
                $where[] = "c.slug = ?";
                $params[] = $cat;
            }
        } elseif (!empty($filters['category_id'])) {
            $where[] = "t.category_id = ?";
            $params[] = (int)$filters['category_id'];
        }

        if (!empty($filters['engine'])) {
            $where[] = "t.engine = ?";
            $params[] = strtoupper(trim((string)$filters['engine']));
        }

        if (!empty($filters['access_mode'])) {
            $where[] = "t.access_mode = ?";
            $params[] = strtoupper(trim((string)$filters['access_mode']));
        }

        if (!empty($filters['search'])) {
            $search = '%' . trim((string)$filters['search']) . '%';
            $where[] = "(t.name LIKE ? OR t.slug LIKE ? OR t.description LIKE ?)";
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }

        $whereClause = empty($where) ? "" : "WHERE " . implode(' AND ', $where);

        $sql = "
            SELECT t.*, c.name as category_name, c.slug as category_slug
            FROM `favorite_web_tools` t
            LEFT JOIN `favorite_web_tool_categories` c ON c.id = t.category_id
            {$whereClause}
            ORDER BY t.display_order ASC, t.id DESC
        ";

        $rows = $this->db->select($sql, $params);
        return array_map(fn($row) => Tool::fromArray($row), $rows);
    }

    private ?bool $hasDesignSlugColumn = null;

    protected function hasDesignSlugColumn(): bool
    {
        if ($this->hasDesignSlugColumn !== null) {
            return $this->hasDesignSlugColumn;
        }

        try {
            $this->db->selectOne("SELECT `frontend_design_slug` FROM `favorite_web_tools` LIMIT 0");
            $this->hasDesignSlugColumn = true;
        } catch (\Throwable) {
            $this->hasDesignSlugColumn = false;
        }

        return $this->hasDesignSlugColumn;
    }

    public function create(array $data): Tool
    {
        $hasDesignCol = $this->hasDesignSlugColumn();

        $columns = ['name', 'slug', 'description', 'category_id', 'engine'];
        if ($hasDesignCol) {
            $columns[] = 'frontend_design_slug';
        }
        $columns = array_merge($columns, [
            'access_mode', 'status', 'input_schema', 'output_schema',
            'configuration', 'display_order', 'meta_title', 'meta_description', 'icon'
        ]);

        $colList = implode('`, `', $columns);
        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $sql = "INSERT INTO `favorite_web_tools` (`{$colList}`) VALUES ({$placeholders})";

        $config = is_array($data['configuration'] ?? null) ? $data['configuration'] : (is_string($data['configuration'] ?? null) ? json_decode($data['configuration'], true) : []);
        if (!is_array($config)) {
            $config = [];
        }

        $customConfigKeys = [
            'ui_schema', 'handler_class', 'handler_id', 'html_source', 'css_source',
            'js_source', 'external_libraries', 'python_service_id', 'python_endpoint', 'thumbnail',
            'http_api_url', 'http_api_method', 'http_api_headers', 'http_request_mapping',
            'http_response_path', 'http_allowed_hosts', 'http_timeout', 'http_body_mode',
            'dynamic_php_source', 'dynamic_php_timeout', 'dynamic_php_memory_mb', 'dynamic_php_output_limit_kb',
            'rate_limit_per_minute', 'max_bulk_items', 'max_upload_size_mb', 'max_output_size_mb', 'asset_keys', 'library_keys'
        ];
        foreach ($customConfigKeys as $extra) {
            if (array_key_exists($extra, $data) && !array_key_exists($extra, $config)) {
                $config[$extra] = $data[$extra];
            }
        }

        $values = [
            $data['name'],
            $data['slug'],
            $data['description'] ?? null,
            isset($data['category_id']) && $data['category_id'] !== '' ? (int)$data['category_id'] : null,
            $data['engine'] ?? 'HTML',
        ];
        if ($hasDesignCol) {
            $values[] = $data['frontend_design_slug'] ?? null;
        }
        $values = array_merge($values, [
            $data['access_mode'] ?? 'FREE',
            $data['status'] ?? ToolStatus::DRAFT,
            is_array($data['input_schema'] ?? null) ? json_encode($data['input_schema']) : ($data['input_schema'] ?? null),
            is_array($data['output_schema'] ?? null) ? json_encode($data['output_schema']) : ($data['output_schema'] ?? null),
            !empty($config) ? json_encode($config) : null,
            (int)($data['display_order'] ?? 0),
            $data['meta_title'] ?? null,
            $data['meta_description'] ?? null,
            $data['icon'] ?? null,
        ]);

        $this->db->execute($sql, $values);

        $id = (int)$this->db->lastInsertId();
        $created = $this->findById($id) ?: new Tool(array_merge($data, ['id' => $id, 'configuration' => $config]));
        $this->snapshotRevision($id, 'created');
        return $created;
    }

    public function update(int $id, array $data): bool
    {
        $fields = [];
        $params = [];

        $jsonFields = ['input_schema', 'output_schema', 'configuration'];
        $allowedFields = [
            'name', 'slug', 'description', 'category_id', 'engine', 'access_mode', 'status',
            'input_schema', 'output_schema', 'configuration', 'display_order', 'meta_title',
            'meta_description', 'icon'
        ];
        if ($this->hasDesignSlugColumn()) {
            $allowedFields[] = 'frontend_design_slug';
        }

        // Merge extra config fields into configuration
        $config = null;
        if (array_key_exists('configuration', $data)) {
            $config = is_array($data['configuration']) ? $data['configuration'] : json_decode((string)$data['configuration'], true);
        }
        if (!is_array($config)) {
            $existing = $this->findById($id);
            $config = $existing ? $existing->configuration : [];
        }

        $hasExtraConfig = false;
        $customConfigKeys = [
            'ui_schema', 'handler_class', 'handler_id', 'html_source', 'css_source',
            'js_source', 'external_libraries', 'python_service_id', 'python_endpoint', 'thumbnail',
            'http_api_url', 'http_api_method', 'http_api_headers', 'http_request_mapping',
            'http_response_path', 'http_allowed_hosts', 'http_timeout', 'http_body_mode',
            'dynamic_php_source', 'dynamic_php_timeout', 'dynamic_php_memory_mb', 'dynamic_php_output_limit_kb',
            'rate_limit_per_minute', 'max_bulk_items', 'max_upload_size_mb', 'max_output_size_mb', 'asset_keys', 'library_keys'
        ];
        foreach ($customConfigKeys as $extra) {
            if (array_key_exists($extra, $data)) {
                $config[$extra] = $data[$extra];
                $hasExtraConfig = true;
            }
        }

        if ($hasExtraConfig || array_key_exists('configuration', $data)) {
            $data['configuration'] = $config;
        }

        foreach ($allowedFields as $field) {
            if (array_key_exists($field, $data)) {
                $fields[] = "`{$field}` = ?";
                $val = $data[$field];
                if (in_array($field, $jsonFields, true)) {
                    $val = is_array($val) ? json_encode($val) : $val;
                } elseif ($field === 'category_id') {
                    $val = ($val !== '' && $val !== null) ? (int)$val : null;
                }
                $params[] = $val;
            }
        }

        if (empty($fields)) {
            return false;
        }

        $params[] = $id;
        $sql = "UPDATE `favorite_web_tools` SET " . implode(', ', $fields) . " WHERE `id` = ?";
        $ok = (bool)$this->db->execute($sql, $params);
        if ($ok) {
            $this->snapshotRevision($id, 'updated');
        }
        return $ok;
    }

    public function setStatus(int $id, string $status): bool
    {
        $ok = (bool)$this->db->execute("UPDATE `favorite_web_tools` SET `status` = ? WHERE `id` = ?", [$status, $id]);
        if ($ok) {
            $this->snapshotRevision($id, strtolower($status));
        }
        return $ok;
    }

    public function delete(int $id): bool
    {
        return $this->db->execute("DELETE FROM `favorite_web_tools` WHERE `id` = ?", [$id]);
    }

    /**
     * Store an immutable snapshot of the current tool definition.
     * Fail-open for legacy installations where migration 007 has not run yet.
     */
    public function snapshotRevision(int $toolId, string $revisionStatus = 'draft'): void
    {
        try {
            $tool = $this->findById($toolId);
            if ($tool === null) {
                return;
            }
            $row = $this->db->selectOne(
                "SELECT COALESCE(MAX(`revision_no`), 0) AS max_rev FROM `favorite_web_tool_revisions` WHERE `tool_id` = ?",
                [$toolId]
            );
            $max = (int)(is_object($row) ? ($row->max_rev ?? 0) : ($row['max_rev'] ?? 0));
            $snapshot = $tool->toArray();
            unset($snapshot['category_name'], $snapshot['category_slug']);
            $this->db->execute(
                "INSERT INTO `favorite_web_tool_revisions` (`tool_id`,`revision_no`,`revision_status`,`snapshot`) VALUES (?,?,?,?)",
                [$toolId, $max + 1, substr(strtolower($revisionStatus), 0, 32), json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]
            );
        } catch (Throwable) {
            // Backward compatibility: revisions must never block normal tool saves.
        }
    }

    /** @return array<int,array<string,mixed>> */
    public function getRevisions(int $toolId, int $limit = 50): array
    {
        try {
            $limit = max(1, min(200, $limit));
            $rows = $this->db->select(
                "SELECT * FROM `favorite_web_tool_revisions` WHERE `tool_id` = ? ORDER BY `revision_no` DESC LIMIT {$limit}",
                [$toolId]
            );
            return array_map(static function ($row): array {
                $a = is_object($row) ? (array)$row : $row;
                $a['snapshot'] = isset($a['snapshot']) && is_string($a['snapshot'])
                    ? (json_decode($a['snapshot'], true) ?: [])
                    : ($a['snapshot'] ?? []);
                return $a;
            }, $rows);
        } catch (Throwable) {
            return [];
        }
    }

    public function restoreRevision(int $toolId, int $revisionNo): bool
    {
        try {
            $row = $this->db->selectOne(
                "SELECT `snapshot` FROM `favorite_web_tool_revisions` WHERE `tool_id` = ? AND `revision_no` = ?",
                [$toolId, $revisionNo]
            );
            if (!$row) {
                return false;
            }
            $raw = is_object($row) ? ($row->snapshot ?? '') : ($row['snapshot'] ?? '');
            $snapshot = is_array($raw) ? $raw : json_decode((string)$raw, true);
            if (!is_array($snapshot)) {
                return false;
            }
            unset($snapshot['id'], $snapshot['created_at'], $snapshot['updated_at'], $snapshot['category_name'], $snapshot['category_slug']);
            $snapshot['status'] = ToolStatus::DRAFT; // Restore safely as draft; publishing remains explicit.
            return $this->update($toolId, $snapshot);
        } catch (Throwable) {
            return false;
        }
    }

    public function duplicate(int $toolId, ?string $newName = null, ?string $newSlug = null): ?Tool
    {
        $tool = $this->findById($toolId);
        if ($tool === null) {
            return null;
        }
        $data = $tool->toArray();
        unset($data['id'], $data['created_at'], $data['updated_at'], $data['category_name'], $data['category_slug']);
        $data['name'] = $newName ?: ($tool->name . ' Copy');
        $base = $newSlug ?: ($tool->slug . '-copy');
        $base = strtolower(trim((string)preg_replace('/[^a-zA-Z0-9]+/', '-', $base), '-')) ?: 'tool-copy';
        $slug = $base;
        $i = 2;
        while ($this->findBySlug($slug) !== null) {
            $slug = $base . '-' . $i++;
        }
        $data['slug'] = $slug;
        $data['status'] = ToolStatus::DRAFT;
        return $this->create($data);
    }

    /** @return array<string,mixed> */
    public function exportPackage(int $toolId): array
    {
        $tool = $this->findById($toolId);
        if ($tool === null) {
            return [];
        }
        $definition = $tool->toArray();
        unset($definition['id'], $definition['created_at'], $definition['updated_at'], $definition['category_name'], $definition['category_slug']);
        return [
            'format' => 'favorite-web-tools/tool-package',
            'format_version' => 1,
            'exported_at' => gmdate('c'),
            'tool' => $definition,
            // Secret values are deliberately never exported. Only secret binding names inside config may remain.
        ];
    }

    public function importPackage(array $package, bool $asDraft = true): Tool
    {
        $data = $package['tool'] ?? $package;
        if (!is_array($data) || trim((string)($data['name'] ?? '')) === '') {
            throw new \InvalidArgumentException('Invalid Favorite Web Tools tool package.');
        }
        $data['name'] = trim((string)$data['name']);
        $base = strtolower(trim((string)preg_replace('/[^a-zA-Z0-9]+/', '-', (string)($data['slug'] ?? $data['name'])), '-')) ?: 'imported-tool';
        $slug = $base;
        $i = 2;
        while ($this->findBySlug($slug) !== null) {
            $slug = $base . '-' . $i++;
        }
        $data['slug'] = $slug;
        if ($asDraft) {
            $data['status'] = ToolStatus::DRAFT;
        }
        unset($data['id'], $data['created_at'], $data['updated_at'], $data['category_name'], $data['category_slug']);
        return $this->create($data);
    }

    public function countByStatus(): array
    {
        $rows = $this->db->select("SELECT `status`, COUNT(*) as cnt FROM `favorite_web_tools` GROUP BY `status`");
        $counts = [
            'total'    => 0,
            'active'   => 0,
            'draft'    => 0,
            'disabled' => 0,
        ];

        foreach ($rows as $row) {
            $st = strtolower((string)(is_object($row) ? ($row->status ?? '') : ($row['status'] ?? '')));
            $cnt = (int)(is_object($row) ? ($row->cnt ?? 0) : ($row['cnt'] ?? 0));
            $counts['total'] += $cnt;
            if (isset($counts[$st])) {
                $counts[$st] = $cnt;
            }
        }

        return $counts;
    }
}

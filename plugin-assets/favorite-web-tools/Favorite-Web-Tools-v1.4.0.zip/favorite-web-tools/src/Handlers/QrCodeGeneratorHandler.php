<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Handlers;

use FavoriteCMS\Tools\Services\QrCodeService;

final class QrCodeGeneratorHandler extends AbstractToolHandler
{
    public function __construct(private ?QrCodeService $service = null)
    {
        $this->service ??= new QrCodeService();
    }

    public function getId(): string
    {
        return 'qr_code_generator';
    }

    public function getName(): string
    {
        return 'QR Code Generator (Server-side)';
    }

    public function execute(array $inputs, array $config = []): array
    {
        return $this->service->generate($inputs, $config);
    }
}

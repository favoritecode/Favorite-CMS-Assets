<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Handlers;

use FavoriteCMS\Tools\Models\DynamicHandler;
use FavoriteCMS\Tools\Services\DynamicHandlerRuntime;

final class ConfiguredToolHandler extends AbstractToolHandler
{
    public function __construct(
        private DynamicHandler $definition,
        private ?DynamicHandlerRuntime $runtime = null
    ) {
        $this->runtime ??= new DynamicHandlerRuntime();
    }

    public function getId(): string
    {
        return $this->definition->handler_id;
    }

    public function getName(): string
    {
        return $this->definition->name;
    }

    public function execute(array $inputs, array $config = []): array
    {
        return $this->runtime->execute($this->definition->definition, $inputs, $config);
    }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Models;

final class LibraryRecord
{
    public ?int $id = null;
    public string $library_key = '';
    public string $name = '';
    public string $library_type = 'PHP';
    public string $package_name = '';
    public string $version = '';
    public array $capabilities = [];
    public array $configuration = [];
    public string $status = 'active';
    public ?string $created_at = null;
    public ?string $updated_at = null;

    public function __construct(array $data = [])
    {
        foreach ($data as $k => $v) {
            if (in_array($k, ['capabilities','configuration'], true)) {
                $this->{$k} = is_array($v) ? $v : (is_string($v) ? (json_decode($v, true) ?: []) : []);
            } elseif (property_exists($this, $k)) {
                $this->{$k} = $k === 'id' ? ($v === null ? null : (int)$v) : $v;
            }
        }
    }
    public static function fromRow(array|object $row): self { return new self((array)$row); }
    public function isActive(): bool { return strtolower($this->status) === 'active'; }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Models;

final class DynamicOperation
{
    public ?int $id = null;
    public string $operation_id = '';
    public string $name = '';
    public string $description = '';
    public string $executor_type = 'BUILTIN';
    public int $version = 1;
    public string $status = 'active';
    public array $parameter_schema = [];
    public array $configuration = [];
    public ?string $created_at = null;
    public ?string $updated_at = null;

    public function __construct(array $data = [])
    {
        foreach ($data as $k => $v) {
            if (in_array($k, ['parameter_schema', 'configuration'], true)) {
                $this->{$k} = self::jsonArray($v);
            } elseif (property_exists($this, $k)) {
                $this->{$k} = $k === 'id' ? ($v === null ? null : (int)$v) : ($k === 'version' ? (int)$v : $v);
            }
        }
    }

    public static function fromRow(array|object $row): self
    {
        return new self((array)$row);
    }

    public function isActive(): bool
    {
        return strtolower($this->status) === 'active';
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }

    private static function jsonArray(mixed $value): array
    {
        if (is_array($value)) return $value;
        if (is_object($value)) return (array)$value;
        if (is_string($value) && trim($value) !== '') {
            $decoded = json_decode($value, true);
            return is_array($decoded) ? $decoded : [];
        }
        return [];
    }
}

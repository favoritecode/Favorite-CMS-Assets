<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Models;

final class SecretRecord
{
    public ?int $id = null;
    public string $secret_key = '';
    public string $label = '';
    public string $encrypted_value = '';
    public array $scope = [];
    public string $status = 'active';
    public ?string $created_at = null;
    public ?string $updated_at = null;

    public function __construct(array $data = [])
    {
        foreach ($data as $k => $v) {
            if ($k === 'scope') {
                $this->scope = is_array($v) ? $v : (is_string($v) ? (json_decode($v, true) ?: []) : []);
            } elseif (property_exists($this, $k)) {
                $this->{$k} = $k === 'id' ? ($v === null ? null : (int)$v) : $v;
            }
        }
    }

    public static function fromRow(array|object $row): self { return new self((array)$row); }
    public function isActive(): bool { return strtolower($this->status) === 'active'; }
}

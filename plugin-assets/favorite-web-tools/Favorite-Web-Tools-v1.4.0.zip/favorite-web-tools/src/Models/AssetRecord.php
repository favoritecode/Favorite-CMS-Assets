<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Models;

final class AssetRecord
{
    public ?int $id = null;
    public string $asset_key = '';
    public string $name = '';
    public string $asset_type = 'JS';
    public string $source_type = 'CDN';
    public string $url = '';
    public string $integrity = '';
    public string $crossorigin = '';
    public int $load_order = 100;
    public array $configuration = [];
    public string $status = 'active';
    public ?string $created_at = null;
    public ?string $updated_at = null;

    public function __construct(array $data = [])
    {
        foreach ($data as $k => $v) {
            if ($k === 'configuration') {
                $this->configuration = is_array($v) ? $v : (is_string($v) ? (json_decode($v, true) ?: []) : []);
            } elseif (property_exists($this, $k)) {
                $this->{$k} = $k === 'id' ? ($v === null ? null : (int)$v) : ($k === 'load_order' ? (int)$v : $v);
            }
        }
    }
    public static function fromRow(array|object $row): self { return new self((array)$row); }
    public function isActive(): bool { return strtolower($this->status) === 'active'; }
}

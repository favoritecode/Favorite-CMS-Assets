<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Models;

final class DynamicHandler
{
    public ?int $id = null;
    public string $handler_id = '';
    public string $name = '';
    public string $description = '';
    public string $status = 'active';
    public array $definition = [];
    public ?string $created_at = null;
    public ?string $updated_at = null;

    public static function fromArray(array|object $row): self
    {
        if (is_object($row)) {
            $row = (array)$row;
        }

        $model = new self();
        $model->id = isset($row['id']) ? (int)$row['id'] : null;
        $model->handler_id = (string)($row['handler_id'] ?? '');
        $model->name = (string)($row['name'] ?? '');
        $model->description = (string)($row['description'] ?? '');
        $model->status = strtolower((string)($row['status'] ?? 'active'));
        $model->definition = self::decodeJson($row['definition'] ?? []);
        $model->created_at = isset($row['created_at']) ? (string)$row['created_at'] : null;
        $model->updated_at = isset($row['updated_at']) ? (string)$row['updated_at'] : null;
        return $model;
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'handler_id' => $this->handler_id,
            'name' => $this->name,
            'description' => $this->description,
            'status' => $this->status,
            'definition' => $this->definition,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }

    private static function decodeJson(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if (is_string($value) && trim($value) !== '') {
            $decoded = json_decode($value, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return [];
    }
}

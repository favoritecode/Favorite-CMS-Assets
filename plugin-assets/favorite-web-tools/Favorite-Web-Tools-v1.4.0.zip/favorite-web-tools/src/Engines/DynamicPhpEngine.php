<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Engines;

use FavoriteCMS\Tools\Contracts\EngineInterface;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Services\DynamicPhpRuntimeService;
use FavoriteCMS\Tools\Support\EngineType;

final class DynamicPhpEngine implements EngineInterface
{
    public function __construct(private ?DynamicPhpRuntimeService $runtime = null)
    {
        $this->runtime ??= new DynamicPhpRuntimeService();
    }

    public function canHandle(Tool $tool): bool
    {
        return strtoupper($tool->engine) === EngineType::DYNAMIC_PHP;
    }

    public function validate(Tool $tool, array $inputs): array
    {
        $source = (string)($tool->dynamic_php_source ?? '');
        return $this->runtime->validateSource($source);
    }

    public function execute(Tool $tool, array $inputs): array
    {
        $source = (string)($tool->dynamic_php_source ?? '');
        $limits = [
            'timeout_seconds' => (int)($tool->dynamic_php_timeout ?? DynamicPhpRuntimeService::DEFAULT_TIMEOUT_SECONDS),
            'memory_mb' => (int)($tool->dynamic_php_memory_mb ?? DynamicPhpRuntimeService::DEFAULT_MEMORY_MB),
            'output_limit_kb' => (int)($tool->dynamic_php_output_limit_kb ?? DynamicPhpRuntimeService::DEFAULT_OUTPUT_LIMIT_KB),
        ];
        $context = [
            'tool_id' => $tool->id,
            'tool_slug' => $tool->slug,
            'tool_name' => $tool->name,
            'engine' => EngineType::DYNAMIC_PHP,
        ];

        return $this->runtime->execute($source, $inputs, $context, $limits);
    }
}

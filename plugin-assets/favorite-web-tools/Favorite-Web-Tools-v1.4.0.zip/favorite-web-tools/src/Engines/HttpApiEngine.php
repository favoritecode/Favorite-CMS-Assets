<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Engines;

use FavoriteCMS\Tools\Contracts\EngineInterface;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Support\EngineType;
use FavoriteCMS\Tools\Support\ResultType;
use FavoriteCMS\Tools\Services\SecretVaultService;
use RuntimeException;

/**
 * Generic, server-side HTTP API engine for admin-configured tools.
 * Secrets can be referenced from environment variables using {{env:NAME}}.
 */
final class HttpApiEngine implements EngineInterface
{
    private const MAX_RESPONSE_BYTES = 2_000_000;

    public function __construct(private ?SecretVaultService $secrets = null) {}

    public function canHandle(Tool $tool): bool
    {
        return strtoupper($tool->engine) === EngineType::HTTP_API;
    }

    public function validate(Tool $tool, array $inputs): array
    {
        $url = trim((string)($tool->configuration['http_api_url'] ?? ''));
        if ($url === '') {
            return ['HTTP API URL is required.'];
        }
        $validation = $this->validateEndpoint($url, $tool->configuration);
        return $validation === null ? [] : [$validation];
    }

    public function execute(Tool $tool, array $inputs): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('cURL is required for the HTTP API engine.');
        }

        $config = $tool->configuration;
        $url = trim((string)($config['http_api_url'] ?? ''));
        $error = $this->validateEndpoint($url, $config);
        if ($error !== null) {
            throw new RuntimeException($error);
        }
        $parts = parse_url($url);
        $host = strtolower((string)($parts['host'] ?? ''));
        $scheme = strtolower((string)($parts['scheme'] ?? 'https'));
        $port = isset($parts['port']) ? (int)$parts['port'] : ($scheme === 'https' ? 443 : 80);
        $resolvedIp = $this->resolvePublicIp($host);
        if ($resolvedIp === null) {
            throw new RuntimeException('API hostname could not be resolved to a public address.');
        }

        $method = strtoupper((string)($config['http_api_method'] ?? 'POST'));
        if (!in_array($method, ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            throw new RuntimeException('Unsupported HTTP method.');
        }

        $mapping = $config['http_request_mapping'] ?? [];
        if (!is_array($mapping)) {
            $mapping = [];
        }
        $payload = $this->mapInputs($inputs, $mapping);

        if ($method === 'GET' && $payload !== []) {
            $sep = str_contains($url, '?') ? '&' : '?';
            $url .= $sep . http_build_query($payload);
        }

        $headers = ['Accept: application/json, text/plain;q=0.9, */*;q=0.5'];
        $configuredHeaders = $config['http_api_headers'] ?? [];
        if (is_array($configuredHeaders)) {
            foreach ($configuredHeaders as $name => $value) {
                $name = trim((string)$name);
                if ($name === '' || preg_match('/[\r\n:]/', $name)) {
                    continue;
                }
                $resolved = $this->resolveSecretTokens((string)$value);
                if (preg_match('/[\r\n]/', $resolved)) {
                    continue;
                }
                $headers[] = $name . ': ' . $resolved;
            }
        }

        $bodyMode = strtolower((string)($config['http_body_mode'] ?? 'json'));
        $body = null;
        if ($method !== 'GET') {
            if ($bodyMode === 'form') {
                $body = http_build_query($payload);
                $headers[] = 'Content-Type: application/x-www-form-urlencoded';
            } elseif ($bodyMode === 'multipart') {
                $body = $this->buildMultipartPayload($payload);
                // Let cURL generate the multipart boundary automatically.
            } else {
                $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                if ($body === false) {
                    throw new RuntimeException('Unable to encode API request payload.');
                }
                $headers[] = 'Content-Type: application/json';
            }
        }

        $timeout = max(1, min(30, (int)($config['http_timeout'] ?? 15)));
        $responseHeaders = [];
        $responseBody = '';

        $ch = curl_init($url);
        if ($ch === false) {
            throw new RuntimeException('Unable to initialize HTTP client.');
        }

        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_RESOLVE => ["{$host}:{$port}:{$resolvedIp}"],
            CURLOPT_PROXY => '',
            CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$responseHeaders): int {
                $len = strlen($line);
                $parts = explode(':', $line, 2);
                if (count($parts) === 2) {
                    $responseHeaders[strtolower(trim($parts[0]))] = trim($parts[1]);
                }
                return $len;
            },
            CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$responseBody): int {
                if (strlen($responseBody) + strlen($chunk) > self::MAX_RESPONSE_BYTES) {
                    return 0;
                }
                $responseBody .= $chunk;
                return strlen($chunk);
            },
        ]);

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }

        $ok = curl_exec($ch);
        $curlError = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $contentType = (string)(curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: ($responseHeaders['content-type'] ?? ''));
        curl_close($ch);

        if ($ok === false) {
            if (strlen($responseBody) >= self::MAX_RESPONSE_BYTES) {
                throw new RuntimeException('API response exceeded the safe size limit.');
            }
            throw new RuntimeException($curlError !== '' ? 'HTTP API request failed.' : 'HTTP API request failed.');
        }

        if ($status < 200 || $status >= 300) {
            throw new RuntimeException('HTTP API returned status ' . $status . '.');
        }

        $data = $this->decodeResponse($responseBody, $contentType);
        $path = trim((string)($config['http_response_path'] ?? ''));
        if ($path !== '') {
            $data = $this->extractPath($data, $path);
        }

        return [
            'success' => true,
            'type' => (is_array($data) || is_object($data)) ? ResultType::JSON : ResultType::TEXT,
            'data' => $data,
            'value' => $data,
            'meta' => [
                'http_status' => $status,
                'content_type' => $contentType,
                'engine' => 'HTTP_API',
            ],
        ];
    }

    /**
     * Build a safe multipart payload from normalized tool inputs.
     * File values use the same normalized shape emitted by ToolExecutionApiController.
     *
     * @param array<string,mixed> $payload
     * @return array<string,mixed>
     */
    private function buildMultipartPayload(array $payload): array
    {
        $out = [];
        foreach ($payload as $key => $value) {
            $field = (string)$key;
            if ($field === '' || preg_match('/[\r\n]/', $field)) {
                continue;
            }

            if (is_array($value) && array_key_exists('content', $value)) {
                $content = (string)($value['content'] ?? '');
                if (strlen($content) > 10_000_000) {
                    throw new RuntimeException('Multipart upload exceeds the safe 10 MB limit.');
                }
                $filename = basename((string)($value['name'] ?? 'upload.bin'));
                $mime = trim((string)($value['type'] ?? 'application/octet-stream'));
                if ($filename === '' || preg_match('/[\r\n]/', $filename) || preg_match('/[\r\n]/', $mime)) {
                    throw new RuntimeException('Invalid multipart upload metadata.');
                }
                if (!class_exists('CURLStringFile')) {
                    throw new RuntimeException('This PHP/cURL build does not support in-memory multipart uploads.');
                }
                $out[$field] = new \CURLStringFile($content, $mime, $filename);
                continue;
            }

            if (is_array($value) || is_object($value)) {
                $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                if ($encoded === false) {
                    throw new RuntimeException('Unable to encode multipart field.');
                }
                $out[$field] = $encoded;
                continue;
            }

            if (is_bool($value)) {
                $out[$field] = $value ? '1' : '0';
            } elseif ($value === null) {
                $out[$field] = '';
            } else {
                $out[$field] = (string)$value;
            }
        }
        return $out;
    }

    private function validateEndpoint(string $url, array $config): ?string
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return 'Configured HTTP API URL is invalid.';
        }
        $parts = parse_url($url);
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower((string)($parts['host'] ?? ''));
        $port = isset($parts['port']) ? (int)$parts['port'] : ($scheme === 'https' ? 443 : 80);
        if (!in_array($scheme, ['http', 'https'], true) || $host === '') {
            return 'Only HTTP/HTTPS API URLs are allowed.';
        }
        if (isset($parts['user']) || isset($parts['pass'])) {
            return 'Credentials in API URLs are forbidden.';
        }
        if (!in_array($port, [80, 443], true)) {
            return 'Only standard HTTP/HTTPS ports are allowed.';
        }
        if ($host === 'localhost' || str_ends_with($host, '.localhost')) {
            return 'Localhost API targets are forbidden.';
        }

        $allowedHosts = $config['http_allowed_hosts'] ?? [];
        if (is_string($allowedHosts)) {
            $allowedHosts = preg_split('/[\s,]+/', $allowedHosts, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        }
        if (is_array($allowedHosts) && $allowedHosts !== []) {
            $allowedHosts = array_map(static fn($v) => strtolower(trim((string)$v)), $allowedHosts);
            if (!in_array($host, $allowedHosts, true)) {
                return 'API host is not in the configured allowlist.';
            }
        }

        // Block direct IP targets and hostnames resolving only to private/reserved space.
        if ($this->resolvePublicIp($host) === null) {
            return 'API hostname resolves to a private/reserved address or could not be resolved.';
        }

        return null;
    }

    private function resolvePublicIp(string $host): ?string
    {
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $this->isPublicIp($host) ? $host : null;
        }

        $ips = gethostbynamel($host) ?: [];
        if ($ips === []) {
            return null;
        }
        foreach ($ips as $ip) {
            if (!$this->isPublicIp($ip)) {
                return null;
            }
        }
        return $ips[0] ?? null;
    }

    private function isPublicIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    }

    private function mapInputs(array $inputs, array $mapping): array
    {
        if ($mapping === []) {
            return $inputs;
        }
        $out = [];
        foreach ($mapping as $target => $source) {
            if (is_int($target)) {
                $target = (string)$source;
            }
            $source = (string)$source;
            if (str_starts_with($source, '{{input.') && str_ends_with($source, '}}')) {
                $source = substr($source, 8, -2);
            }
            if (array_key_exists($source, $inputs)) {
                $out[(string)$target] = $inputs[$source];
            }
        }
        return $out;
    }

    private function resolveSecretTokens(string $value): string
    {
        $value = preg_replace_callback('/\{\{secret[.:]([A-Z0-9_]+)\}\}/', function (array $m): string {
            return (string)($this->secrets?->resolve($m[1]) ?? '');
        }, $value) ?? $value;

        return preg_replace_callback('/\{\{env:([A-Z0-9_]+)\}\}/', static function (array $m): string {
            $v = getenv($m[1]);
            return $v === false ? '' : (string)$v;
        }, $value) ?? $value;
    }

    private function decodeResponse(string $body, string $contentType): mixed
    {
        if (str_contains(strtolower($contentType), 'json')) {
            $decoded = json_decode($body, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }
        $trim = trim($body);
        if (($trim[0] ?? '') === '{' || ($trim[0] ?? '') === '[') {
            $decoded = json_decode($body, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }
        return $body;
    }

    private function extractPath(mixed $data, string $path): mixed
    {
        $path = trim($path, '. ');
        if ($path === '') {
            return $data;
        }
        $current = $data;
        foreach (explode('.', $path) as $segment) {
            if (is_array($current) && array_key_exists($segment, $current)) {
                $current = $current[$segment];
                continue;
            }
            throw new RuntimeException("Configured response path '{$path}' was not found.");
        }
        return $current;
    }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Engines;

use FavoriteCMS\Tools\Contracts\EngineInterface;
use FavoriteCMS\Tools\Handlers\AbstractToolHandler;
use FavoriteCMS\Tools\Handlers\PhpHandlerRegistry;
use FavoriteCMS\Tools\Handlers\ConfiguredToolHandler;
use FavoriteCMS\Tools\Repositories\DynamicHandlerRepository;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Services\DynamicHandlerRuntime;
use FavoriteCMS\Tools\Support\EngineType;
use Throwable;

class PhpEngine implements EngineInterface
{
    public function __construct(
        private ?DynamicHandlerRepository $dynamicHandlers = null,
        private ?DynamicHandlerRuntime $dynamicRuntime = null
    ) {
    }

    public function canHandle(Tool $tool): bool
    {
        return $tool->engine === EngineType::PHP;
    }

    public function validate(Tool $tool, array $inputs): array
    {
        $handlerId = $this->resolveHandlerId($tool);
        $handler = $this->resolveHandler($handlerId);

        if (!$handler) {
            return ["Controlled PHP handler '{$handlerId}' is not registered or active."];
        }

        return [];
    }

    public function execute(Tool $tool, array $inputs): array
    {
        $handlerId = $this->resolveHandlerId($tool);
        $handler = $this->resolveHandler($handlerId);

        if (!$handler) {
            return [
                'success' => false,
                'error'   => "Controlled PHP handler '{$handlerId}' is not registered or active.",
            ];
        }

        try {
            $result = $handler->execute($inputs, $tool->configuration ?? []);
            if (!isset($result['success'])) {
                $result['success'] = true;
            }
            if (isset($result['value']) && !isset($result['data'])) {
                $result['data'] = $result['value'];
            } elseif (isset($result['data']) && !isset($result['value'])) {
                $result['value'] = $result['data'];
            }
            return $result;
        } catch (Throwable $e) {
            return [
                'success' => false,
                'error'   => \FavoriteCMS\Tools\Services\ToolExecutionService::sanitizeErrorMessage($e),
            ];
        }
    }


    private function resolveHandler(string $handlerId): ?\FavoriteCMS\Tools\Contracts\ToolHandlerInterface
    {
        $handler = PhpHandlerRegistry::get($handlerId);
        if ($handler) {
            return $handler;
        }

        if ($this->dynamicHandlers !== null) {
            $dynamic = $this->dynamicHandlers->findByHandlerId($handlerId);
            if ($dynamic && $dynamic->isActive()) {
                return new ConfiguredToolHandler($dynamic, $this->dynamicRuntime);
            }
        }

        return null;
    }

    private function resolveHandlerId(Tool $tool): string
    {
        if (!empty($tool->handler_id)) {
            return (string)$tool->handler_id;
        }

        if (!empty($tool->handler_class)) {
            return (string)$tool->handler_class;
        }

        if (!empty($tool->configuration['handler_class'])) {
            return (string)$tool->configuration['handler_class'];
        }

        if (!empty($tool->configuration['php_handler'])) {
            return (string)$tool->configuration['php_handler'];
        }

        $fallback = str_replace('-', '_', $tool->slug);
        return $fallback;
    }
}


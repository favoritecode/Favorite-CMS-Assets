<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Controllers\Api;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Tools\Services\QrCodeService;
use FavoriteCMS\Tools\Services\ToolExecutionService;
use Throwable;

final class QrCodeApiController
{
    public function __construct(private Application $app, private QrCodeService $service)
    {
    }

    public function generate(Request $request): Response
    {
        $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? 'application/json'));
        if ($contentType !== ''
            && !str_contains($contentType, 'application/json')
            && !str_contains($contentType, 'multipart/form-data')
            && !str_contains($contentType, 'application/x-www-form-urlencoded')) {
            return Response::json([
                'success' => false,
                'reason' => 'UNSUPPORTED_MEDIA_TYPE',
                'error' => 'Use JSON, form data, or multipart form data.',
            ], 415);
        }

        $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > QrCodeService::MAX_CSV_BYTES + 262144) {
            return Response::json([
                'success' => false,
                'reason' => 'REQUEST_TOO_LARGE',
                'error' => 'Request exceeds the allowed size limit.',
            ], 413);
        }

        try {
            $inputs = $this->collectInputs($request);
            $result = $this->service->generate($inputs);
            if (($result['success'] ?? false) !== true) {
                $reason = (string)($result['reason'] ?? 'QR_GENERATION_FAILED');
                $status = match ($reason) {
                    'INVALID_URL', 'NO_VALID_ROWS', 'QR_GENERATION_FAILED' => 422,
                    'TOO_MANY_ITEMS', 'CSV_TOO_LARGE' => 413,
                    'INVALID_OPTIONS' => 422,
                    default => 400,
                };
                return Response::json([
                    'success' => false,
                    'reason' => $reason,
                    'error' => ToolExecutionService::sanitizeMessageString((string)($result['error'] ?? 'QR generation failed.')),
                ], $status);
            }

            $payload = $result['value'] ?? $result['data'] ?? $result;
            return Response::json(is_array($payload) ? $payload : ['success' => true, 'data' => $payload], 200);
        } catch (Throwable $e) {
            return Response::json([
                'success' => false,
                'reason' => 'QR_GENERATION_FAILED',
                'error' => ToolExecutionService::sanitizeErrorMessage($e),
            ], 500);
        }
    }

    /** @return array<string,mixed> */
    private function collectInputs(Request $request): array
    {
        $inputs = [];
        $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));

        if (str_contains($contentType, 'application/json')) {
            $raw = method_exists($request, 'getContent')
                ? (string)$request->getContent()
                : (string)@file_get_contents('php://input');
            if ($raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $inputs = isset($decoded['inputs']) && is_array($decoded['inputs']) ? $decoded['inputs'] : $decoded;
                }
            }
        }

        if ($inputs === []) {
            $post = !empty($_POST) ? $_POST : (method_exists($request, 'all') ? $request->all() : []);
            if (is_array($post)) {
                unset($post['_token'], $post['_fcms_json_payload']);
                $inputs = isset($post['inputs']) && is_array($post['inputs']) ? $post['inputs'] : $post;
            }
        }

        foreach ($_FILES ?? [] as $key => $file) {
            if (!is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                continue;
            }
            $size = (int)($file['size'] ?? 0);
            if ($size > QrCodeService::MAX_CSV_BYTES) {
                throw new \RuntimeException('CSV upload exceeds the 2 MB limit.');
            }
            $inputs[$key] = [
                'name' => basename((string)($file['name'] ?? 'upload.csv')),
                'type' => (string)($file['type'] ?? 'text/csv'),
                'size' => $size,
                'content' => (string)@file_get_contents((string)($file['tmp_name'] ?? '')),
            ];
        }

        return $inputs;
    }
}

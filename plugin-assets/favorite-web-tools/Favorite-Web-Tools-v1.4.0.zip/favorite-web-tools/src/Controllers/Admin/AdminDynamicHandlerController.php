<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Controllers\Admin;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\User;
use FavoriteCMS\Tools\Models\DynamicHandler;
use FavoriteCMS\Tools\Handlers\ConfiguredToolHandler;
use FavoriteCMS\Tools\Handlers\PhpHandlerRegistry;
use FavoriteCMS\Tools\Repositories\DynamicHandlerRepository;
use FavoriteCMS\Tools\Repositories\ToolRepository;
use FavoriteCMS\Tools\Services\DynamicHandlerRuntime;
use FavoriteCMS\Tools\Support\CsrfGuard;
use FavoriteCMS\Tools\Support\ViewRenderer;
use Throwable;

final class AdminDynamicHandlerController
{
    public function __construct(
        private Application $app,
        private DynamicHandlerRepository $repo,
        private ?DynamicHandlerRuntime $runtime = null,
        private ?ToolRepository $toolRepo = null
    ) {
        $this->runtime ??= new DynamicHandlerRuntime();
    }

    public function handle(Request $request): Response|string
    {
        if (!$this->isAuthorized()) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage dynamic handlers.</p>', 403);
        }

        if ($request->method() === 'POST') {
            return $this->handlePost($request);
        }

        $action = (string)$request->get('action', 'index');
        $id = (int)$request->get('id', 0);
        if ($action === 'create') {
            return $this->form(null);
        }
        if ($action === 'edit') {
            $handler = $this->repo->findById($id);
            if (!$handler) {
                $_SESSION['flash_error'] = 'Dynamic handler not found.';
                return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers');
            }
            return $this->form($handler);
        }
        if ($action === 'export') {
            return $this->exportHandler($id);
        }
        return $this->index();
    }

    private function index(): string
    {
        $flashSuccess = $_SESSION['flash_success'] ?? null;
        $flashError = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);

        return ViewRenderer::render('admin/dynamic-handlers/index', [
            'handlers' => $this->repo->all(false),
            'flashSuccess' => $flashSuccess,
            'flashError' => $flashError,
            'csrfToken' => CsrfGuard::token(),
        ]);
    }

    private function form(?DynamicHandler $handler): string|Response
    {
        if ($handler === null) {
            $handler = new DynamicHandler();
            $handler->definition = [
                'input_key' => 'text',
                'result_type' => 'TEXT',
                'steps' => [
                    ['operation' => 'trim'],
                ],
            ];
        }

        $flashError = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_error']);

        return ViewRenderer::render('admin/dynamic-handlers/form', [
            'handler' => $handler,
            'csrfToken' => CsrfGuard::token(),
            'allowedOperations' => $this->runtime->allAvailableOperations(),
            'flashError' => $flashError,
        ]);
    }

    private function handlePost(Request $request): Response
    {
        if (!CsrfGuard::verify($request)) {
            $_SESSION['flash_error'] = 'Security token invalid or expired.';
            return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers');
        }

        $action = (string)$request->post('action', 'save');
        $id = (int)$request->post('id', 0);

        if ($action === 'import') {
            return $this->importHandler($request);
        }

        if ($action === 'delete') {
            if ($id > 0) {
                $handler = $this->repo->findById($id);
                if ($handler && $this->toolRepo !== null) {
                    $inUse = 0;
                    foreach ($this->toolRepo->all() as $tool) {
                        if (($tool->handler_id ?? null) === $handler->handler_id) {
                            $inUse++;
                        }
                    }
                    if ($inUse > 0) {
                        $_SESSION['flash_error'] = "This dynamic handler is used by {$inUse} tool(s). Reassign those tools before deleting it.";
                        return Response::redirect("/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}");
                    }
                }
                $this->repo->delete($id);
                $_SESSION['flash_success'] = 'Dynamic handler deleted.';
            }
            return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers');
        }

        $name = trim((string)$request->post('name', ''));
        $handlerId = strtolower(trim((string)$request->post('handler_id', '')));
        $handlerId = preg_replace('/[^a-z0-9_-]+/', '_', $handlerId) ?? $handlerId;
        $handlerId = trim($handlerId, '_-');
        $description = trim((string)$request->post('description', ''));
        $status = strtolower((string)$request->post('status', 'active')) === 'disabled' ? 'disabled' : 'active';
        $rawDefinition = trim((string)$request->post('definition', '{}'));
        $definition = json_decode($rawDefinition, true);

        if ($name === '' || $handlerId === '') {
            $_SESSION['flash_error'] = 'Name and Handler ID are required.';
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }
        if (!is_array($definition)) {
            $_SESSION['flash_error'] = 'Definition must be valid JSON: ' . json_last_error_msg();
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }

        $errors = $this->runtime->validateDefinition($definition);
        if ($errors !== []) {
            $_SESSION['flash_error'] = implode(' ', $errors);
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }

        $registered = PhpHandlerRegistry::get($handlerId);
        if ($registered !== null && !($registered instanceof ConfiguredToolHandler)) {
            $_SESSION['flash_error'] = "Handler ID '{$handlerId}' is reserved by a built-in controlled handler.";
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }

        $existing = $this->repo->findByHandlerId($handlerId);
        if ($existing && $existing->id !== $id) {
            $_SESSION['flash_error'] = "Handler ID '{$handlerId}' is already in use.";
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }

        $payload = compact('handlerId', 'name', 'description', 'status', 'definition');
        $payload['handler_id'] = $payload['handlerId'];
        unset($payload['handlerId']);

        try {
            if ($id > 0) {
                $this->repo->update($id, $payload);
                if ($updated = $this->repo->findById($id)) { PhpHandlerRegistry::register(new ConfiguredToolHandler($updated, $this->runtime)); }
                $_SESSION['flash_success'] = "Dynamic handler '{$name}' updated.";
                return Response::redirect("/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}");
            }

            $created = $this->repo->create($payload);
            PhpHandlerRegistry::register(new ConfiguredToolHandler($created, $this->runtime));
            $_SESSION['flash_success'] = "Dynamic handler '{$name}' created.";
            return Response::redirect("/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$created->id}");
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Failed to save dynamic handler.';
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id={$id}" : '/admin/page/favorite-web-tools-dynamic-handlers?action=create');
        }
    }

    private function exportHandler(int $id): Response
    {
        $handler = $this->repo->findById($id);
        if (!$handler) {
            $_SESSION['flash_error'] = 'Dynamic handler not found.';
            return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers');
        }
        $package = [
            'format' => 'favorite-web-tools/dynamic-handler',
            'format_version' => 1,
            'handler' => [
                'handler_id' => $handler->handler_id,
                'name' => $handler->name,
                'description' => $handler->description,
                'status' => $handler->status,
                'definition' => $handler->definition,
            ],
        ];
        $json = json_encode($package, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return new Response((string)$json, 200, [
            'Content-Type' => 'application/json; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="fwt-handler-' . preg_replace('/[^a-z0-9_-]+/i','-', $handler->handler_id) . '.json"',
            'Content-Length' => (string)strlen((string)$json),
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    private function importHandler(Request $request): Response
    {
        try {
            $raw = trim((string)$request->post('package_json', ''));
            $tmp = $_FILES['handler_package']['tmp_name'] ?? '';
            if ($raw === '' && $tmp !== '' && is_file($tmp)) {
                if ((int)($_FILES['handler_package']['size'] ?? 0) > 1024 * 1024) throw new \RuntimeException('Handler package exceeds 1 MB.');
                $raw = (string)file_get_contents($tmp);
            }
            $package = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
            $data = is_array($package['handler'] ?? null) ? $package['handler'] : $package;
            if (!is_array($data)) throw new \InvalidArgumentException('Invalid Dynamic Handler package.');
            $base = strtolower(trim((string)preg_replace('/[^a-z0-9_-]+/i','_', (string)($data['handler_id'] ?? 'imported_handler')), '_-')) ?: 'imported_handler';
            $hid = $base; $n = 2;
            while ($this->repo->findByHandlerId($hid) || PhpHandlerRegistry::has($hid)) $hid = $base . '_' . $n++;
            $definition = is_array($data['definition'] ?? null) ? $data['definition'] : [];
            $errors = $this->runtime->validateDefinition($definition);
            if ($errors !== []) throw new \RuntimeException(implode(' ', $errors));
            $created = $this->repo->create([
                'handler_id' => $hid,
                'name' => trim((string)($data['name'] ?? 'Imported Handler')),
                'description' => (string)($data['description'] ?? ''),
                'status' => 'disabled', // explicit review/enable after import
                'definition' => $definition,
            ]);
            PhpHandlerRegistry::register(new ConfiguredToolHandler($created, $this->runtime));
            $_SESSION['flash_success'] = "Dynamic handler imported as DISABLED '{$created->name}'. Review before enabling.";
            return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id=' . (int)$created->id);
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Handler import failed: ' . $e->getMessage();
            return Response::redirect('/admin/page/favorite-web-tools-dynamic-handlers');
        }
    }

    private function isAuthorized(): bool
    {
        if (isset($GLOBALS['_test_current_user'])) {
            $u = $GLOBALS['_test_current_user'];
            if (method_exists($u, 'can') && $u->can('manage_options')) {
                return true;
            }
        }

        $userId = (int)($_SESSION['auth_user_id'] ?? 0);
        if ($userId > 0 && class_exists(User::class)) {
            try {
                $user = User::find($userId);
                if ($user && method_exists($user, 'can') && $user->can('manage_options')) {
                    return true;
                }
            } catch (Throwable) {
            }
        }

        if (function_exists('current_user_can')) {
            try {
                return current_user_can('manage_options');
            } catch (Throwable) {
            }
        }
        return false;
    }
}

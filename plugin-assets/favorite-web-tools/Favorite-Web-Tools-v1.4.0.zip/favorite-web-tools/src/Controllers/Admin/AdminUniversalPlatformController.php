<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Controllers\Admin;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\User;
use FavoriteCMS\Tools\Models\DynamicOperation;
use FavoriteCMS\Tools\Repositories\AssetRepository;
use FavoriteCMS\Tools\Repositories\DynamicOperationRepository;
use FavoriteCMS\Tools\Repositories\ExecutionLogRepository;
use FavoriteCMS\Tools\Repositories\LibraryRepository;
use FavoriteCMS\Tools\Repositories\SecretRepository;
use FavoriteCMS\Tools\Services\DynamicOperationRuntime;
use FavoriteCMS\Tools\Services\SecretVaultService;
use FavoriteCMS\Tools\Services\SystemHealthService;
use FavoriteCMS\Tools\Support\CsrfGuard;
use FavoriteCMS\Tools\Support\ViewRenderer;
use Throwable;

final class AdminUniversalPlatformController
{
    public function __construct(
        private Application $app,
        private DynamicOperationRepository $operations,
        private SecretRepository $secrets,
        private SecretVaultService $vault,
        private LibraryRepository $libraries,
        private AssetRepository $assets,
        private ExecutionLogRepository $logs,
        private SystemHealthService $health,
        private DynamicOperationRuntime $operationRuntime
    ) {}

    public function handle(Request $request, string $section): Response|string
    {
        if (!$this->isAuthorized()) return Response::make('<h1>403 Access Denied</h1>', 403);
        if ($request->method() === 'POST') {
            if (!CsrfGuard::verify($request)) return Response::make('<h1>403 Forbidden</h1><p>Invalid security token.</p>',403);
            return $this->post($request,$section);
        }
        return $this->get($request,$section);
    }

    private function get(Request $request,string $section):Response|string
    {
        $action=(string)$request->get('action','index');$id=(int)$request->get('id',0);
        return match($section){
            'operations'=>$this->operationsGet($action,$id),
            'secrets'=>$this->secretsGet($action,$id),
            'libraries'=>$this->librariesGet($action,$id),
            'assets'=>$this->assetsGet($action,$id),
            'logs'=>ViewRenderer::render('admin/execution-logs/index',['logs'=>$this->logs->recent(300),'csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error')]),
            'health'=>ViewRenderer::render('admin/system-health/index',['checks'=>$this->health->report()]),
            default=>Response::make('<h1>404</h1>',404),
        };
    }

    private function post(Request $r,string $section):Response
    {
        return match($section){
            'operations'=>$this->operationsPost($r),
            'secrets'=>$this->secretsPost($r),
            'libraries'=>$this->librariesPost($r),
            'assets'=>$this->assetsPost($r),
            'logs'=>$this->logsPost($r),
            default=>Response::redirect('/admin/page/favorite-web-tools'),
        };
    }

    private function operationsGet(string $action,int $id):Response|string
    {
        if($action==='export'){
            $op=$this->operations->find($id);if(!$op){$_SESSION['flash_error']='Operation not found.';return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations');}
            $package=['format'=>'favorite-web-tools/dynamic-operation','format_version'=>1,'operation'=>$op->toArray()];unset($package['operation']['id'],$package['operation']['created_at'],$package['operation']['updated_at']);
            $json=json_encode($package,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
            return new Response((string)$json,200,['Content-Type'=>'application/json; charset=utf-8','Content-Disposition'=>'attachment; filename="fwt-operation-'.preg_replace('/[^a-z0-9_-]+/i','-',$op->operation_id).'.json"','Content-Length'=>(string)strlen((string)$json),'X-Content-Type-Options'=>'nosniff']);
        }
        if(in_array($action,['create','edit','test'],true)){
            $op=$id>0?$this->operations->find($id):new DynamicOperation(['executor_type'=>'BUILTIN','status'=>'active','configuration'=>['capability'=>'transform','operation'=>'trim']]);
            if(!$op)$op=new DynamicOperation();
            return ViewRenderer::render('admin/dynamic-operations/form',['operation'=>$op,'isTest'=>$action==='test','csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error'),'lastResult'=>$_SESSION['fwt_operation_test_result']??null]);
        }
        return ViewRenderer::render('admin/dynamic-operations/index',['operations'=>$this->operations->all(),'csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error')]);
    }

    private function operationsPost(Request $r):Response
    {
        $action=(string)$r->post('action','save');$id=(int)$r->post('id',0);
        if($action==='import'){
            try{$raw=trim((string)$r->post('package_json',''));$tmp=$_FILES['operation_package']['tmp_name']??'';if($raw===''&&$tmp!==''&&is_file($tmp)){$raw=(string)file_get_contents($tmp);} $pkg=json_decode($raw,true,512,JSON_THROW_ON_ERROR);$d=is_array($pkg['operation']??null)?$pkg['operation']:$pkg;if(!is_array($d))throw new \InvalidArgumentException('Invalid operation package.');$base=strtolower(trim((string)preg_replace('/[^a-z0-9_\-.]+/i','_', (string)($d['operation_id']??'imported_operation')),'_-'));if($base==='')$base='imported_operation';$oid=$base;$n=2;while($this->operations->findByOperationId($oid))$oid=$base.'_'.$n++;$created=$this->operations->create(['operation_id'=>$oid,'name'=>trim((string)($d['name']??'Imported Operation')),'description'=>(string)($d['description']??''),'executor_type'=>strtoupper((string)($d['executor_type']??'BUILTIN')),'status'=>'disabled','parameter_schema'=>is_array($d['parameter_schema']??null)?$d['parameter_schema']:[],'configuration'=>is_array($d['configuration']??null)?$d['configuration']:[]]);$_SESSION['flash_success']="Operation imported as DISABLED '{$created->name}'. Review before enabling.";return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations?action=edit&id='.(int)$created->id);}catch(Throwable $e){$_SESSION['flash_error']='Operation import failed: '.$e->getMessage();return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations');}
        }
        if($action==='delete'){$this->operations->delete($id);$_SESSION['flash_success']='Dynamic Operation deleted.';return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations');}
        if($action==='test'){
            $op=$this->operations->find($id);if(!$op){$_SESSION['flash_error']='Operation not found.';return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations');}
            $input=json_decode((string)$r->post('test_input','{}'),true);if(!is_array($input))$input=['input'=>(string)$r->post('test_input','')];$current=$input['current']??$input['input']??$input;$res=$this->operationRuntime->execute($op,$current,[],$input,['tool_slug'=>'admin-operation-test']);$_SESSION['fwt_operation_test_result']=$res;return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations?action=test&id='.$id);
        }
        $operationId=strtolower(trim((string)$r->post('operation_id','')));$operationId=preg_replace('/[^a-z0-9_\-.]+/','_',$operationId)??'';$name=trim((string)$r->post('name',''));
        if($operationId===''||$name===''){$_SESSION['flash_error']='Name and Operation ID are required.';return Response::redirect($id?'/admin/page/favorite-web-tools-dynamic-operations?action=edit&id='.$id:'/admin/page/favorite-web-tools-dynamic-operations?action=create');}
        $cfg=json_decode((string)$r->post('configuration','{}'),true);$schema=json_decode((string)$r->post('parameter_schema','{}'),true);if(!is_array($cfg)||!is_array($schema)){$_SESSION['flash_error']='Configuration and Parameter Schema must be valid JSON.';return Response::redirect($id?'/admin/page/favorite-web-tools-dynamic-operations?action=edit&id='.$id:'/admin/page/favorite-web-tools-dynamic-operations?action=create');}
        $payload=['operation_id'=>$operationId,'name'=>$name,'description'=>trim((string)$r->post('description','')),'executor_type'=>strtoupper((string)$r->post('executor_type','BUILTIN')),'status'=>(string)$r->post('status','active'),'configuration'=>$cfg,'parameter_schema'=>$schema];
        try{$op=$id?$this->operations->update($id,$payload):$this->operations->create($payload);$_SESSION['flash_success']='Dynamic Operation saved.';return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations'.($id?'?action=edit&id='.$id:''));}catch(Throwable $e){$_SESSION['flash_error']='Unable to save operation: '.$e->getMessage();return Response::redirect('/admin/page/favorite-web-tools-dynamic-operations');}
    }

    private function secretsGet(string $action,int $id):string
    {
        $record=$id?$this->secrets->find($id):null;
        return ViewRenderer::render('admin/secrets/index',['records'=>$this->secrets->all(),'edit'=>$action==='edit'?$record:null,'csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error')]);
    }
    private function secretsPost(Request $r):Response
    {
        $action=(string)$r->post('action','save');$id=(int)$r->post('id',0);if($action==='delete'){$this->secrets->delete($id);$_SESSION['flash_success']='Secret deleted.';return Response::redirect('/admin/page/favorite-web-tools-secrets');}
        $key=strtoupper(trim((string)$r->post('secret_key','')));$label=trim((string)$r->post('label',$key));$value=(string)$r->post('secret_value','');$scopeRaw=(string)$r->post('scope','{}');$scope=json_decode($scopeRaw,true);if(!is_array($scope))$scope=[];
        try{$this->vault->store($key,$label,$value,$scope,(string)$r->post('status','active'),$id);$_SESSION['flash_success']='Secret saved. Value remains server-side and encrypted.';}catch(Throwable $e){$_SESSION['flash_error']=$e->getMessage();}
        return Response::redirect('/admin/page/favorite-web-tools-secrets');
    }

    private function librariesGet(string $action,int $id):string{return ViewRenderer::render('admin/libraries/index',['records'=>$this->libraries->all(),'edit'=>$action==='edit'?$this->libraries->find($id):null,'csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error')]);}
    private function librariesPost(Request $r):Response
    {
        $action=(string)$r->post('action','save');$id=(int)$r->post('id',0);if($action==='delete'){$this->libraries->delete($id);return Response::redirect('/admin/page/favorite-web-tools-libraries');}
        $caps=preg_split('/[\s,]+/',trim((string)$r->post('capabilities','')),-1,PREG_SPLIT_NO_EMPTY)?:[];$cfg=json_decode((string)$r->post('configuration','{}'),true);if(!is_array($cfg))$cfg=[];
        $this->libraries->save(['library_key'=>trim((string)$r->post('library_key','')),'name'=>trim((string)$r->post('name','')),'library_type'=>strtoupper((string)$r->post('library_type','PHP')),'package_name'=>trim((string)$r->post('package_name','')),'version'=>trim((string)$r->post('version','')),'capabilities'=>$caps,'configuration'=>$cfg,'status'=>(string)$r->post('status','active')],$id);$_SESSION['flash_success']='Library registration saved.';return Response::redirect('/admin/page/favorite-web-tools-libraries');
    }

    private function assetsGet(string $action,int $id):string{return ViewRenderer::render('admin/assets/index',['records'=>$this->assets->all(),'edit'=>$action==='edit'?$this->assets->find($id):null,'csrfToken'=>CsrfGuard::token(),'flashSuccess'=>$this->flash('flash_success'),'flashError'=>$this->flash('flash_error')]);}
    private function assetsPost(Request $r):Response
    {
        $action=(string)$r->post('action','save');$id=(int)$r->post('id',0);if($action==='delete'){$this->assets->delete($id);return Response::redirect('/admin/page/favorite-web-tools-assets');}
        $url=trim((string)$r->post('url',''));if($url!==''&&!str_starts_with($url,'/')&&(!filter_var($url,FILTER_VALIDATE_URL)||!str_starts_with(strtolower($url),'https://'))){$_SESSION['flash_error']='Frontend CDN assets must use HTTPS or a local / path.';return Response::redirect('/admin/page/favorite-web-tools-assets');}
        $cfg=json_decode((string)$r->post('configuration','{}'),true);if(!is_array($cfg))$cfg=[];
        $this->assets->save(['asset_key'=>trim((string)$r->post('asset_key','')),'name'=>trim((string)$r->post('name','')),'asset_type'=>strtoupper((string)$r->post('asset_type','JS')),'source_type'=>strtoupper((string)$r->post('source_type','CDN')),'url'=>$url,'integrity'=>trim((string)$r->post('integrity','')),'crossorigin'=>trim((string)$r->post('crossorigin','')),'load_order'=>(int)$r->post('load_order',100),'configuration'=>$cfg,'status'=>(string)$r->post('status','active')],$id);$_SESSION['flash_success']='Frontend asset saved.';return Response::redirect('/admin/page/favorite-web-tools-assets');
    }

    private function logsPost(Request $r):Response{if((string)$r->post('action','')==='cleanup'){$days=max(1,(int)$r->post('days',30));$this->logs->cleanup($days);$_SESSION['flash_success']='Old execution logs cleaned.';}return Response::redirect('/admin/page/favorite-web-tools-execution-logs');}
    private function flash(string $key):mixed{$v=$_SESSION[$key]??null;unset($_SESSION[$key]);return$v;}

    private function isAuthorized():bool
    {
        if(isset($GLOBALS['_test_current_user'])){$u=$GLOBALS['_test_current_user'];if(method_exists($u,'can')&&$u->can('manage_options'))return true;}
        $userId=(int)($_SESSION['auth_user_id']??0);if($userId>0&&class_exists(User::class)){try{$u=User::find($userId);if($u&&method_exists($u,'can')&&$u->can('manage_options'))return true;}catch(Throwable){}}
        if(function_exists('current_user_can')){try{return current_user_can('manage_options');}catch(Throwable){}}
        return false;
    }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Controllers\Admin;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\User;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Repositories\CategoryRepository;
use FavoriteCMS\Tools\Repositories\FrontendDesignRepository;
use FavoriteCMS\Tools\Repositories\DynamicHandlerRepository;
use FavoriteCMS\Tools\Repositories\PythonServiceRepository;
use FavoriteCMS\Tools\Repositories\ToolRepository;
use FavoriteCMS\Tools\Services\ToolExecutionService;
use FavoriteCMS\Tools\Support\CsrfGuard;
use FavoriteCMS\Tools\Support\ViewRenderer;
use Throwable;

class AdminToolController
{
    protected Application $app;
    protected ToolRepository $toolRepo;
    protected CategoryRepository $categoryRepo;
    protected PythonServiceRepository $pythonRepo;
    protected ToolExecutionService $executionService;
    protected ?FrontendDesignRepository $designRepo;
    protected ?DynamicHandlerRepository $dynamicHandlerRepo;

    public function __construct(
        Application $app,
        ToolRepository $toolRepo,
        CategoryRepository $categoryRepo,
        PythonServiceRepository $pythonRepo,
        ToolExecutionService $executionService,
        ?FrontendDesignRepository $designRepo = null,
        ?DynamicHandlerRepository $dynamicHandlerRepo = null
    ) {
        $this->app = $app;
        $this->toolRepo = $toolRepo;
        $this->categoryRepo = $categoryRepo;
        $this->pythonRepo = $pythonRepo;
        $this->executionService = $executionService;
        $this->designRepo = $designRepo ?? ($app->has(FrontendDesignRepository::class) ? $app->make(FrontendDesignRepository::class) : null);
        $this->dynamicHandlerRepo = $dynamicHandlerRepo ?? ($app->has(DynamicHandlerRepository::class) ? $app->make(DynamicHandlerRepository::class) : null);
    }

    public function handle(Request $request): Response|string
    {
        if (!$this->isAuthorized()) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage tools.</p>', 403);
        }

        if ($request->method() === 'POST') {
            return $this->handlePost($request);
        }

        return $this->handleGet($request);
    }

    protected function handleGet(Request $request): Response|string
    {
        $action = (string)$request->get('action', 'index');
        $id = (int)$request->get('id', 0);

        return match ($action) {
            'create' => $this->createForm($request),
            'edit'   => $this->editForm($request, $id),
            'test'   => $this->testScreen($request, $id),
            'export' => $this->exportTool($request, $id),
            default  => $this->index($request),
        };
    }

    protected function handlePost(Request $request): Response
    {
        if (!CsrfGuard::verify($request)) {
            $_SESSION['flash_error'] = 'Security token invalid or expired (CSRF failure). Please try again.';
            return Response::redirect('/admin/page/favorite-web-tools');
        }

        $action = (string)$request->post('action', 'save');
        $id = (int)$request->post('id', 0);

        return match ($action) {
            'save'         => $this->saveTool($request, $id),
            'activate'     => $this->activateTool($request, $id),
            'disable'      => $this->disableTool($request, $id),
            'delete'       => $this->deleteTool($request, $id),
            'duplicate'    => $this->duplicateTool($request, $id),
            'import'       => $this->importTool($request),
            'restore_revision' => $this->restoreRevision($request, $id),
            'execute_test' => $this->executeTest($request, $id),
            default        => Response::redirect('/admin/page/favorite-web-tools'),
        };
    }

    public function index(Request $request): string
    {
        $search = trim((string)$request->get('search', ''));
        $status = trim((string)$request->get('status', ''));
        $catId = (int)$request->get('category_id', 0);

        $allTools = $this->toolRepo->all();
        $counts = [
            'all'      => count($allTools),
            'active'   => count(array_filter($allTools, fn($t) => $t->isActive())),
            'draft'    => count(array_filter($allTools, fn($t) => $t->isDraft())),
            'disabled' => count(array_filter($allTools, fn($t) => $t->isDisabled())),
        ];

        // Filter
        $filteredTools = array_filter($allTools, function ($t) use ($search, $status, $catId) {
            if ($status !== '' && strtolower($t->status) !== strtolower($status)) {
                return false;
            }
            if ($catId > 0 && $t->category_id !== $catId) {
                return false;
            }
            if ($search !== '') {
                $term = strtolower($search);
                $nameMatch = str_contains(strtolower($t->name), $term);
                $slugMatch = str_contains(strtolower($t->slug), $term);
                $descMatch = str_contains(strtolower($t->description ?? ''), $term);
                if (!$nameMatch && !$slugMatch && !$descMatch) {
                    return false;
                }
            }
            return true;
        });

        // Map categories for quick display
        $categories = $this->categoryRepo->all();
        $categoryMap = [];
        foreach ($categories as $cat) {
            $categoryMap[$cat->id] = $cat->name;
        }

        $flashSuccess = $_SESSION['flash_success'] ?? null;
        $flashError   = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);

        return ViewRenderer::render('admin/tools/index', [
            'tools'        => array_values($filteredTools),
            'counts'       => $counts,
            'categories'   => $categories,
            'categoryMap'  => $categoryMap,
            'statusFilter' => $status !== '' ? $status : null,
            'catFilter'    => $catId > 0 ? $catId : null,
            'search'       => $search,
            'csrfToken'    => CsrfGuard::token(),
            'flashSuccess' => $flashSuccess,
            'flashError'   => $flashError,
        ]);
    }

    public function createForm(Request $request): string
    {
        $categories = $this->categoryRepo->all();
        $pythonServices = $this->pythonRepo->allActive();
        $registeredHandlers = $this->getAvailableHandlers();

        $tool = new Tool([
            'engine'        => 'PHP',
            'access_mode'   => 'FREE',
            'status'        => 'DRAFT',
            'display_order' => 0,
            'input_schema'  => [],
            'output_schema' => [],
            'ui_schema'     => [],
        ]);

        $flashError = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_error']);

        $designs = $this->getActiveDesigns();

        return ViewRenderer::render('admin/tools/form', [
            'tool'               => $tool,
            'categories'         => $categories,
            'pythonServices'     => $pythonServices,
            'registeredHandlers' => $registeredHandlers,
            'designs'            => $designs,
            'csrfToken'          => CsrfGuard::token(),
            'isEdit'             => false,
            'flashError'         => $flashError,
        ]);
    }

    public function editForm(Request $request, int $id): Response|string
    {
        $tool = $this->toolRepo->find($id);
        if ($tool === null) {
            $_SESSION['flash_error'] = "Tool #{$id} was not found.";
            return Response::redirect('/admin/page/favorite-web-tools');
        }

        $categories = $this->categoryRepo->all();
        $pythonServices = $this->pythonRepo->allActive();
        if ($tool->python_service_id) {
            $hasCurrent = false;
            foreach ($pythonServices as $ps) {
                if ($ps->id === $tool->python_service_id) {
                    $hasCurrent = true;
                    break;
                }
            }
            if (!$hasCurrent) {
                $currentSrv = $this->pythonRepo->findById((int)$tool->python_service_id);
                if ($currentSrv) {
                    $pythonServices[] = $currentSrv;
                }
            }
        }
        $registeredHandlers = $this->getAvailableHandlers();
        $designs = $this->getActiveDesigns();

        $flashSuccess = $_SESSION['flash_success'] ?? null;
        $flashError   = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);

        return ViewRenderer::render('admin/tools/form', [
            'tool'               => $tool,
            'categories'         => $categories,
            'pythonServices'     => $pythonServices,
            'registeredHandlers' => $registeredHandlers,
            'designs'            => $designs,
            'csrfToken'          => CsrfGuard::token(),
            'isEdit'             => true,
            'flashSuccess'       => $flashSuccess,
            'flashError'         => $flashError,
            'revisions'          => $this->toolRepo->getRevisions($id, 20),
        ]);
    }

    public function testScreen(Request $request, int $id): Response|string
    {
        $tool = $this->toolRepo->find($id);
        if ($tool === null) {
            $_SESSION['flash_error'] = "Tool #{$id} was not found.";
            return Response::redirect('/admin/page/favorite-web-tools');
        }

        $flashSuccess = $_SESSION['flash_success'] ?? null;
        $flashError   = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);

        return ViewRenderer::render('admin/tools/test', [
            'tool'         => $tool,
            'csrfToken'    => CsrfGuard::token(),
            'flashSuccess' => $flashSuccess,
            'flashError'   => $flashError,
        ]);
    }

    protected function saveTool(Request $request, int $id): Response
    {
        $name = trim((string)$request->post('name', ''));
        $slug = trim((string)$request->post('slug', ''));
        $description = trim((string)$request->post('description', ''));
        $categoryId = (int)$request->post('category_id', 0) ?: null;
        $engine = strtoupper(trim((string)$request->post('engine', 'PHP')));
        $handlerId = trim((string)$request->post('handler_id', ''));
        $handlerClass = trim((string)$request->post('handler_class', ''));

        // Map core registered handler IDs to their class. Dynamic handlers deliberately keep
        // handler_class empty and are resolved by handler_id through DynamicHandlerRepository.
        if ($handlerId !== '' && \FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::has($handlerId)) {
            $handlerInstance = \FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::get($handlerId);
            if ($handlerInstance) {
                $handlerClass = get_class($handlerInstance);
            }
        } elseif ($handlerId !== '' && $this->dynamicHandlerRepo?->findByHandlerId($handlerId)) {
            $handlerClass = '';
        } elseif ($handlerClass !== '') {
            foreach (\FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::listHandlers() as $hid => $hname) {
                $h = \FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::get($hid);
                if ($h && get_class($h) === $handlerClass) {
                    $handlerId = $hid;
                    break;
                }
            }
        }

        $htmlSource = (string)$request->post('html_source', '');
        $cssSource = (string)$request->post('css_source', '');
        $jsSource = (string)$request->post('js_source', '');

        // Parse external libraries (one per line, validate http/https)
        $rawLibs = (string)$request->post('external_libraries', '');
        $externalLibs = [];
        if (trim($rawLibs) !== '') {
            $lines = preg_split('/[\r\n]+/', $rawLibs);
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '') {
                    continue;
                }
                if (preg_match('/^https?:\/\//i', $line) && filter_var($line, FILTER_VALIDATE_URL)) {
                    $externalLibs[] = $line;
                }
            }
        }

        $pythonServiceId = (int)$request->post('python_service_id', 0) ?: null;
        $pythonEndpoint = trim((string)$request->post('python_endpoint', ''));
        $httpApiUrl = trim((string)$request->post('http_api_url', ''));
        $httpApiMethod = strtoupper(trim((string)$request->post('http_api_method', 'POST')));
        $httpBodyMode = strtolower(trim((string)$request->post('http_body_mode', 'json')));
        $httpResponsePath = trim((string)$request->post('http_response_path', ''));
        $httpTimeout = max(1, min(30, (int)$request->post('http_timeout', 15)));
        $dynamicPhpSource = (string)$request->post('dynamic_php_source', '');
        $dynamicPhpTimeout = max(1, min(15, (int)$request->post('dynamic_php_timeout', 5)));
        $dynamicPhpMemoryMb = max(16, min(128, (int)$request->post('dynamic_php_memory_mb', 64)));
        $dynamicPhpOutputLimitKb = max(64, min(2048, (int)$request->post('dynamic_php_output_limit_kb', 512)));
        $rateLimitPerMinute = max(0, min(10000, (int)$request->post('rate_limit_per_minute', 0)));
        $maxBulkItems = max(1, min(100000, (int)$request->post('max_bulk_items', 100)));
        $maxUploadSizeMb = max(1, min(1024, (int)$request->post('max_upload_size_mb', 10)));
        $maxOutputSizeMb = max(1, min(1024, (int)$request->post('max_output_size_mb', 20)));
        $assetKeys = array_values(array_filter(array_map('trim', preg_split('/[\s,]+/', (string)$request->post('asset_keys', ''), -1, PREG_SPLIT_NO_EMPTY) ?: [])));
        $libraryKeys = array_values(array_filter(array_map('trim', preg_split('/[\s,]+/', (string)$request->post('library_keys', ''), -1, PREG_SPLIT_NO_EMPTY) ?: [])));
        $rawHttpHeaders = trim((string)$request->post('http_api_headers', ''));
        $rawHttpMapping = trim((string)$request->post('http_request_mapping', ''));
        $rawAllowedHosts = trim((string)$request->post('http_allowed_hosts', ''));
        $httpApiHeaders = [];
        $httpRequestMapping = [];
        $httpAllowedHosts = [];

        if ($rawHttpHeaders !== '') {
            $decoded = json_decode($rawHttpHeaders, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                $_SESSION['flash_error'] = 'Invalid JSON in HTTP API Headers: ' . json_last_error_msg();
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $httpApiHeaders = $decoded;
        }

        if ($rawHttpMapping !== '') {
            $decoded = json_decode($rawHttpMapping, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                $_SESSION['flash_error'] = 'Invalid JSON in HTTP Request Mapping: ' . json_last_error_msg();
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $httpRequestMapping = $decoded;
        }

        if ($rawAllowedHosts !== '') {
            $httpAllowedHosts = array_values(array_filter(array_map(
                static fn(string $v): string => strtolower(trim($v)),
                preg_split('/[\s,]+/', $rawAllowedHosts, -1, PREG_SPLIT_NO_EMPTY) ?: []
            )));
        }
        $accessMode = strtoupper(trim((string)$request->post('access_mode', 'FREE')));
        $status = strtoupper(trim((string)$request->post('status', 'DRAFT')));
        $icon = trim((string)$request->post('icon', ''));
        $thumbnail = trim((string)$request->post('thumbnail', ''));
        $displayOrder = (int)$request->post('display_order', 0);

        // Validate JSON schemas
        $rawInput = trim((string)$request->post('input_schema', ''));
        $rawOutput = trim((string)$request->post('output_schema', ''));
        $rawUi = trim((string)$request->post('ui_schema', ''));

        if ($rawInput !== '' && $rawInput !== '{}' && $rawInput !== '[]') {
            $decoded = json_decode($rawInput, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                $_SESSION['flash_error'] = 'Invalid JSON in Input Schema: ' . json_last_error_msg();
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $inputSchema = $decoded;
        } else {
            $inputSchema = [];
        }

        if ($rawOutput !== '' && $rawOutput !== '{}' && $rawOutput !== '[]') {
            $decoded = json_decode($rawOutput, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                $_SESSION['flash_error'] = 'Invalid JSON in Output Schema: ' . json_last_error_msg();
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $outputSchema = $decoded;
        } else {
            $outputSchema = [];
        }

        if ($rawUi !== '' && $rawUi !== '{}' && $rawUi !== '[]') {
            $decoded = json_decode($rawUi, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                $_SESSION['flash_error'] = 'Invalid JSON in UI Schema: ' . json_last_error_msg();
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $uiSchema = $decoded;
        } else {
            $uiSchema = [];
        }

        if ($name === '') {
            $_SESSION['flash_error'] = 'Tool Name is required.';
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
        }

        if ($engine === 'PHP') {
            if ($handlerId === '' && $handlerClass === '') {
                $_SESSION['flash_error'] = 'Please select a registered or dynamic controlled handler.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            if ($handlerId !== ''
                && !\FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::has($handlerId)
                && !($this->dynamicHandlerRepo?->findByHandlerId($handlerId)?->isActive())) {
                $_SESSION['flash_error'] = "Controlled handler '{$handlerId}' is not registered or active.";
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
        }

        if ($engine === 'DYNAMIC_PHP') {
            $runtime = new \FavoriteCMS\Tools\Services\DynamicPhpRuntimeService();
            $runtimeErrors = $runtime->validateSource($dynamicPhpSource);
            if ($runtimeErrors !== []) {
                $_SESSION['flash_error'] = implode(' ', $runtimeErrors);
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
        }

        if ($engine === 'PYTHON_API') {
            if (empty($pythonServiceId)) {
                $_SESSION['flash_error'] = 'Please select an active Python API Service for this tool.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }

            $service = $this->pythonRepo->findById($pythonServiceId);
            if ($service === null || !$service->isActive()) {
                $_SESSION['flash_error'] = 'The selected Python API Service is invalid or disabled.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }

            if ($pythonEndpoint === '') {
                $pythonEndpoint = $service->default_endpoint_path ?: '/download/api';
            }

            if (preg_match('#^https?://#i', $pythonEndpoint)) {
                $endpointHost = strtolower((string)parse_url($pythonEndpoint, PHP_URL_HOST));
                $serviceHost  = strtolower((string)parse_url($service->base_url, PHP_URL_HOST));
                if ($endpointHost !== '' && $endpointHost !== $serviceHost) {
                    $_SESSION['flash_error'] = "The endpoint URL host '{$endpointHost}' does not match the configured service host '{$serviceHost}'. Host override is forbidden.";
                    return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
                }
                $path = parse_url($pythonEndpoint, PHP_URL_PATH) ?? '/';
                $query = parse_url($pythonEndpoint, PHP_URL_QUERY);
                $pythonEndpoint = $path . ($query ? '?' . $query : '');
            }

            if (!str_starts_with($pythonEndpoint, '/')) {
                $pythonEndpoint = '/' . $pythonEndpoint;
            }
        }

        if ($engine === 'HTTP_API') {
            if ($httpApiUrl === '' || !filter_var($httpApiUrl, FILTER_VALIDATE_URL)) {
                $_SESSION['flash_error'] = 'Please enter a valid HTTP API URL.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            $scheme = strtolower((string)parse_url($httpApiUrl, PHP_URL_SCHEME));
            if (!in_array($scheme, ['http', 'https'], true)) {
                $_SESSION['flash_error'] = 'Only HTTP/HTTPS API URLs are allowed.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            if (!in_array($httpApiMethod, ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], true)) {
                $_SESSION['flash_error'] = 'Unsupported HTTP API method.';
                return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
            }
            if (!in_array($httpBodyMode, ['json', 'form', 'multipart'], true)) {
                $httpBodyMode = 'json';
            }
        }

        if ($slug === '') {
            $slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $name), '-'));
        }

        // Validate slug uniqueness
        $existing = $this->toolRepo->findBySlug($slug);
        if ($existing !== null && $existing->id !== $id) {
            $_SESSION['flash_error'] = "Slug '{$slug}' is already in use by another tool. Please choose a unique slug.";
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
        }

        $frontendDesignSlug = trim((string)$request->post('frontend_design_slug', '')) ?: null;

        $data = [
            'name'                 => $name,
            'slug'                 => $slug,
            'description'          => $description,
            'category_id'          => $categoryId,
            'engine'               => $engine,
            'frontend_design_slug' => $frontendDesignSlug,
            'handler_class'        => $handlerClass !== '' ? $handlerClass : null,
            'handler_id'         => $handlerId !== '' ? $handlerId : null,
            'html_source'        => $htmlSource,
            'css_source'         => $cssSource,
            'js_source'          => $jsSource,
            'external_libraries' => $externalLibs,
            'python_service_id'  => $pythonServiceId,
            'python_endpoint'    => $pythonEndpoint !== '' ? $pythonEndpoint : null,
            'http_api_url'       => $httpApiUrl,
            'http_api_method'    => $httpApiMethod,
            'http_api_headers'   => $httpApiHeaders,
            'http_request_mapping' => $httpRequestMapping,
            'http_response_path' => $httpResponsePath,
            'http_allowed_hosts' => $httpAllowedHosts,
            'http_timeout'       => $httpTimeout,
            'http_body_mode'     => $httpBodyMode,
            'dynamic_php_source' => $dynamicPhpSource,
            'dynamic_php_timeout' => $dynamicPhpTimeout,
            'dynamic_php_memory_mb' => $dynamicPhpMemoryMb,
            'dynamic_php_output_limit_kb' => $dynamicPhpOutputLimitKb,
            'rate_limit_per_minute' => $rateLimitPerMinute,
            'max_bulk_items' => $maxBulkItems,
            'max_upload_size_mb' => $maxUploadSizeMb,
            'max_output_size_mb' => $maxOutputSizeMb,
            'asset_keys' => $assetKeys,
            'library_keys' => $libraryKeys,
            'access_mode'        => $accessMode,
            'status'             => $status,
            'icon'               => $icon,
            'thumbnail'          => $thumbnail,
            'display_order'      => $displayOrder,
            'input_schema'       => $inputSchema,
            'output_schema'      => $outputSchema,
            'ui_schema'          => $uiSchema,
        ];

        try {
            if ($id > 0) {
                $this->toolRepo->update($id, $data);
                $_SESSION['flash_success'] = "Tool '{$name}' was updated successfully.";
                return Response::redirect("/admin/page/favorite-web-tools?action=edit&id={$id}");
            } else {
                $created = $this->toolRepo->create($data);
                $_SESSION['flash_success'] = "Tool '{$name}' was created successfully.";
                return Response::redirect("/admin/page/favorite-web-tools?action=edit&id={$created->id}");
            }
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Failed to save tool: ' . $e->getMessage();
            return Response::redirect($id > 0 ? "/admin/page/favorite-web-tools?action=edit&id={$id}" : '/admin/page/favorite-web-tools?action=create');
        }
    }

    protected function activateTool(Request $request, int $id): Response
    {
        try {
            $this->toolRepo->updateStatus($id, 'ACTIVE');
            $_SESSION['flash_success'] = "Tool #{$id} is now ACTIVE.";
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Failed to activate tool: ' . $e->getMessage();
        }
        return Response::redirect('/admin/page/favorite-web-tools');
    }

    protected function disableTool(Request $request, int $id): Response
    {
        try {
            $this->toolRepo->updateStatus($id, 'DISABLED');
            $_SESSION['flash_success'] = "Tool #{$id} is now DISABLED.";
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Failed to disable tool: ' . $e->getMessage();
        }
        return Response::redirect('/admin/page/favorite-web-tools');
    }

    protected function deleteTool(Request $request, int $id): Response
    {
        try {
            $this->toolRepo->delete($id);
            $_SESSION['flash_success'] = "Tool #{$id} was deleted.";
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Failed to delete tool: ' . $e->getMessage();
        }
        return Response::redirect('/admin/page/favorite-web-tools');
    }

    protected function duplicateTool(Request $request, int $id): Response
    {
        try {
            $copy = $this->toolRepo->duplicate($id);
            if ($copy === null) {
                throw new \RuntimeException('Source tool not found.');
            }
            $_SESSION['flash_success'] = "Tool duplicated as '{$copy->name}'. Review the draft before publishing.";
            return Response::redirect('/admin/page/favorite-web-tools?action=edit&id=' . (int)$copy->id);
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Duplicate failed: ' . $e->getMessage();
            return Response::redirect('/admin/page/favorite-web-tools');
        }
    }

    protected function importTool(Request $request): Response
    {
        try {
            $raw = trim((string)$request->post('package_json', ''));
            $tmp = $_FILES['tool_package']['tmp_name'] ?? '';
            if ($raw === '' && $tmp !== '' && is_file($tmp)) {
                if ((int)($_FILES['tool_package']['size'] ?? 0) > 2 * 1024 * 1024) {
                    throw new \RuntimeException('Tool package is too large (2 MB max).');
                }
                $raw = (string)file_get_contents($tmp);
            }
            if ($raw === '') {
                throw new \InvalidArgumentException('Choose a tool JSON package or paste package JSON.');
            }
            $package = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($package)) {
                throw new \InvalidArgumentException('Invalid tool package JSON.');
            }
            $created = $this->toolRepo->importPackage($package, true);
            $_SESSION['flash_success'] = "Tool package imported as draft '{$created->name}'.";
            return Response::redirect('/admin/page/favorite-web-tools?action=edit&id=' . (int)$created->id);
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'Import failed: ' . $e->getMessage();
            return Response::redirect('/admin/page/favorite-web-tools');
        }
    }

    protected function exportTool(Request $request, int $id): Response
    {
        $package = $this->toolRepo->exportPackage($id);
        if ($package === []) {
            $_SESSION['flash_error'] = "Tool #{$id} was not found.";
            return Response::redirect('/admin/page/favorite-web-tools');
        }
        $slug = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($package['tool']['slug'] ?? 'tool')) ?: 'tool';
        $json = json_encode($package, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return new Response((string)$json, 200, [
            'Content-Type' => 'application/json; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="favorite-web-tool-' . $slug . '.json"',
            'Content-Length' => (string)strlen((string)$json),
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    protected function restoreRevision(Request $request, int $id): Response
    {
        $revisionNo = max(1, (int)$request->post('revision_no', 0));
        if ($this->toolRepo->restoreRevision($id, $revisionNo)) {
            $_SESSION['flash_success'] = "Revision #{$revisionNo} restored as DRAFT. Review and publish explicitly.";
        } else {
            $_SESSION['flash_error'] = "Could not restore revision #{$revisionNo}.";
        }
        return Response::redirect('/admin/page/favorite-web-tools?action=edit&id=' . $id);
    }

    protected function executeTest(Request $request, int $id): Response
    {
        $tool = $this->toolRepo->find($id);
        if ($tool === null) {
            $_SESSION['flash_error'] = "Tool #{$id} not found.";
            return Response::redirect('/admin/page/favorite-web-tools');
        }

        $rawInputs = (string)$request->post('test_inputs', '');
        $inputs = json_decode($rawInputs, true);
        if (!is_array($inputs)) {
            // Treat as single text input
            $inputs = ['text' => $rawInputs, 'code' => $rawInputs, 'input' => $rawInputs, 'html' => $rawInputs, 'css' => $rawInputs, 'json' => $rawInputs];
        }

        $userId = (int)($_SESSION['auth_user_id'] ?? 1);
        $result = $this->executionService->execute($tool->slug, $inputs, $userId, true);

        $_SESSION['last_test_result'] = $result;
        return Response::redirect("/admin/page/favorite-web-tools?action=test&id={$id}");
    }

    private function parseJsonField(mixed $val): array
    {
        if (is_array($val)) {
            return $val;
        }
        if (is_string($val) && trim($val) !== '') {
            $decoded = json_decode($val, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return [];
    }

    /**
     * @return array<\FavoriteCMS\Tools\Models\FrontendDesign>
     */
    protected function getActiveDesigns(): array
    {
        if ($this->designRepo !== null) {
            return $this->designRepo->allActive();
        }
        if ($this->app->has(FrontendDesignRepository::class)) {
            return $this->app->make(FrontendDesignRepository::class)->allActive();
        }
        return [];
    }

    /**
     * @return array<string, string>
     */
    protected function getAvailableHandlers(): array
    {
        $handlers = \FavoriteCMS\Tools\Handlers\PhpHandlerRegistry::listHandlers();
        if ($this->dynamicHandlerRepo !== null) {
            foreach ($this->dynamicHandlerRepo->all(true) as $handler) {
                // Core handlers retain priority if an administrator accidentally chooses a duplicate ID.
                if (!isset($handlers[$handler->handler_id])) {
                    $handlers[$handler->handler_id] = 'Dynamic: ' . $handler->name;
                }
            }
        }
        return $handlers;
    }

    protected function isAuthorized(): bool
    {
        if (isset($GLOBALS['_test_current_user'])) {
            $u = $GLOBALS['_test_current_user'];
            if (method_exists($u, 'can') && $u->can('manage_options')) {
                return true;
            }
        }

        $userId = (int)($_SESSION['auth_user_id'] ?? 0);
        if ($userId > 0 && class_exists(User::class)) {
            try {
                $user = User::find($userId);
                if ($user && method_exists($user, 'can') && $user->can('manage_options')) {
                    return true;
                }
            } catch (Throwable) {
            }
        }

        if (function_exists('current_user_can')) {
            try {
                return current_user_can('manage_options');
            } catch (Throwable) {
            }
        }

        return false;
    }
}


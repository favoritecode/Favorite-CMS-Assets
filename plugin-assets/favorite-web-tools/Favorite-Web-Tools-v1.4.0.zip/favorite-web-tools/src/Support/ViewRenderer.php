<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Support;

final class ViewRenderer
{
    private static string $viewsDir = '';
    private static bool $adminAssetsEmitted = false;

    public static function setViewsDir(string $dir): void
    {
        self::$viewsDir = rtrim($dir, '/\\');
    }

    public static function getViewsDir(): string
    {
        if (self::$viewsDir === '') {
            self::$viewsDir = dirname(__DIR__, 2) . '/views';
        }
        return self::$viewsDir;
    }

    public static function render(string $viewName, array $data = []): string
    {
        $path = self::getViewsDir() . '/' . ltrim($viewName, '/\\') . '.php';
        if (!is_file($path)) {
            return "<div class='fwt-error-notice'>View not found: " . htmlspecialchars($viewName, ENT_QUOTES, 'UTF-8') . "</div>";
        }

        extract($data, EXTR_SKIP);
        ob_start();
        include $path;
        $html = (string)ob_get_clean();

        // Favorite CMS admin appearance is controlled by the CMS shell, not by
        // individual plugin views. Load the Web Tools admin compatibility layer
        // centrally so every existing/new admin screen follows the same mode.
        if (str_starts_with(ltrim($viewName, '/\\'), 'admin/')) {
            $html = self::withAdminAssets($html);
        }

        return $html;
    }

    private static function withAdminAssets(string $html): string
    {
        if (self::$adminAssetsEmitted) {
            return $html;
        }

        self::$adminAssetsEmitted = true;
        $root = dirname(__DIR__, 2);
        $cssVersion = is_file($root . '/assets/css/tools-admin.css') ? (string)filemtime($root . '/assets/css/tools-admin.css') : '1';
        $jsVersion = is_file($root . '/assets/js/tools-admin.js') ? (string)filemtime($root . '/assets/js/tools-admin.js') : '1';

        return '<link rel="stylesheet" href="/plugins/favorite-web-tools/assets/css/tools-admin.css?v=' . rawurlencode($cssVersion) . '">'
            . '<script src="/plugins/favorite-web-tools/assets/js/tools-admin.js?v=' . rawurlencode($jsVersion) . '"></script>'
            . $html;
    }
}


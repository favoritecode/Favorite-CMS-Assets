<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Support;

final class EngineType
{
    public const HTML = 'HTML';
    public const CSS = 'CSS';
    public const JAVASCRIPT = 'JAVASCRIPT';
    public const PHP = 'PHP';
    public const DYNAMIC_PHP = 'DYNAMIC_PHP';
    public const PYTHON_API = 'PYTHON_API';
    public const HTTP_API = 'HTTP_API';

    public static function all(): array
    {
        return [
            self::HTML,
            self::CSS,
            self::JAVASCRIPT,
            self::PHP,
            self::DYNAMIC_PHP,
            self::PYTHON_API,
            self::HTTP_API,
        ];
    }

    public static function isValid(string $engine): bool
    {
        return in_array($engine, self::all(), true);
    }

    public static function label(string $engine): string
    {
        return match ($engine) {
            self::HTML => 'HTML Engine',
            self::CSS => 'CSS Engine',
            self::JAVASCRIPT => 'JavaScript Engine',
            self::PHP => 'PHP Controlled Handler',
            self::DYNAMIC_PHP => 'Dynamic PHP Runtime (Sandboxed)',
            self::PYTHON_API => 'Python API Engine',
            self::HTTP_API => 'Generic HTTP API Engine',
            default => $engine,
        };
    }
}


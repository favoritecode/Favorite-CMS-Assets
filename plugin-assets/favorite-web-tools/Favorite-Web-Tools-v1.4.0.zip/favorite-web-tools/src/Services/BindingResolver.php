<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

final class BindingResolver
{
    public function __construct(private ?SecretVaultService $secrets = null) {}

    public function resolve(mixed $value, array $state): mixed
    {
        if (is_array($value)) {
            $out=[]; foreach($value as $k=>$v) $out[$k]=$this->resolve($v,$state); return $out;
        }
        if (!is_string($value)) return $value;
        if (preg_match('/^\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}$/', $value, $m)) return $this->lookup($m[1],$state);
        return preg_replace_callback('/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/', function($m) use($state){$v=$this->lookup($m[1],$state); return is_scalar($v)||$v===null?(string)$v:(string)json_encode($v,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);}, $value) ?? $value;
    }

    public function truthy(mixed $condition, array $state): bool
    {
        $v=$this->resolve($condition,$state);
        if(is_bool($v)) return $v;
        if(is_numeric($v)) return (float)$v!==0.0;
        if(is_array($v)) return $v!==[];
        $s=strtolower(trim((string)$v)); return !in_array($s,['','0','false','null','no','off'],true);
    }

    private function lookup(string $path,array $state):mixed
    {
        if(str_starts_with($path,'secret.')){
            $key=substr($path,7); return $this->secrets?->resolve($key,$state['context']['tool_slug']??null,$state['context']['operation_id']??null);
        }
        if($path==='current'||$path==='value') return $state['current']??null;
        if($path==='result.count'){ $r=$state['result']??null; return is_countable($r)?count($r):(is_array($r)&&isset($r['count'])?$r['count']:0); }
        $segments=explode('.',$path); $root=array_shift($segments);
        $current=$state[$root]??null;
        foreach($segments as $seg){ if(is_array($current)&&array_key_exists($seg,$current)){$current=$current[$seg];}elseif(is_object($current)&&isset($current->{$seg})){$current=$current->{$seg};}else{return null;} }
        return $current;
    }
}

<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use RuntimeException;
use ZipArchive;

final class CapabilityService
{
    public function __construct(
        private DownloadManagerService $downloads,
        private QrCodeService $qr
    ) {}

    public function execute(string $capability, mixed $current, array $params, array $inputs = []): array
    {
        return match (strtolower($capability)) {
            'qr_generate' => $this->qrGenerate($current, $params, $inputs),
            'csv_parse' => $this->csvParse($current, $params),
            'csv_create' => $this->csvCreate($current, $params),
            'file_output' => $this->fileOutput($current, $params),
            'zip_create' => $this->zipCreate($current, $params),
            'image_resize', 'image_convert' => $this->imageResize($current, $params),
            default => ['success'=>false,'error'=>'Unknown platform capability: '.$capability],
        };
    }

    private function qrGenerate(mixed $current, array $params, array $inputs): array
    {
        $payload = $inputs;
        if (is_array($current)) {
            if (isset($current['url']) || isset($current['items']) || array_is_list($current)) {
                $payload = array_merge($payload, array_is_list($current) ? ['items'=>$current] : $current);
            }
        } elseif (is_string($current) && trim($current) !== '') {
            $payload['url'] = trim($current);
        }
        foreach (['size','qr_color','background_color','border_width','border_color','transparent','title'] as $key) {
            if (array_key_exists($key,$params)) $payload[$key]=$params[$key];
        }
        return $this->qr->generate($payload);
    }

    private function csvParse(mixed $current, array $params): array
    {
        $content = is_array($current) ? (string)($current['content'] ?? '') : (string)$current;
        if ($content === '') return ['success'=>false,'error'=>'CSV content is empty.'];
        $delimiter = (string)($params['delimiter'] ?? ',');
        if (strlen($delimiter)!==1) $delimiter=',';
        $stream=fopen('php://temp','w+b'); if(!$stream)return['success'=>false,'error'=>'Unable to open CSV parser.'];
        fwrite($stream,$content); rewind($stream); $rows=[]; $header=null; $useHeader=!array_key_exists('header',$params)||!empty($params['header']);
        while(($fields=fgetcsv($stream,null,$delimiter,'"',''))!==false){
            if($fields===[null]||$fields===[])continue;
            if($header===null&&$useHeader){$header=array_map(static fn($v)=>trim((string)$v),$fields);continue;}
            if($header!==null){$row=[];foreach($header as $i=>$key)$row[$key]=$fields[$i]??'';$rows[]=$row;}else{$rows[]=$fields;}
            if(count($rows)>10000){fclose($stream);return['success'=>false,'error'=>'CSV row limit exceeded.'];}
        }
        fclose($stream);
        return ['success'=>true,'type'=>'JSON','value'=>$rows,'data'=>$rows,'meta'=>['count'=>count($rows)]];
    }

    private function csvCreate(mixed $current, array $params): array
    {
        if(!is_array($current))return['success'=>false,'error'=>'CSV Create expects an array of rows.'];
        $stream=fopen('php://temp','w+b');if(!$stream)return['success'=>false,'error'=>'Unable to create CSV.'];
        $rows=$current; if($rows!==[]&&is_array(reset($rows))&&!array_is_list(reset($rows))){fputcsv($stream,array_keys(reset($rows)));}
        foreach($rows as $row){fputcsv($stream,is_array($row)?array_values($row):[(string)$row]);}
        rewind($stream);$csv=(string)stream_get_contents($stream);fclose($stream);
        if(!empty($params['download']))return$this->fileOutput($csv,['filename'=>$params['filename']??'result.csv','mime_type'=>'text/csv']);
        return['success'=>true,'type'=>'TEXT','value'=>$csv,'data'=>$csv];
    }

    private function fileOutput(mixed $current, array $params): array
    {
        $content = is_string($current) ? $current : (string)json_encode($current,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
        $filename=basename((string)($params['filename']??'result.txt')); if($filename==='')$filename='result.txt';
        $mime=(string)($params['mime_type']??'application/octet-stream');
        $d=$this->downloads->createDownload($content,$filename,$mime);
        $file=['name'=>$d['filename'],'url'=>$d['download_url'],'download_url'=>$d['download_url'],'size'=>$d['size'],'mime_type'=>$mime,'reference'=>$d['reference']];
        return['success'=>true,'type'=>'JSON','value'=>['files'=>[$file]],'data'=>['files'=>[$file]],'files'=>[$file]];
    }

    private function zipCreate(mixed $current, array $params): array
    {
        if(!class_exists(ZipArchive::class))return['success'=>false,'error'=>'ZipArchive extension is not available.'];
        $files=is_array($current)&&isset($current['files'])&&is_array($current['files'])?$current['files']:(is_array($current)?$current:[]);
        if($files===[])return['success'=>false,'error'=>'ZIP Create received no files.'];
        $tmp=tempnam(sys_get_temp_dir(),'fwtzip_'); if($tmp===false)return['success'=>false,'error'=>'Unable to create temporary ZIP.'];
        $zip=new ZipArchive(); if($zip->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true){@unlink($tmp);return['success'=>false,'error'=>'Unable to create ZIP archive.'];}
        $used=[];
        foreach($files as $i=>$file){
            if(!is_array($file))continue;$name=basename((string)($file['name']??('file-'.($i+1).'.txt')));$name=preg_replace('/[^A-Za-z0-9._-]+/','-',$name)?:('file-'.($i+1));$base=$name;$n=2;while(isset($used[strtolower($name)])){$ext=pathinfo($base,PATHINFO_EXTENSION);$stem=pathinfo($base,PATHINFO_FILENAME);$name=$stem.'-'.$n++.($ext!==''?'.'.$ext:'');}$used[strtolower($name)]=true;
            $content=$file['content']??null;
            if(!is_string($content)&&!empty($file['reference'])){$resolved=$this->downloads->getDownload((string)$file['reference']);$content=$resolved['content']??null;}
            if(is_string($content))$zip->addFromString($name,$content);
        }
        $zip->close();$bytes=(string)file_get_contents($tmp);@unlink($tmp);if($bytes==='')return['success'=>false,'error'=>'ZIP archive contained no usable files.'];
        return$this->fileOutput($bytes,['filename'=>$params['filename']??'files.zip','mime_type'=>'application/zip']);
    }

    private function imageResize(mixed $current, array $params): array
    {
        if(!extension_loaded('gd'))return['success'=>false,'error'=>'GD extension is required for image processing.'];
        $content=is_array($current)?($current['content']??null):null; if(!is_string($content)||$content==='')return['success'=>false,'error'=>'Image operation expects normalized uploaded image content.'];
        $src=@imagecreatefromstring($content);if(!$src)return['success'=>false,'error'=>'Unsupported or invalid image.'];
        $sw=imagesx($src);$sh=imagesy($src);$maxW=max(1,min(8000,(int)($params['width']??$sw)));$maxH=max(1,min(8000,(int)($params['height']??$sh)));$fit=strtolower((string)($params['fit']??'contain'));
        if($fit==='stretch'){$dw=$maxW;$dh=$maxH;}else{$ratio=min($maxW/$sw,$maxH/$sh);if(!empty($params['prevent_upscale']))$ratio=min(1,$ratio);$dw=max(1,(int)round($sw*$ratio));$dh=max(1,(int)round($sh*$ratio));}
        $dst=imagecreatetruecolor($dw,$dh);imagealphablending($dst,false);imagesavealpha($dst,true);$transparent=imagecolorallocatealpha($dst,0,0,0,127);imagefill($dst,0,0,$transparent);imagecopyresampled($dst,$src,0,0,0,0,$dw,$dh,$sw,$sh);
        $format=strtolower((string)($params['format']??'webp'));$quality=max(1,min(100,(int)($params['quality']??85)));ob_start();$mime='image/webp';$ext='webp';
        if($format==='png'){imagepng($dst,null,max(0,min(9,(int)round((100-$quality)/11))));$mime='image/png';$ext='png';}elseif(in_array($format,['jpg','jpeg'],true)){imagejpeg($dst,null,$quality);$mime='image/jpeg';$ext='jpg';}else{imagewebp($dst,null,$quality);}
        $bytes=(string)ob_get_clean();imagedestroy($src);imagedestroy($dst);if($bytes==='')return['success'=>false,'error'=>'Image conversion failed.'];
        return$this->fileOutput($bytes,['filename'=>$params['filename']??('image.'.$ext),'mime_type'=>$mime]);
    }
}

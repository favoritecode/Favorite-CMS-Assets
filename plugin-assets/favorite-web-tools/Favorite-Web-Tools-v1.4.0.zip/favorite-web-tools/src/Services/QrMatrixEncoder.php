<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use RuntimeException;

/**
 * Small self-contained QR Model 2 encoder used by Favorite Web Tools.
 *
 * Scope by design:
 * - Byte mode
 * - Error correction level L
 * - Versions 1-10
 *
 * This covers ordinary URLs up to the Version 10-L byte capacity while
 * avoiding a browser-side QR dependency. Longer payloads fail cleanly.
 */
final class QrMatrixEncoder
{
    /** @var array<int,array{data:int,ec:int,blocks:array<int,int>}> */
    private const VERSION_INFO = [
        1  => ['data' => 19,  'ec' => 7,  'blocks' => [19]],
        2  => ['data' => 34,  'ec' => 10, 'blocks' => [34]],
        3  => ['data' => 55,  'ec' => 15, 'blocks' => [55]],
        4  => ['data' => 80,  'ec' => 20, 'blocks' => [80]],
        5  => ['data' => 108, 'ec' => 26, 'blocks' => [108]],
        6  => ['data' => 136, 'ec' => 18, 'blocks' => [68, 68]],
        7  => ['data' => 156, 'ec' => 20, 'blocks' => [78, 78]],
        8  => ['data' => 194, 'ec' => 24, 'blocks' => [97, 97]],
        9  => ['data' => 232, 'ec' => 30, 'blocks' => [116, 116]],
        10 => ['data' => 274, 'ec' => 18, 'blocks' => [68, 68, 69, 69]],
    ];

    /** @var array<int,array<int,int>> */
    private const ALIGNMENT_POSITIONS = [
        1  => [],
        2  => [6, 18],
        3  => [6, 22],
        4  => [6, 26],
        5  => [6, 30],
        6  => [6, 34],
        7  => [6, 22, 38],
        8  => [6, 24, 42],
        9  => [6, 26, 46],
        10 => [6, 28, 50],
    ];

    /**
     * @return array<int,array<int,bool>>
     */
    public function encode(string $payload): array
    {
        if ($payload === '') {
            throw new RuntimeException('QR payload cannot be empty.');
        }

        $version = $this->chooseVersion($payload);
        $dataCodewords = $this->makeDataCodewords($payload, $version);
        $allCodewords = $this->addErrorCorrectionAndInterleave($dataCodewords, $version);

        return $this->makeMatrix($allCodewords, $version);
    }

    private function chooseVersion(string $payload): int
    {
        $length = strlen($payload);
        foreach (self::VERSION_INFO as $version => $info) {
            $countBits = $version <= 9 ? 8 : 16;
            $neededBits = 4 + $countBits + ($length * 8);
            if ($neededBits <= $info['data'] * 8) {
                return $version;
            }
        }

        throw new RuntimeException('URL is too long for the built-in QR encoder. Please use a URL of 271 bytes or fewer.');
    }

    /** @return array<int,int> */
    private function makeDataCodewords(string $payload, int $version): array
    {
        $capacityBits = self::VERSION_INFO[$version]['data'] * 8;
        $bits = [];

        // Byte mode indicator 0100.
        $this->appendBits($bits, 0b0100, 4);
        $this->appendBits($bits, strlen($payload), $version <= 9 ? 8 : 16);

        foreach (unpack('C*', $payload) ?: [] as $byte) {
            $this->appendBits($bits, (int)$byte, 8);
        }

        $remaining = $capacityBits - count($bits);
        if ($remaining < 0) {
            throw new RuntimeException('QR payload exceeds the selected symbol capacity.');
        }

        $terminator = min(4, $remaining);
        for ($i = 0; $i < $terminator; $i++) {
            $bits[] = 0;
        }

        while ((count($bits) % 8) !== 0 && count($bits) < $capacityBits) {
            $bits[] = 0;
        }

        $data = [];
        for ($i = 0; $i < count($bits); $i += 8) {
            $value = 0;
            for ($j = 0; $j < 8; $j++) {
                $value = ($value << 1) | ($bits[$i + $j] ?? 0);
            }
            $data[] = $value;
        }

        $pads = [0xEC, 0x11];
        $padIndex = 0;
        while (count($data) < self::VERSION_INFO[$version]['data']) {
            $data[] = $pads[$padIndex++ % 2];
        }

        return $data;
    }

    /** @param array<int,int> $bits */
    private function appendBits(array &$bits, int $value, int $length): void
    {
        if ($length < 0 || ($length < 31 && $value >= (1 << $length))) {
            throw new RuntimeException('Internal QR bit encoding error.');
        }
        for ($i = $length - 1; $i >= 0; $i--) {
            $bits[] = ($value >> $i) & 1;
        }
    }

    /**
     * @param array<int,int> $data
     * @return array<int,int>
     */
    private function addErrorCorrectionAndInterleave(array $data, int $version): array
    {
        $info = self::VERSION_INFO[$version];
        $ecLen = $info['ec'];
        $dataBlocks = [];
        $ecBlocks = [];
        $offset = 0;

        foreach ($info['blocks'] as $dataLen) {
            $block = array_slice($data, $offset, $dataLen);
            $offset += $dataLen;
            $dataBlocks[] = $block;
            $ecBlocks[] = $this->reedSolomonRemainder($block, $ecLen);
        }

        $result = [];
        $maxDataLen = max($info['blocks']);
        for ($i = 0; $i < $maxDataLen; $i++) {
            foreach ($dataBlocks as $block) {
                if (isset($block[$i])) {
                    $result[] = $block[$i];
                }
            }
        }

        for ($i = 0; $i < $ecLen; $i++) {
            foreach ($ecBlocks as $block) {
                $result[] = $block[$i];
            }
        }

        return $result;
    }

    /**
     * @param array<int,int> $data
     * @return array<int,int>
     */
    private function reedSolomonRemainder(array $data, int $degree): array
    {
        $generator = [1];
        $root = 1;
        for ($i = 0; $i < $degree; $i++) {
            $next = array_fill(0, count($generator) + 1, 0);
            foreach ($generator as $j => $coefficient) {
                $next[$j] ^= $coefficient;
                $next[$j + 1] ^= $this->gfMultiply($coefficient, $root);
            }
            $generator = $next;
            $root = $this->gfMultiply($root, 0x02);
        }

        $remainder = array_fill(0, $degree, 0);
        foreach ($data as $byte) {
            $factor = $byte ^ $remainder[0];
            for ($i = 0; $i < $degree - 1; $i++) {
                $remainder[$i] = $remainder[$i + 1];
            }
            $remainder[$degree - 1] = 0;

            for ($i = 0; $i < $degree; $i++) {
                $remainder[$i] ^= $this->gfMultiply($generator[$i + 1], $factor);
            }
        }

        return $remainder;
    }

    private function gfMultiply(int $x, int $y): int
    {
        $z = 0;
        while ($y > 0) {
            if (($y & 1) !== 0) {
                $z ^= $x;
            }
            $y >>= 1;
            $x <<= 1;
            if (($x & 0x100) !== 0) {
                $x ^= 0x11D;
            }
        }
        return $z & 0xFF;
    }

    /**
     * @param array<int,int> $codewords
     * @return array<int,array<int,bool>>
     */
    private function makeMatrix(array $codewords, int $version): array
    {
        $size = 21 + (($version - 1) * 4);
        $baseModules = array_fill(0, $size, array_fill(0, $size, false));
        $isFunction = array_fill(0, $size, array_fill(0, $size, false));

        $this->drawFunctionPatterns($baseModules, $isFunction, $version);

        $best = null;
        $bestPenalty = PHP_INT_MAX;
        for ($mask = 0; $mask < 8; $mask++) {
            $modules = $baseModules;
            $this->drawCodewords($modules, $isFunction, $codewords, $mask);
            $this->drawFormatBits($modules, $isFunction, $mask, false);
            if ($version >= 7) {
                $this->drawVersionBits($modules, $isFunction, $version, false);
            }
            $penalty = $this->penaltyScore($modules);
            if ($penalty < $bestPenalty) {
                $bestPenalty = $penalty;
                $best = $modules;
            }
        }

        if ($best === null) {
            throw new RuntimeException('Unable to construct QR matrix.');
        }

        return $best;
    }

    /**
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     */
    private function drawFunctionPatterns(array &$modules, array &$isFunction, int $version): void
    {
        $size = count($modules);

        // Timing patterns first; finder/alignment patterns overwrite where required.
        for ($i = 0; $i < $size; $i++) {
            $dark = ($i % 2) === 0;
            $this->setFunction($modules, $isFunction, 6, $i, $dark);
            $this->setFunction($modules, $isFunction, $i, 6, $dark);
        }

        $this->drawFinder($modules, $isFunction, 3, 3);
        $this->drawFinder($modules, $isFunction, $size - 4, 3);
        $this->drawFinder($modules, $isFunction, 3, $size - 4);

        $alignment = self::ALIGNMENT_POSITIONS[$version];
        $lastAlignment = $alignment !== [] ? $alignment[count($alignment) - 1] : null;
        foreach ($alignment as $x) {
            foreach ($alignment as $y) {
                // Skip only the three finder corners. Alignment patterns whose
                // center lies on timing row/column 6 are valid in larger symbols
                // and intentionally overwrite the timing pattern locally.
                if (($x === 6 && $y === 6)
                    || ($x === 6 && $y === $lastAlignment)
                    || ($x === $lastAlignment && $y === 6)) {
                    continue;
                }
                $this->drawAlignment($modules, $isFunction, $x, $y);
            }
        }

        // Reserve format information modules using a temporary valid value.
        $this->drawFormatBits($modules, $isFunction, 0, true);

        if ($version >= 7) {
            $this->drawVersionBits($modules, $isFunction, $version, true);
        }
    }

    /**
     * Finder pattern with one-module white separator.
     *
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     */
    private function drawFinder(array &$modules, array &$isFunction, int $cx, int $cy): void
    {
        $size = count($modules);
        for ($dy = -4; $dy <= 4; $dy++) {
            for ($dx = -4; $dx <= 4; $dx++) {
                $x = $cx + $dx;
                $y = $cy + $dy;
                if ($x < 0 || $y < 0 || $x >= $size || $y >= $size) {
                    continue;
                }
                $dist = max(abs($dx), abs($dy));
                $dark = $dist !== 2 && $dist !== 4;
                $this->setFunction($modules, $isFunction, $x, $y, $dark);
            }
        }
    }

    /** @param array<int,array<int,bool>> $modules @param array<int,array<int,bool>> $isFunction */
    private function drawAlignment(array &$modules, array &$isFunction, int $cx, int $cy): void
    {
        for ($dy = -2; $dy <= 2; $dy++) {
            for ($dx = -2; $dx <= 2; $dx++) {
                $dark = max(abs($dx), abs($dy)) !== 1;
                $this->setFunction($modules, $isFunction, $cx + $dx, $cy + $dy, $dark);
            }
        }
    }

    /**
     * Error correction level L has format bits 01.
     *
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     */
    private function drawFormatBits(array &$modules, array &$isFunction, int $mask, bool $markFunction): void
    {
        $size = count($modules);
        $data = (1 << 3) | $mask; // Level L = 01.
        $rem = $data;
        for ($i = 0; $i < 10; $i++) {
            $rem = ($rem << 1) ^ ((($rem >> 9) & 1) * 0x537);
        }
        $bits = (($data << 10) | $rem) ^ 0x5412;

        $set = function (int $x, int $y, int $bit) use (&$modules, &$isFunction, $bits, $markFunction): void {
            $value = (($bits >> $bit) & 1) !== 0;
            $modules[$y][$x] = $value;
            if ($markFunction) {
                $isFunction[$y][$x] = true;
            }
        };

        for ($i = 0; $i <= 5; $i++) {
            $set(8, $i, $i);
        }
        $set(8, 7, 6);
        $set(8, 8, 7);
        $set(7, 8, 8);
        for ($i = 9; $i < 15; $i++) {
            $set(14 - $i, 8, $i);
        }

        for ($i = 0; $i < 8; $i++) {
            $set($size - 1 - $i, 8, $i);
        }
        for ($i = 8; $i < 15; $i++) {
            $set(8, $size - 15 + $i, $i);
        }

        // Fixed dark module.
        $modules[$size - 8][8] = true;
        if ($markFunction) {
            $isFunction[$size - 8][8] = true;
        }
    }

    /**
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     */
    private function drawVersionBits(array &$modules, array &$isFunction, int $version, bool $markFunction): void
    {
        $size = count($modules);
        $rem = $version;
        for ($i = 0; $i < 12; $i++) {
            $rem = ($rem << 1) ^ ((($rem >> 11) & 1) * 0x1F25);
        }
        $bits = ($version << 12) | $rem;

        for ($i = 0; $i < 18; $i++) {
            $bit = (($bits >> $i) & 1) !== 0;
            $a = $size - 11 + ($i % 3);
            $b = intdiv($i, 3);
            $modules[$b][$a] = $bit;
            $modules[$a][$b] = $bit;
            if ($markFunction) {
                $isFunction[$b][$a] = true;
                $isFunction[$a][$b] = true;
            }
        }
    }

    /**
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     * @param array<int,int> $codewords
     */
    private function drawCodewords(array &$modules, array $isFunction, array $codewords, int $mask): void
    {
        $size = count($modules);
        $bitLength = count($codewords) * 8;
        $bitIndex = 0;
        $upward = true;

        for ($right = $size - 1; $right >= 1; $right -= 2) {
            if ($right === 6) {
                $right = 5;
            }
            for ($vert = 0; $vert < $size; $vert++) {
                $y = $upward ? ($size - 1 - $vert) : $vert;
                for ($j = 0; $j < 2; $j++) {
                    $x = $right - $j;
                    if ($isFunction[$y][$x]) {
                        continue;
                    }

                    $dark = false;
                    if ($bitIndex < $bitLength) {
                        $byte = $codewords[intdiv($bitIndex, 8)];
                        $dark = (($byte >> (7 - ($bitIndex & 7))) & 1) !== 0;
                        $bitIndex++;
                    }
                    if ($this->maskBit($mask, $x, $y)) {
                        $dark = !$dark;
                    }
                    $modules[$y][$x] = $dark;
                }
            }
            $upward = !$upward;
        }
    }

    private function maskBit(int $mask, int $x, int $y): bool
    {
        return match ($mask) {
            0 => (($x + $y) % 2) === 0,
            1 => ($y % 2) === 0,
            2 => ($x % 3) === 0,
            3 => (($x + $y) % 3) === 0,
            4 => ((intdiv($y, 2) + intdiv($x, 3)) % 2) === 0,
            5 => ((($x * $y) % 2) + (($x * $y) % 3)) === 0,
            6 => (((($x * $y) % 2) + (($x * $y) % 3)) % 2) === 0,
            7 => (((($x + $y) % 2) + (($x * $y) % 3)) % 2) === 0,
            default => false,
        };
    }

    /** @param array<int,array<int,bool>> $modules */
    private function penaltyScore(array $modules): int
    {
        $size = count($modules);
        $score = 0;

        for ($y = 0; $y < $size; $y++) {
            $runColor = $modules[$y][0];
            $runLength = 1;
            for ($x = 1; $x < $size; $x++) {
                if ($modules[$y][$x] === $runColor) {
                    $runLength++;
                    if ($runLength === 5) $score += 3;
                    elseif ($runLength > 5) $score++;
                } else {
                    $runColor = $modules[$y][$x];
                    $runLength = 1;
                }
            }
        }
        for ($x = 0; $x < $size; $x++) {
            $runColor = $modules[0][$x];
            $runLength = 1;
            for ($y = 1; $y < $size; $y++) {
                if ($modules[$y][$x] === $runColor) {
                    $runLength++;
                    if ($runLength === 5) $score += 3;
                    elseif ($runLength > 5) $score++;
                } else {
                    $runColor = $modules[$y][$x];
                    $runLength = 1;
                }
            }
        }

        for ($y = 0; $y < $size - 1; $y++) {
            for ($x = 0; $x < $size - 1; $x++) {
                $c = $modules[$y][$x];
                if ($modules[$y][$x + 1] === $c && $modules[$y + 1][$x] === $c && $modules[$y + 1][$x + 1] === $c) {
                    $score += 3;
                }
            }
        }

        $patternA = '00001011101';
        $patternB = '10111010000';
        for ($y = 0; $y < $size; $y++) {
            $row = '';
            for ($x = 0; $x < $size; $x++) $row .= $modules[$y][$x] ? '1' : '0';
            $score += 40 * (substr_count($row, $patternA) + substr_count($row, $patternB));
        }
        for ($x = 0; $x < $size; $x++) {
            $col = '';
            for ($y = 0; $y < $size; $y++) $col .= $modules[$y][$x] ? '1' : '0';
            $score += 40 * (substr_count($col, $patternA) + substr_count($col, $patternB));
        }

        $dark = 0;
        foreach ($modules as $row) {
            foreach ($row as $module) {
                if ($module) $dark++;
            }
        }
        $total = $size * $size;
        $score += intdiv(abs(($dark * 20) - ($total * 10)), $total) * 10;

        return $score;
    }

    /**
     * @param array<int,array<int,bool>> $modules
     * @param array<int,array<int,bool>> $isFunction
     */
    private function setFunction(array &$modules, array &$isFunction, int $x, int $y, bool $dark): void
    {
        $modules[$y][$x] = $dark;
        $isFunction[$y][$x] = true;
    }
}

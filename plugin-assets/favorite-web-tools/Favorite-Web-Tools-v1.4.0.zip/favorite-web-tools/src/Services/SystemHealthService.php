<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Services;
final class SystemHealthService {
 public function __construct(private DynamicPhpRuntimeService $phpRuntime){}
 public function report():array{
  $temp=function_exists('storage_path')?storage_path('temp/tools'):sys_get_temp_dir();
  return[
   ['name'=>'PHP','status'=>version_compare(PHP_VERSION,'8.1.0','>=')?'ok':'error','detail'=>PHP_VERSION],
   ['name'=>'Dynamic PHP Runtime','status'=>$this->phpRuntime->isAvailable()?'ok':'warning','detail'=>$this->phpRuntime->isAvailable()?'PHP CLI/proc_open available':'Unavailable; use Controlled/Python/HTTP engine'],
   ['name'=>'ZipArchive','status'=>class_exists('ZipArchive')?'ok':'warning','detail'=>class_exists('ZipArchive')?'Available':'Not installed'],
   ['name'=>'GD','status'=>extension_loaded('gd')?'ok':'warning','detail'=>extension_loaded('gd')?'Available':'Not installed'],
   ['name'=>'Imagick','status'=>extension_loaded('imagick')?'ok':'info','detail'=>extension_loaded('imagick')?'Available':'Optional'],
   ['name'=>'cURL','status'=>extension_loaded('curl')?'ok':'warning','detail'=>extension_loaded('curl')?'Available':'HTTP API unavailable without cURL'],
   ['name'=>'OpenSSL/Sodium','status'=>(extension_loaded('openssl')||extension_loaded('sodium'))?'ok':'error','detail'=>(extension_loaded('openssl')||extension_loaded('sodium'))?'Secret encryption available':'Secret encryption unavailable'],
   ['name'=>'Temp Workspace','status'=>(is_dir($temp)&&is_writable($temp))?'ok':'warning','detail'=>$temp],
  ];
 }
}

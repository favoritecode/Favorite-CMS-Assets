<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use FavoriteCMS\Tools\Handlers\PhpHandlerRegistry;
use FavoriteCMS\Tools\Support\ResultType;
use RuntimeException;

/**
 * Configuration-driven pipeline runtime.
 *
 * Existing built-in operations remain supported. Published Dynamic Operations can be referenced
 * by operation_id without changing plugin source. Conditions, foreach, optional steps and nested
 * dynamic handlers are supported with bounded recursion/step limits.
 */
final class DynamicHandlerRuntime
{
    public const MAX_STEPS = 80;
    public const MAX_STRING_BYTES = 8_000_000;
    public const MAX_RECURSION = 5;

    public function __construct(
        private ?DynamicOperationRuntime $dynamicOperations = null,
        private ?BindingResolver $bindings = null
    ) {
        $this->bindings ??= new BindingResolver();
    }

    public static function allowedOperations(): array
    {
        return [
            'trim' => 'Trim whitespace',
            'uppercase' => 'Uppercase text',
            'lowercase' => 'Lowercase text',
            'titlecase' => 'Title Case text',
            'replace' => 'Find and replace literal text',
            'prefix' => 'Add prefix',
            'suffix' => 'Add suffix',
            'slugify' => 'Create URL slug',
            'url_encode' => 'URL encode',
            'url_decode' => 'URL decode',
            'base64_encode' => 'Base64 encode',
            'base64_decode' => 'Base64 decode',
            'json_pretty' => 'Pretty-print JSON',
            'json_minify' => 'Minify JSON',
            'json_validate' => 'Validate JSON',
            'hash' => 'Generate hash',
            'sort_lines' => 'Sort lines',
            'unique_lines' => 'Remove duplicate lines',
            'template' => 'Template output using {{value}} / {{input.name}}',
            'core_handler' => 'Run one existing registered core handler',
        ];
    }

    public function allAvailableOperations(): array
    {
        $ops = self::allowedOperations();
        if ($this->dynamicOperations) {
            foreach ($this->dynamicOperations->labels() as $id => $label) {
                if (!isset($ops[$id])) $ops[$id] = 'Dynamic: ' . $label;
            }
        }
        return $ops;
    }

    /** @return string[] */
    public function validateDefinition(array $definition): array
    {
        $errors = [];
        $steps = $definition['steps'] ?? null;
        if (!is_array($steps) || $steps === []) return ['Definition must contain at least one pipeline step.'];
        if (count($steps) > self::MAX_STEPS) $errors[] = 'Definition exceeds the maximum of ' . self::MAX_STEPS . ' steps.';

        $allowed = self::allowedOperations();
        foreach ($steps as $index => $step) {
            if (!is_array($step)) { $errors[] = 'Step ' . ($index + 1) . ' must be an object.'; continue; }
            $operation = strtolower(trim((string)($step['operation'] ?? $step['op'] ?? '')));
            if ($operation === '') { $errors[] = 'Step ' . ($index + 1) . ' requires an operation.'; continue; }
            $isKnown = isset($allowed[$operation]) || ($this->dynamicOperations?->hasOperation($operation) ?? false);
            if (!$isKnown) { $errors[] = 'Step ' . ($index + 1) . " uses unsupported operation '{$operation}'."; continue; }
            if ($operation === 'hash') {
                $algo = strtolower((string)($step['algorithm'] ?? 'sha256'));
                if (!in_array($algo, ['sha256','sha384','sha512','sha1','md5'], true)) $errors[] = 'Step ' . ($index + 1) . " uses unsupported hash algorithm '{$algo}'.";
            }
            if ($operation === 'core_handler') {
                $handlerId = trim((string)($step['handler_id'] ?? ''));
                if ($handlerId === '' || !PhpHandlerRegistry::has($handlerId)) $errors[] = 'Step ' . ($index + 1) . ' references an unknown core handler.';
            }
            if (isset($step['on_error']) && !in_array(strtolower((string)$step['on_error']), ['stop','continue','skip'], true)) {
                $errors[] = 'Step ' . ($index + 1) . ' has invalid on_error strategy.';
            }
        }

        $inputKey = (string)($definition['input_key'] ?? 'input');
        if ($inputKey === '' || !preg_match('/^[A-Za-z0-9_.-]+$/', $inputKey)) $errors[] = 'input_key contains invalid characters.';
        return $errors;
    }

    public function execute(array $definition, array $inputs, array $toolConfig = []): array
    {
        return $this->executeInternal($definition, $inputs, $toolConfig, 0);
    }

    private function executeInternal(array $definition, array $inputs, array $toolConfig, int $depth): array
    {
        if ($depth > self::MAX_RECURSION) return ['success'=>false,'error'=>'Dynamic handler recursion limit exceeded.'];
        $errors = $this->validateDefinition($definition);
        if ($errors !== []) return ['success'=>false,'error'=>implode(' ', $errors)];

        $inputKey = (string)($definition['input_key'] ?? 'input');
        $value = $this->resolveInputValue($inputs, $inputKey);
        if ($value === null && array_key_exists('default_value', $definition)) $value = $definition['default_value'];
        if ($value === null) $value = '';

        $stepMeta=[]; $history=[]; $warnings=[];
        foreach ($definition['steps'] as $index => $step) {
            $op = strtolower((string)($step['operation'] ?? $step['op'] ?? ''));
            $state=['input'=>$inputs,'current'=>$value,'step'=>$history,'result'=>$value,'context'=>$toolConfig];
            if (array_key_exists('when',$step) && !$this->bindings->truthy($step['when'],$state)) {
                $stepMeta[]=['index'=>$index+1,'operation'=>$op,'status'=>'skipped_condition'];
                continue;
            }

            $resolvedStep=$this->bindings->resolve($step,$state); if(!is_array($resolvedStep))$resolvedStep=$step;
            $strategy=strtolower((string)($resolvedStep['on_error']??(!empty($resolvedStep['optional'])?'continue':'stop')));
            try {
                if (array_key_exists('foreach',$resolvedStep)) {
                    $iterable=$this->bindings->resolve($resolvedStep['foreach'],$state);
                    if(!is_array($iterable)) throw new RuntimeException('foreach binding did not resolve to an array.');
                    $mapped=[];
                    foreach($iterable as $k=>$item){$mapped[$k]=$this->applyOperation($op,$item,$resolvedStep,$inputs,$toolConfig,$history);$this->assertValueSize($mapped[$k]);}
                    $value=$mapped;
                } else {
                    $value=$this->applyOperation($op,$value,$resolvedStep,$inputs,$toolConfig,$history);
                    $this->assertValueSize($value);
                }
                $history['step'.($index+1)]=['value'=>$value,'operation'=>$op];
                $history['previous']=['value'=>$value,'operation'=>$op];
                $stepMeta[]=['index'=>$index+1,'operation'=>$op,'status'=>'ok'];
            } catch (\Throwable $e) {
                $message=ToolExecutionService::sanitizeMessageString($e->getMessage());
                $stepMeta[]=['index'=>$index+1,'operation'=>$op,'status'=>'error'];
                if($strategy==='continue'||$strategy==='skip'){$warnings[]='Step '.($index+1).' skipped: '.$message;continue;}
                return['success'=>false,'error'=>$message,'meta'=>['runtime'=>'dynamic_controlled_handler','steps'=>$stepMeta,'warnings'=>$warnings]];
            }
        }

        if(isset($definition['output_mapping'])&&is_array($definition['output_mapping'])){
            $mapped=$this->bindings->resolve($definition['output_mapping'],['input'=>$inputs,'current'=>$value,'step'=>$history,'result'=>$value,'context'=>$toolConfig]);
            $value=$mapped;
        }

        $type = strtoupper((string)($definition['result_type'] ?? $this->inferResultType($value)));
        if (!in_array($type,[ResultType::TEXT,ResultType::JSON,ResultType::HTML,ResultType::CSS,'FILE','FILES','IMAGE','TABLE'],true)) $type=$this->inferResultType($value);
        return ['success'=>true,'type'=>$type,'value'=>$value,'data'=>$value,'meta'=>['runtime'=>'dynamic_controlled_handler','steps'=>$stepMeta,'warnings'=>$warnings]];
    }

    private function applyOperation(string $operation,mixed $value,array $step,array $inputs,array $toolConfig,array $history):mixed
    {
        if ($this->dynamicOperations?->hasOperation($operation)) {
            $result=$this->dynamicOperations->executeById($operation,$value,$step,$inputs,$toolConfig,$history);
            if(($result['success']??false)!==true) throw new RuntimeException(is_string($result['error']??null)?$result['error']:'Dynamic operation failed.');
            return $result['value']??$result['data']??$result;
        }
        return match($operation){
            'trim'=>trim($this->toString($value)), 'uppercase'=>$this->upper($this->toString($value)), 'lowercase'=>$this->lower($this->toString($value)), 'titlecase'=>$this->title($this->toString($value)),
            'replace'=>str_replace((string)($step['search']??''),(string)($step['replace']??''),$this->toString($value)),
            'prefix'=>(string)($step['value']??$step['text']??'').$this->toString($value), 'suffix'=>$this->toString($value).(string)($step['value']??$step['text']??''),
            'slugify'=>$this->slugify($this->toString($value)), 'url_encode'=>rawurlencode($this->toString($value)), 'url_decode'=>rawurldecode($this->toString($value)),
            'base64_encode'=>base64_encode($this->toString($value)), 'base64_decode'=>$this->safeBase64Decode($this->toString($value)),
            'json_pretty'=>$this->jsonPretty($value), 'json_minify'=>$this->jsonMinify($value), 'json_validate'=>$this->jsonValidate($value),
            'hash'=>hash(strtolower((string)($step['algorithm']??'sha256')),$this->toString($value)),
            'sort_lines'=>$this->sortLines($this->toString($value),!empty($step['descending'])), 'unique_lines'=>$this->uniqueLines($this->toString($value),!empty($step['case_sensitive'])),
            'template'=>$this->renderTemplate((string)($step['template']??'{{value}}'),$value,$inputs),
            'core_handler'=>$this->callCoreHandler((string)($step['handler_id']??''),$inputs,$toolConfig,$value),
            default=>throw new RuntimeException("Unsupported dynamic operation '{$operation}'."),
        };
    }

    private function callCoreHandler(string $handlerId,array $inputs,array $toolConfig,mixed $value):mixed
    {
        $handler=PhpHandlerRegistry::get($handlerId); if(!$handler)throw new RuntimeException('Configured core handler is unavailable.');
        $mapped=$inputs;$mapped['input']=is_scalar($value)||$value===null?(string)$value:$value;$mapped['text']=$mapped['input'];$result=$handler->execute($mapped,$toolConfig);
        if(($result['success']??true)===false)throw new RuntimeException(is_string($result['error']??null)?$result['error']:'Core handler failed.');
        return$result['value']??$result['data']??'';
    }

    private function resolveInputValue(array $inputs,string $path):mixed
    {
        if(array_key_exists($path,$inputs))return$inputs[$path];$segments=explode('.',$path);$current=$inputs;
        foreach($segments as $segment){if(!is_array($current)||!array_key_exists($segment,$current)){foreach(['input','text','content','value','items'] as $fallback)if(array_key_exists($fallback,$inputs))return$inputs[$fallback];return null;}$current=$current[$segment];}
        return$current;
    }
    private function renderTemplate(string $template,mixed $value,array $inputs):string{ $rendered=str_replace('{{value}}',$this->toString($value),$template);return preg_replace_callback('/\{\{input\.([A-Za-z0-9_.-]+)\}\}/',fn($m)=>$this->toString($this->resolveInputValue($inputs,$m[1])),$rendered)??$rendered; }
    private function jsonPretty(mixed $value):string{$decoded=$this->decodeJsonValue($value);return(string)json_encode($decoded,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);}
    private function jsonMinify(mixed $value):string{$decoded=$this->decodeJsonValue($value);return(string)json_encode($decoded,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);}
    private function jsonValidate(mixed $value):array{try{$decoded=$this->decodeJsonValue($value);return['valid'=>true,'data'=>$decoded,'message'=>'Valid JSON.'];}catch(RuntimeException $e){return['valid'=>false,'message'=>$e->getMessage()];}}
    private function decodeJsonValue(mixed $value):mixed{if(is_array($value)||is_object($value))return$value;$decoded=json_decode($this->toString($value),true);if(json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('Invalid JSON: '.json_last_error_msg());return$decoded;}
    private function safeBase64Decode(string $value):string{$decoded=base64_decode($value,true);if($decoded===false)throw new RuntimeException('Input is not valid Base64.');return$decoded;}
    private function sortLines(string $value,bool $descending):string{$lines=preg_split('/\R/u',$value)?:[];natcasesort($lines);$lines=array_values($lines);if($descending)$lines=array_reverse($lines);return implode("\n",$lines);}
    private function uniqueLines(string $value,bool $caseSensitive):string{$lines=preg_split('/\R/u',$value)?:[];$seen=[];$out=[];foreach($lines as $line){$key=$caseSensitive?$line:$this->lower($line);if(isset($seen[$key]))continue;$seen[$key]=true;$out[]=$line;}return implode("\n",$out);}
    private function slugify(string $value):string{$value=trim($value);$value=preg_replace('/([a-z])([A-Z])/u','$1-$2',$value)??$value;$value=preg_replace('/[^\pL\pN]+/u','-',$value)??$value;return$this->lower(trim($value,'-'));}
    private function upper(string $value):string{return function_exists('mb_strtoupper')?mb_strtoupper($value,'UTF-8'):strtoupper($value);}
    private function lower(string $value):string{return function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);}
    private function title(string $value):string{return function_exists('mb_convert_case')?mb_convert_case($value,MB_CASE_TITLE,'UTF-8'):ucwords(strtolower($value));}
    private function inferResultType(mixed $value):string{return(is_array($value)||is_object($value))?ResultType::JSON:ResultType::TEXT;}
    private function toString(mixed $value):string{if($value===null)return'';if(is_string($value))return$value;if(is_scalar($value))return(string)$value;return(string)json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);}
    private function assertValueSize(mixed $value):void{if(strlen($this->toString($value))>self::MAX_STRING_BYTES)throw new RuntimeException('Dynamic handler output exceeded the safe size limit.');}
}

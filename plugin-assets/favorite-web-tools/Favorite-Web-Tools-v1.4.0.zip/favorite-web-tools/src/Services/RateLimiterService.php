<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Services;
final class RateLimiterService {
 private string $dir;
 public function __construct(?string $dir=null){$this->dir=$dir??(function_exists('storage_path')?storage_path('temp/fwt-rate-limits'):sys_get_temp_dir().'/fwt-rate-limits');if(!is_dir($this->dir))@mkdir($this->dir,0700,true);}
 public function allow(string $key,int $limit,int $window=60):bool{if($limit<=0)return true;$file=$this->dir.'/'.hash('sha256',$key).'.json';$fh=@fopen($file,'c+');if(!$fh)return true;flock($fh,LOCK_EX);$raw=stream_get_contents($fh);$d=is_string($raw)?json_decode($raw,true):null;$now=time();if(!is_array($d)||($d['start']??0)+$window<=$now)$d=['start'=>$now,'count'=>0];$ok=(int)$d['count']<$limit;if($ok)$d['count']=(int)$d['count']+1;ftruncate($fh,0);rewind($fh);fwrite($fh,json_encode($d));fflush($fh);flock($fh,LOCK_UN);fclose($fh);return$ok;}
}

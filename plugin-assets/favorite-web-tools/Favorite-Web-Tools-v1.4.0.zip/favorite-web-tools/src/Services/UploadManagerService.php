<?php

declare(strict_types=1);
namespace FavoriteCMS\Tools\Services;
use RuntimeException;
final class UploadManagerService {
 public const DEFAULT_MAX_BYTES=10_485_760;
 private const BLOCKED_EXT=['php','phtml','phar','cgi','pl','py','sh','bash','exe','dll','com','bat','cmd','msi','htaccess','user.ini'];
 public function normalize(array $files,int $maxBytes=self::DEFAULT_MAX_BYTES):array{$out=[];foreach($files as $key=>$file){$out[$key]=$this->normalizeOne($file,$maxBytes);}return$out;}
 private function normalizeOne(array $f,int $max):array{
  if(isset($f['tmp_name'])&&is_array($f['tmp_name'])){ $list=[];foreach($f['tmp_name'] as $i=>$tmp){$list[]=$this->normalizeOne(['tmp_name'=>$tmp,'name'=>$f['name'][$i]??'upload.bin','type'=>$f['type'][$i]??'','size'=>$f['size'][$i]??0,'error'=>$f['error'][$i]??UPLOAD_ERR_OK],$max);}return['multiple'=>true,'files'=>$list];}
  if(($f['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK) throw new RuntimeException('Upload failed.');
  $tmp=(string)($f['tmp_name']??''); if($tmp===''||!is_file($tmp)) throw new RuntimeException('Uploaded temporary file is missing.');
  $size=(int)($f['size']??filesize($tmp)); if($size<0||$size>$max) throw new RuntimeException('Uploaded file exceeds the allowed size.');
  $name=basename((string)($f['name']??'upload.bin')); $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); if(in_array($ext,self::BLOCKED_EXT,true)) throw new RuntimeException('Executable uploads are not allowed.');
  $mime='application/octet-stream'; if(function_exists('finfo_open')){$fi=finfo_open(FILEINFO_MIME_TYPE);if($fi){$det=finfo_file($fi,$tmp);if(is_string($det)&&$det!=='')$mime=$det;finfo_close($fi);}}
  return['name'=>$name,'extension'=>$ext,'type'=>$mime,'size'=>$size,'tmp_name'=>$tmp,'content'=>(string)file_get_contents($tmp)];
 }
}

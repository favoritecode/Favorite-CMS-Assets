<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use RuntimeException;

final class QrCodeService
{
    public const MAX_ITEMS = 100;
    public const MAX_CSV_BYTES = 2_097_152;
    public const MIN_SIZE = 100;
    public const MAX_SIZE = 400;
    public const MAX_BORDER = 20;

    public function __construct(
        private ?DownloadManagerService $downloads = null,
        private ?QrMatrixEncoder $encoder = null
    ) {
        $this->downloads ??= new DownloadManagerService();
        $this->encoder ??= new QrMatrixEncoder();
    }

    /**
     * Generate one PNG or a ZIP of multiple PNG files.
     *
     * @return array<string,mixed>
     */
    public function generate(array $inputs, array $config = []): array
    {
        try {
            $items = $this->normalizeItems($inputs);
            $qrColor = $this->normalizeColor((string)($inputs['qr_color'] ?? '#000000'), '#000000');
            $backgroundColor = $this->normalizeColor((string)($inputs['background_color'] ?? '#ffffff'), '#ffffff');
            $borderColor = $this->normalizeColor((string)($inputs['border_color'] ?? '#ffffff'), '#ffffff');
        } catch (RuntimeException $e) {
            $message = $e->getMessage();
            $code = str_contains(strtolower($message), 'csv') ? 'CSV_TOO_LARGE' : 'INVALID_OPTIONS';
            return $this->error($code, $message);
        }

        if ($items === []) {
            return $this->error('NO_VALID_ROWS', 'No valid URL was provided.');
        }
        if (count($items) > self::MAX_ITEMS) {
            return $this->error('TOO_MANY_ITEMS', 'A maximum of ' . self::MAX_ITEMS . ' QR codes can be generated at once.');
        }

        $borderWidth = max(0, min(self::MAX_BORDER, (int)($inputs['border_width'] ?? 1)));
        $size = max(self::MIN_SIZE, min(self::MAX_SIZE, (int)($inputs['size'] ?? 200)));
        $transparent = $this->toBool($inputs['transparent'] ?? false);

        $files = [];
        $usedNames = [];
        foreach ($items as $index => $item) {
            $url = (string)$item['url'];
            if (!$this->isValidWebUrl($url)) {
                return $this->error('INVALID_URL', 'One or more rows contain an invalid HTTP/HTTPS URL.', ['row' => $index + 1]);
            }

            try {
                $matrix = $this->encoder->encode($url);
                $png = $this->renderPng($matrix, $size, $qrColor, $backgroundColor, $borderWidth, $borderColor, $transparent);
            } catch (RuntimeException $e) {
                return $this->error('QR_GENERATION_FAILED', $e->getMessage(), ['row' => $index + 1]);
            }

            $base = $this->safeBaseName((string)($item['title'] ?? ''), $url, $index + 1);
            $filename = $this->uniqueFilename($base . '.png', $usedNames);
            $files[] = [
                'name' => $filename,
                'content' => $png,
                'mime_type' => 'image/png',
            ];
        }

        if (count($files) === 1) {
            $download = $this->downloads->createDownload($files[0]['content'], $files[0]['name'], 'image/png');
            return [
                'success' => true,
                'type' => 'json',
                'value' => [
                    'success' => true,
                    'count' => 1,
                    'download_type' => 'png',
                    'files' => [[
                        'name' => $download['filename'],
                        'url' => $download['download_url'],
                        'download_url' => $download['download_url'],
                        'size' => $download['size'],
                        'mime_type' => 'image/png',
                    ]],
                    'message' => 'QR generated successfully.',
                ],
                'data' => null,
                'meta' => ['qr_engine' => 'server_php', 'count' => 1],
            ];
        }

        try {
            $zipBytes = $this->buildZip($files);
        } catch (RuntimeException $e) {
            return $this->error('ZIP_GENERATION_FAILED', 'Unable to build the QR ZIP archive.');
        }
        $zip = $this->downloads->createDownload($zipBytes, 'qr-codes.zip', 'application/zip');

        return [
            'success' => true,
            'type' => 'json',
            'value' => [
                'success' => true,
                'count' => count($files),
                'download_type' => 'zip',
                'files' => [[
                    'name' => $zip['filename'],
                    'url' => $zip['download_url'],
                    'download_url' => $zip['download_url'],
                    'size' => $zip['size'],
                    'mime_type' => 'application/zip',
                ]],
                'generated_files' => array_map(static fn(array $f): array => ['name' => $f['name']], $files),
                'message' => count($files) . ' QR codes generated successfully.',
            ],
            'data' => null,
            'meta' => ['qr_engine' => 'server_php', 'count' => count($files)],
        ];
    }

    /** @return array<int,array{title:string,url:string}> */
    private function normalizeItems(array $inputs): array
    {
        $items = [];

        if (isset($inputs['items']) && is_string($inputs['items'])) {
            $decoded = json_decode($inputs['items'], true);
            if (is_array($decoded)) {
                $inputs['items'] = $decoded;
            }
        }

        if (isset($inputs['items']) && is_array($inputs['items'])) {
            foreach ($inputs['items'] as $row) {
                if (is_string($row)) {
                    $row = ['url' => $row];
                }
                if (!is_array($row)) {
                    continue;
                }
                $url = trim((string)($row['url'] ?? ''));
                if ($url === '') {
                    continue;
                }
                $items[] = [
                    'title' => trim((string)($row['title'] ?? $row['name'] ?? '')),
                    'url' => $url,
                ];
            }
        }

        $singleUrl = trim((string)($inputs['url'] ?? ''));
        if ($singleUrl !== '') {
            array_unshift($items, [
                'title' => trim((string)($inputs['title'] ?? $inputs['filename'] ?? '')),
                'url' => $singleUrl,
            ]);
        }

        $bulk = trim((string)($inputs['urls'] ?? $inputs['bulk_urls'] ?? $inputs['text'] ?? ''));
        if ($bulk !== '') {
            foreach (preg_split('/\R+/', $bulk) ?: [] as $line) {
                $line = trim($line);
                if ($line === '') {
                    continue;
                }
                // Optional "title<TAB>url" or "title | url" convenience format.
                if (preg_match('/^(.+?)\s*(?:\t|\|)\s*(https?:\/\/\S+)$/iu', $line, $m)) {
                    $items[] = ['title' => trim($m[1]), 'url' => trim($m[2])];
                } else {
                    $items[] = ['title' => '', 'url' => $line];
                }
            }
        }

        $csvContent = $this->extractCsvContent($inputs);
        if ($csvContent !== null && $csvContent !== '') {
            foreach ($this->parseCsv($csvContent) as $row) {
                $items[] = $row;
            }
        }

        // Preserve order, remove exact duplicate title+URL rows.
        $deduped = [];
        $seen = [];
        foreach ($items as $item) {
            $key = strtolower($item['title']) . "\0" . $item['url'];
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $deduped[] = $item;
        }

        return $deduped;
    }

    private function extractCsvContent(array $inputs): ?string
    {
        foreach (['csv_file', 'csv_upload', 'csv'] as $key) {
            if (!array_key_exists($key, $inputs)) {
                continue;
            }
            $value = $inputs[$key];
            if (is_array($value)) {
                $size = (int)($value['size'] ?? strlen((string)($value['content'] ?? '')));
                if ($size > self::MAX_CSV_BYTES) {
                    throw new RuntimeException('CSV upload exceeds the 2 MB limit.');
                }
                $content = (string)($value['content'] ?? '');
                if ($content !== '') {
                    return $content;
                }
            } elseif (is_string($value)) {
                if (strlen($value) > self::MAX_CSV_BYTES) {
                    throw new RuntimeException('CSV upload exceeds the 2 MB limit.');
                }
                return $value;
            }
        }

        $direct = $inputs['csv_content'] ?? null;
        if (is_string($direct) && $direct !== '') {
            if (strlen($direct) > self::MAX_CSV_BYTES) {
                throw new RuntimeException('CSV upload exceeds the 2 MB limit.');
            }
            return $direct;
        }

        return null;
    }

    /** @return array<int,array{title:string,url:string}> */
    private function parseCsv(string $content): array
    {
        $stream = fopen('php://temp', 'w+b');
        if ($stream === false) {
            throw new RuntimeException('Unable to parse CSV input.');
        }
        fwrite($stream, $content);
        rewind($stream);

        $rows = [];
        $header = null;
        $rowNumber = 0;
        while (($fields = fgetcsv($stream, null, ',', '"', '')) !== false) {
            $rowNumber++;
            if ($fields === [null] || $fields === []) {
                continue;
            }
            $fields = array_map(static fn($v): string => trim((string)$v), $fields);
            if ($rowNumber === 1) {
                $lower = array_map('strtolower', $fields);
                if (in_array('url', $lower, true)) {
                    $header = $lower;
                    continue;
                }
            }

            if ($header !== null) {
                $record = [];
                foreach ($header as $i => $name) {
                    $record[$name] = $fields[$i] ?? '';
                }
                $url = trim((string)($record['url'] ?? ''));
                $title = trim((string)($record['title'] ?? $record['name'] ?? ''));
            } else {
                if (count($fields) === 1) {
                    $title = '';
                    $url = $fields[0];
                } else {
                    $title = $fields[0];
                    $url = $fields[1] ?? '';
                }
            }

            if ($url !== '') {
                $rows[] = ['title' => $title, 'url' => $url];
            }
            if (count($rows) > self::MAX_ITEMS) {
                break;
            }
        }
        fclose($stream);
        return $rows;
    }

    private function isValidWebUrl(string $url): bool
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true);
    }

    private function normalizeColor(string $value, string $fallback): string
    {
        $value = trim($value);
        if (preg_match('/^#[0-9a-fA-F]{6}$/', $value)) {
            return strtolower($value);
        }
        if (preg_match('/^#([0-9a-fA-F]{3})$/', $value, $m)) {
            return '#' . strtolower($m[1][0] . $m[1][0] . $m[1][1] . $m[1][1] . $m[1][2] . $m[1][2]);
        }
        if ($value !== '') {
            throw new RuntimeException('Invalid color value. Use a hex color such as #000000.');
        }
        return $fallback;
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) return $value;
        if (is_int($value)) return $value !== 0;
        return in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on'], true);
    }

    private function safeBaseName(string $title, string $url, int $index): string
    {
        $base = trim($title);
        if ($base === '') {
            $host = (string)(parse_url($url, PHP_URL_HOST) ?? '');
            $base = $host !== '' ? preg_replace('/^www\./i', '', $host) : 'qr-' . $index;
        }
        if (function_exists('iconv')) {
            $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base);
            if (is_string($ascii) && $ascii !== '') {
                $base = $ascii;
            }
        }
        $base = preg_replace('/[^A-Za-z0-9._-]+/', '-', $base) ?? '';
        $base = trim($base, '-_.');
        if ($base === '') {
            $base = 'qr-' . $index;
        }
        return substr($base, 0, 120);
    }

    /** @param array<string,bool> $used */
    private function uniqueFilename(string $filename, array &$used): string
    {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $base = pathinfo($filename, PATHINFO_FILENAME);
        $candidate = $filename;
        $i = 2;
        while (isset($used[strtolower($candidate)])) {
            $candidate = $base . '-' . $i++ . ($ext !== '' ? '.' . $ext : '');
        }
        $used[strtolower($candidate)] = true;
        return $candidate;
    }

    /**
     * @param array<int,array<int,bool>> $matrix
     */
    private function renderPng(
        array $matrix,
        int $size,
        string $foreground,
        string $background,
        int $borderWidth,
        string $borderColor,
        bool $transparent
    ): string {
        $modules = count($matrix);
        if ($modules < 21) {
            throw new RuntimeException('Invalid QR matrix.');
        }
        $quietModules = 4;
        $drawable = max(1, $size - ($borderWidth * 2));
        $moduleScale = intdiv($drawable, $modules + ($quietModules * 2));
        if ($moduleScale < 1) {
            throw new RuntimeException('QR image size is too small for this payload.');
        }

        $qrPixels = ($modules + ($quietModules * 2)) * $moduleScale;
        $left = $borderWidth + intdiv($drawable - $qrPixels, 2);
        $top = $borderWidth + intdiv($drawable - $qrPixels, 2);

        [$fr, $fg, $fb] = $this->hexRgb($foreground);
        [$br, $bg, $bb] = $this->hexRgb($background);
        [$or, $og, $ob] = $this->hexRgb($borderColor);

        $raw = '';
        for ($y = 0; $y < $size; $y++) {
            $raw .= "\x00"; // PNG filter: None.
            for ($x = 0; $x < $size; $x++) {
                $isOuterBorder = $borderWidth > 0 && (
                    $x < $borderWidth || $y < $borderWidth || $x >= $size - $borderWidth || $y >= $size - $borderWidth
                );
                if ($isOuterBorder) {
                    $raw .= chr($or) . chr($og) . chr($ob) . "\xFF";
                    continue;
                }

                $dark = false;
                $qx = $x - $left;
                $qy = $y - $top;
                if ($qx >= 0 && $qy >= 0 && $qx < $qrPixels && $qy < $qrPixels) {
                    $mx = intdiv($qx, $moduleScale) - $quietModules;
                    $my = intdiv($qy, $moduleScale) - $quietModules;
                    if ($mx >= 0 && $my >= 0 && $mx < $modules && $my < $modules) {
                        $dark = $matrix[$my][$mx];
                    }
                }

                if ($dark) {
                    $raw .= chr($fr) . chr($fg) . chr($fb) . "\xFF";
                } else {
                    $alpha = $transparent ? 0 : 255;
                    $raw .= chr($br) . chr($bg) . chr($bb) . chr($alpha);
                }
            }
        }

        $compressed = gzcompress($raw, 9);
        if ($compressed === false) {
            throw new RuntimeException('PNG compression is unavailable.');
        }

        $png = "\x89PNG\r\n\x1A\n";
        $png .= $this->pngChunk('IHDR', pack('NNCCCCC', $size, $size, 8, 6, 0, 0, 0));
        $png .= $this->pngChunk('IDAT', $compressed);
        $png .= $this->pngChunk('IEND', '');
        return $png;
    }

    /** @return array{0:int,1:int,2:int} */
    private function hexRgb(string $hex): array
    {
        $hex = ltrim($hex, '#');
        return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
    }

    private function pngChunk(string $type, string $data): string
    {
        return pack('N', strlen($data)) . $type . $data . hex2bin(hash('crc32b', $type . $data));
    }

    /**
     * Pure-PHP ZIP writer for generated QR PNGs. Avoids requiring ZipArchive.
     *
     * @param array<int,array{name:string,content:string,mime_type:string}> $files
     */
    private function buildZip(array $files): string
    {
        $local = '';
        $central = '';
        $offset = 0;
        $count = 0;

        foreach ($files as $file) {
            $name = str_replace('\\', '/', basename($file['name']));
            $nameBytes = $name;
            $content = $file['content'];
            $compressed = gzdeflate($content, 9);
            if ($compressed === false) {
                throw new RuntimeException('ZIP compression unavailable.');
            }
            $crc = crc32($content);
            $uncompressedSize = strlen($content);
            $compressedSize = strlen($compressed);
            $dosTime = $this->dosTime();
            $dosDate = $this->dosDate();
            $flags = 0x0800; // UTF-8 filename.
            $method = 8; // Deflate.

            $header = pack(
                'VvvvvvVVVvv',
                0x04034b50,
                20,
                $flags,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                strlen($nameBytes),
                0
            ) . $nameBytes;
            $local .= $header . $compressed;

            $central .= pack(
                'VvvvvvvVVVvvvvvVV',
                0x02014b50,
                0x0314,
                20,
                $flags,
                $method,
                $dosTime,
                $dosDate,
                $crc,
                $compressedSize,
                $uncompressedSize,
                strlen($nameBytes),
                0,
                0,
                0,
                0,
                0,
                $offset
            ) . $nameBytes;

            $offset += strlen($header) + $compressedSize;
            $count++;
        }

        $end = pack(
            'VvvvvVVv',
            0x06054b50,
            0,
            0,
            $count,
            $count,
            strlen($central),
            strlen($local),
            0
        );

        return $local . $central . $end;
    }

    private function dosTime(): int
    {
        $h = (int)date('G');
        $m = (int)date('i');
        $s = intdiv((int)date('s'), 2);
        return (($h & 0x1F) << 11) | (($m & 0x3F) << 5) | ($s & 0x1F);
    }

    private function dosDate(): int
    {
        $y = max(1980, (int)date('Y')) - 1980;
        $m = (int)date('n');
        $d = (int)date('j');
        return (($y & 0x7F) << 9) | (($m & 0x0F) << 5) | ($d & 0x1F);
    }

    /** @return array<string,mixed> */
    private function error(string $code, string $message, array $meta = []): array
    {
        return [
            'success' => false,
            'error' => $message,
            'reason' => $code,
            'type' => 'json',
            'value' => ['success' => false, 'error' => $message, 'reason' => $code],
            'data' => ['success' => false, 'error' => $message, 'reason' => $code],
            'meta' => $meta,
        ];
    }
}

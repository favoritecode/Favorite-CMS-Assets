<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use FavoriteCMS\Tools\Engines\HttpApiEngine;
use FavoriteCMS\Tools\Engines\PythonApiEngine;
use FavoriteCMS\Tools\Handlers\ConfiguredToolHandler;
use FavoriteCMS\Tools\Handlers\PhpHandlerRegistry;
use FavoriteCMS\Tools\Models\DynamicOperation;
use FavoriteCMS\Tools\Models\Tool;
use FavoriteCMS\Tools\Repositories\DynamicOperationRepository;
use FavoriteCMS\Tools\Repositories\PythonServiceRepository;
use RuntimeException;

final class DynamicOperationRuntime
{
    public function __construct(
        private DynamicOperationRepository $repo,
        private DynamicPhpRuntimeService $phpRuntime,
        private CapabilityService $capabilities,
        private BindingResolver $bindings,
        private ?PythonServiceRepository $pythonRepo = null,
        private ?PythonClientService $pythonClient = null,
        private ?SecretVaultService $secrets = null
    ) {}

    public function hasOperation(string $id): bool { $op=$this->repo->findByOperationId($id); return $op?->isActive()??false; }
    public function labels(): array { $out=[];foreach($this->repo->all(true) as $op)$out[$op->operation_id]=$op->name.' ['.$op->executor_type.']';return$out; }

    public function executeById(string $operationId, mixed $current, array $step, array $inputs, array $context = [], array $history = []): array
    {
        $op=$this->repo->findByOperationId($operationId);
        if(!$op||!$op->isActive())return['success'=>false,'error'=>"Dynamic operation '{$operationId}' is unavailable."];
        $state=['input'=>$inputs,'current'=>$current,'step'=>$history,'result'=>$current,'context'=>array_merge($context,['operation_id'=>$operationId])];
        $params=$this->bindings->resolve($step,$state); if(!is_array($params))$params=[];
        return $this->execute($op,$current,$params,$inputs,$context);
    }

    public function execute(DynamicOperation $op,mixed $current,array $params,array $inputs,array $context=[]):array
    {
        $type=strtoupper($op->executor_type);$cfg=$this->bindings->resolve($op->configuration,['input'=>$inputs,'current'=>$current,'step'=>[],'result'=>$current,'context'=>array_merge($context,['operation_id'=>$op->operation_id])]);if(!is_array($cfg))$cfg=[];$cfg=array_replace_recursive($cfg,$params);
        if($type==='BUILTIN'||$type==='BUILTIN_SAFE_OPERATION'){
            $cap=(string)($cfg['capability']??'');
            if($cap==='transform'){
                $operation=(string)($cfg['operation']??$op->operation_id);$runtime=new DynamicHandlerRuntime();
                return $runtime->execute(['input_key'=>'input','result_type'=>'JSON','steps'=>[array_merge($cfg,['operation'=>$operation])]],['input'=>$current]);
            }
            return $this->capabilities->execute($cap?:$op->operation_id,$current,$cfg,$inputs);
        }
        if($type==='SANDBOXED_PHP'||$type==='DYNAMIC_PHP'){
            $source=(string)($cfg['source']??$op->configuration['source']??'');
            $payload=is_array($current)?$current:array_merge($inputs,['value'=>$current,'input'=>$current]);
            return $this->phpRuntime->execute($source,$payload,array_merge($context,['operation_id'=>$op->operation_id]),['timeout_seconds'=>$cfg['timeout_seconds']??5,'memory_mb'=>$cfg['memory_mb']??64,'output_limit_kb'=>$cfg['output_limit_kb']??1024]);
        }
        if($type==='CONTROLLED_HANDLER'){
            $handlerId=(string)($cfg['handler_id']??'');$handler=PhpHandlerRegistry::get($handlerId);
            if(!$handler||$handler instanceof ConfiguredToolHandler)return['success'=>false,'error'=>'Operation requires a trusted built-in Controlled Handler.'];
            $mapped=$inputs;$mapped['input']=$current;$mapped['value']=$current;return$handler->execute($mapped,$cfg);
        }
        if($type==='HTTP_API'||$type==='GENERIC_HTTP_API'){
            $tool=new Tool(['name'=>$op->name,'slug'=>'operation-'.$op->operation_id,'engine'=>'HTTP_API','configuration'=>$this->normalizeHttpConfig($cfg)]);
            $engine=new HttpApiEngine($this->secrets);$mapped=$inputs;$mapped['current']=$current;return$engine->execute($tool,$mapped);
        }
        if($type==='PYTHON_API'){
            if(!$this->pythonRepo)return['success'=>false,'error'=>'Python service repository is unavailable.'];
            $tool=new Tool(['name'=>$op->name,'slug'=>'operation-'.$op->operation_id,'engine'=>'PYTHON_API','configuration'=>$cfg]);
            $engine=new PythonApiEngine($this->pythonRepo,$this->pythonClient??new PythonClientService());$mapped=$inputs;$mapped['current']=$current;return$engine->execute($tool,$mapped);
        }
        return['success'=>false,'error'=>'Unsupported operation executor type.'];
    }

    private function normalizeHttpConfig(array $cfg):array
    {
        return[
            'http_api_url'=>$cfg['url']??$cfg['http_api_url']??'', 'http_api_method'=>$cfg['method']??$cfg['http_api_method']??'POST',
            'http_api_headers'=>$cfg['headers']??$cfg['http_api_headers']??[], 'http_request_mapping'=>$cfg['request_mapping']??$cfg['http_request_mapping']??[],
            'http_response_path'=>$cfg['response_path']??$cfg['http_response_path']??'', 'http_allowed_hosts'=>$cfg['allowed_hosts']??$cfg['http_allowed_hosts']??[],
            'http_timeout'=>$cfg['timeout']??$cfg['http_timeout']??15,'http_body_mode'=>$cfg['body_mode']??$cfg['http_body_mode']??'json'
        ];
    }
}

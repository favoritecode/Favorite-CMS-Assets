<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use RuntimeException;

/**
 * Sandboxed subprocess runtime for admin-authored Dynamic PHP tools.
 *
 * Security boundary:
 * - never evals PHP inside the CMS request process;
 * - executes in a separate PHP CLI subprocess with no php.ini (-n);
 * - open_basedir is restricted to a randomized temporary sandbox;
 * - URL wrappers, process/network/file-system escape functions and environment access are disabled;
 * - input/output are JSON over pipes;
 * - wall-clock timeout, memory and output limits are enforced;
 * - failure is closed when PHP CLI/proc_open are unavailable.
 *
 * This runtime is intentionally for pure transformations/calculations. Tools that require CMS DB
 * access, arbitrary filesystem access, network access, or privileged application services should
 * use a Controlled Handler, Python API, or Generic HTTP API engine instead.
 */
final class DynamicPhpRuntimeService
{
    public function __construct(private ?DownloadManagerService $downloads = null)
    {
        $this->downloads ??= new DownloadManagerService();
    }
    public const DEFAULT_TIMEOUT_SECONDS = 5;
    public const MAX_TIMEOUT_SECONDS = 15;
    public const DEFAULT_MEMORY_MB = 64;
    public const MAX_MEMORY_MB = 128;
    public const DEFAULT_OUTPUT_LIMIT_KB = 512;
    public const MAX_OUTPUT_LIMIT_KB = 2048;
    public const MAX_SOURCE_BYTES = 200_000;
    public const MAX_INPUT_BYTES = 2_000_000;

    /** @var string[] */
    private const DENIED_FUNCTIONS = [
        'eval', 'assert', 'exec', 'system', 'passthru', 'shell_exec', 'popen', 'proc_open',
        'proc_close', 'proc_terminate', 'proc_get_status', 'pcntl_exec', 'pcntl_fork',
        'pcntl_wait', 'pcntl_waitpid', 'pcntl_signal', 'putenv', 'getenv', 'ini_set',
        'ini_alter', 'dl', 'mail', 'header', 'setcookie', 'setrawcookie',
        'fsockopen', 'pfsockopen', 'stream_socket_client', 'stream_socket_server',
        'stream_socket_accept', 'stream_socket_pair', 'stream_socket_sendto', 'socket_create',
        'socket_connect', 'curl_init', 'curl_exec', 'curl_multi_init', 'ftp_connect',
        'ftp_ssl_connect', 'link', 'symlink', 'readlink', 'chroot', 'chmod', 'chown', 'chgrp',
        'parse_ini_file', 'show_source', 'highlight_file', 'phpinfo', 'get_included_files',
        'get_required_files', 'debug_backtrace', 'debug_print_backtrace', 'getcwd',
        'get_current_user', 'getmyuid', 'getmypid', 'getmygid', 'php_uname',
        'call_user_func', 'call_user_func_array', 'forward_static_call', 'forward_static_call_array',
        'register_shutdown_function', 'unserialize', 'set_time_limit', 'ignore_user_abort',
    ];

    /** @var string[] */
    private const DENIED_VARIABLES = [
        '$GLOBALS', '$_SERVER', '$_ENV', '$_COOKIE', '$_SESSION', '$_FILES', '$_GET', '$_POST', '$_REQUEST',
    ];

    /**
     * Validate the source code body before it is saved/executed.
     * The source is a function body and must not include PHP tags.
     *
     * @return string[]
     */
    public function validateSource(string $source): array
    {
        $errors = [];
        $source = trim($source);

        if ($source === '') {
            return ['Dynamic PHP source cannot be empty.'];
        }
        if (strlen($source) > self::MAX_SOURCE_BYTES) {
            $errors[] = 'Dynamic PHP source exceeds the maximum allowed size.';
        }
        if (str_contains($source, '<?') || str_contains($source, '?>')) {
            $errors[] = 'Do not include PHP opening/closing tags. Enter only the function body.';
        }

        foreach (self::DENIED_VARIABLES as $variable) {
            if (str_contains($source, $variable)) {
                $errors[] = "Use of {$variable} is not allowed in Dynamic PHP Runtime.";
            }
        }

        try {
            $tokens = token_get_all("<?php\n" . $source, TOKEN_PARSE);
        } catch (\ParseError $e) {
            $errors[] = 'Dynamic PHP syntax error: ' . $e->getMessage();
            return array_values(array_unique($errors));
        }
        $blockedTokens = array_filter([
            defined('T_EVAL') ? T_EVAL : null,
            defined('T_INCLUDE') ? T_INCLUDE : null,
            defined('T_INCLUDE_ONCE') ? T_INCLUDE_ONCE : null,
            defined('T_REQUIRE') ? T_REQUIRE : null,
            defined('T_REQUIRE_ONCE') ? T_REQUIRE_ONCE : null,
            defined('T_EXIT') ? T_EXIT : null,
            defined('T_HALT_COMPILER') ? T_HALT_COMPILER : null,
            defined('T_NAMESPACE') ? T_NAMESPACE : null,
            defined('T_CLASS') ? T_CLASS : null,
            defined('T_INTERFACE') ? T_INTERFACE : null,
            defined('T_TRAIT') ? T_TRAIT : null,
            defined('T_ENUM') ? T_ENUM : null,
            defined('T_NEW') ? T_NEW : null,
            defined('T_FILE') ? T_FILE : null,
            defined('T_DIR') ? T_DIR : null,
        ], static fn($v) => is_int($v));

        $count = count($tokens);
        for ($i = 0; $i < $count; $i++) {
            $token = $tokens[$i];
            if (!is_array($token)) {
                continue;
            }

            [$id, $text] = $token;
            if (in_array($id, $blockedTokens, true)) {
                $errors[] = 'Dynamic PHP source contains a blocked language construct: ' . token_name($id) . '.';
                continue;
            }

            if ($id === T_STRING) {
                $name = strtolower($text);
                $j = $i + 1;
                while ($j < $count && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                    $j++;
                }
                if ($j < $count && $tokens[$j] === '(' && in_array($name, self::DENIED_FUNCTIONS, true)) {
                    $errors[] = "Function {$text}() is not allowed in Dynamic PHP Runtime.";
                }
            }
        }

        return array_values(array_unique($errors));
    }

    public function isAvailable(): bool
    {
        return function_exists('proc_open')
            && function_exists('proc_get_status')
            && function_exists('proc_terminate')
            && $this->resolvePhpBinary() !== null;
    }

    /**
     * @return array{success:bool,type?:string,value?:mixed,data?:mixed,meta?:array,error?:string}
     */
    public function execute(string $source, array $input, array $context = [], array $limits = []): array
    {
        $errors = $this->validateSource($source);
        if ($errors !== []) {
            return ['success' => false, 'error' => implode(' ', $errors)];
        }

        if (!$this->isAvailable()) {
            return [
                'success' => false,
                'error' => 'Dynamic PHP Runtime is unavailable on this server. PHP CLI and proc_open are required. Use a Controlled Handler, Python API, or HTTP API engine instead.',
            ];
        }

        $inputJson = json_encode(['input' => $input, 'context' => $context], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($inputJson) || strlen($inputJson) > self::MAX_INPUT_BYTES) {
            return ['success' => false, 'error' => 'Dynamic PHP input exceeds the maximum allowed size.'];
        }

        $timeout = max(1, min(self::MAX_TIMEOUT_SECONDS, (int)($limits['timeout_seconds'] ?? self::DEFAULT_TIMEOUT_SECONDS)));
        $memory = max(16, min(self::MAX_MEMORY_MB, (int)($limits['memory_mb'] ?? self::DEFAULT_MEMORY_MB)));
        $outputLimitKb = max(64, min(self::MAX_OUTPUT_LIMIT_KB, (int)($limits['output_limit_kb'] ?? self::DEFAULT_OUTPUT_LIMIT_KB)));
        $outputLimitBytes = $outputLimitKb * 1024;

        $sandbox = $this->createSandboxDirectory();
        $workspace = $sandbox . DIRECTORY_SEPARATOR . 'workspace';
        if (!@mkdir($workspace, 0700, true) && !is_dir($workspace)) {
            return ['success' => false, 'error' => 'Unable to create Dynamic PHP workspace.'];
        }
        $runnerFile = $sandbox . DIRECTORY_SEPARATOR . 'runner.php';

        try {
            $wrapper = $this->buildRunnerScript($source);
            if (file_put_contents($runnerFile, $wrapper, LOCK_EX) === false) {
                throw new RuntimeException('Unable to prepare Dynamic PHP sandbox.');
            }

            $binary = $this->resolvePhpBinary();
            if ($binary === null) {
                throw new RuntimeException('PHP CLI is unavailable.');
            }

            $disabledFunctions = implode(',', self::DENIED_FUNCTIONS);
            $command = [
                $binary,
                '-n',
                '-d', 'display_errors=0',
                '-d', 'display_startup_errors=0',
                '-d', 'log_errors=0',
                '-d', 'html_errors=0',
                '-d', 'allow_url_fopen=0',
                '-d', 'allow_url_include=0',
                '-d', 'open_basedir=' . $sandbox,
                '-d', 'sys_temp_dir=' . $sandbox,
                '-d', 'upload_tmp_dir=' . $sandbox,
                '-d', 'memory_limit=' . $memory . 'M',
                '-d', 'max_execution_time=' . $timeout,
                '-d', 'disable_functions=' . $disabledFunctions,
                $runnerFile,
            ];

            $descriptorSpec = [
                0 => ['pipe', 'r'],
                1 => ['pipe', 'w'],
                2 => ['pipe', 'w'],
            ];

            $process = @proc_open($command, $descriptorSpec, $pipes, $sandbox, []);
            if (!is_resource($process)) {
                throw new RuntimeException('Unable to start the sandboxed PHP subprocess.');
            }

            fwrite($pipes[0], $inputJson);
            fclose($pipes[0]);
            stream_set_blocking($pipes[1], false);
            stream_set_blocking($pipes[2], false);

            $stdout = '';
            $stderr = '';
            $start = microtime(true);
            $timedOut = false;
            $tooLarge = false;
            $exitCode = null;

            while (true) {
                $stdout .= (string)stream_get_contents($pipes[1]);
                $stderr .= (string)stream_get_contents($pipes[2]);

                if (strlen($stdout) > $outputLimitBytes || strlen($stderr) > 64 * 1024) {
                    $tooLarge = true;
                    @proc_terminate($process, 9);
                    break;
                }

                $status = proc_get_status($process);
                if (!($status['running'] ?? false)) {
                    $exitCode = isset($status['exitcode']) ? (int)$status['exitcode'] : null;
                    break;
                }

                if ((microtime(true) - $start) > ($timeout + 0.5)) {
                    $timedOut = true;
                    @proc_terminate($process, 9);
                    break;
                }

                usleep(10_000);
            }

            $stdout .= (string)stream_get_contents($pipes[1]);
            $stderr .= (string)stream_get_contents($pipes[2]);
            fclose($pipes[1]);
            fclose($pipes[2]);
            @proc_close($process);

            if ($timedOut) {
                return ['success' => false, 'error' => 'Dynamic PHP execution timed out.'];
            }
            if ($tooLarge) {
                return ['success' => false, 'error' => 'Dynamic PHP output exceeded the configured limit.'];
            }

            $decoded = json_decode(trim($stdout), true);
            if (!is_array($decoded)) {
                $elapsed = microtime(true) - $start;
                if ($elapsed >= max(0.75, $timeout * 0.8)) {
                    return ['success' => false, 'error' => 'Dynamic PHP execution timed out.'];
                }
                return ['success' => false, 'error' => $exitCode !== null && $exitCode !== 0
                    ? 'Dynamic PHP execution failed inside the sandbox.'
                    : 'Dynamic PHP runtime returned an invalid response.'];
            }

            if (($decoded['success'] ?? false) !== true) {
                return [
                    'success' => false,
                    'error' => $this->sanitizeChildError((string)($decoded['error'] ?? 'Dynamic PHP execution failed.')),
                ];
            }

            if (isset($decoded['files']) && is_array($decoded['files'])) {
                $normalizedFiles = [];
                foreach ($decoded['files'] as $file) {
                    if (!is_array($file)) { continue; }
                    $relative = ltrim(str_replace('\\', '/', (string)($file['path'] ?? '')), '/');
                    if ($relative === '' || str_contains($relative, '..')) { continue; }
                    $candidate = $workspace . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
                    if (!is_file($candidate)) { continue; }
                    $content = (string)@file_get_contents($candidate);
                    $filename = basename((string)($file['name'] ?? basename($candidate)));
                    $mime = (string)($file['mime_type'] ?? 'application/octet-stream');
                    $download = $this->downloads?->createDownload($content, $filename, $mime);
                    if (is_array($download)) {
                        $normalizedFiles[] = [
                            'name' => $download['filename'],
                            'url' => $download['download_url'],
                            'download_url' => $download['download_url'],
                            'reference' => $download['reference'],
                            'size' => $download['size'],
                            'mime_type' => $mime,
                        ];
                    }
                }
                $decoded['files'] = $normalizedFiles;
                if ($normalizedFiles !== []) {
                    $decoded['meta'] = is_array($decoded['meta'] ?? null) ? $decoded['meta'] : [];
                    $decoded['meta']['file_count'] = count($normalizedFiles);
                }
            }

            $decoded['meta'] = is_array($decoded['meta'] ?? null) ? $decoded['meta'] : [];
            $decoded['meta']['runtime'] = 'dynamic_php_sandbox';
            $decoded['meta']['timeout_seconds'] = $timeout;
            $decoded['meta']['memory_mb'] = $memory;
            $decoded['meta']['workspace'] = 'isolated';
            return $decoded;
        } catch (\Throwable $e) {
            return ['success' => false, 'error' => 'Dynamic PHP runtime could not complete the execution safely.'];
        } finally {
            $this->removeSandboxDirectory($sandbox);
        }
    }

    private function buildRunnerScript(string $source): string
    {
        $template = <<<'PHP'
<?php

declare(strict_types=1);

final class FwtSandboxWorkspace
{
    public function __construct(private string $root) {}

    public function write(string $name, string $content, string $mime = 'application/octet-stream'): array
    {
        $name = basename($name);
        $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name) ?: 'output.bin';
        $path = $this->root . DIRECTORY_SEPARATOR . $name;
        if (file_put_contents($path, $content, LOCK_EX) === false) {
            throw new RuntimeException('Unable to write workspace output.');
        }
        return ['path' => $name, 'name' => $name, 'mime_type' => $mime, 'size' => strlen($content)];
    }

    public function read(string $name): string
    {
        $name = basename($name);
        $path = $this->root . DIRECTORY_SEPARATOR . $name;
        if (!is_file($path)) throw new RuntimeException('Workspace file not found.');
        return (string)file_get_contents($path);
    }

    public function csvParse(string $content, bool $header = true): array
    {
        $stream = fopen('php://temp', 'w+b');
        if (!$stream) throw new RuntimeException('Unable to parse CSV.');
        fwrite($stream, $content); rewind($stream);
        $rows = []; $keys = null;
        while (($fields = fgetcsv($stream, null, ',', '"', '')) !== false) {
            if ($fields === [null] || $fields === []) continue;
            if ($header && $keys === null) { $keys = array_map(static fn($v) => trim((string)$v), $fields); continue; }
            if ($keys !== null) { $row = []; foreach ($keys as $i => $k) $row[$k] = $fields[$i] ?? ''; $rows[] = $row; }
            else $rows[] = $fields;
            if (count($rows) > 10000) throw new RuntimeException('CSV row limit exceeded.');
        }
        fclose($stream); return $rows;
    }

    public function csvCreate(array $rows): string
    {
        $stream = fopen('php://temp', 'w+b');
        if (!$stream) throw new RuntimeException('Unable to create CSV.');
        if ($rows !== [] && is_array(reset($rows)) && !array_is_list(reset($rows))) fputcsv($stream, array_keys(reset($rows)));
        foreach ($rows as $row) fputcsv($stream, is_array($row) ? array_values($row) : [(string)$row]);
        rewind($stream); $content = (string)stream_get_contents($stream); fclose($stream); return $content;
    }

    public function list(): array
    {
        $items = scandir($this->root) ?: [];
        return array_values(array_filter($items, static fn($v) => $v !== '.' && $v !== '..'));
    }
}

$payload = json_decode(stream_get_contents(STDIN), true);
if (!is_array($payload)) {
    echo json_encode(['success' => false, 'error' => 'Invalid runtime input.']); exit(0);
}

$input = is_array($payload['input'] ?? null) ? $payload['input'] : [];
$context = is_array($payload['context'] ?? null) ? $payload['context'] : [];
$workspace = new FwtSandboxWorkspace(__DIR__ . DIRECTORY_SEPARATOR . 'workspace');
$context['workspace'] = $workspace;
$context['files'] = $workspace;
$context['capabilities'] = ['workspace','csv','json','hash','text'];

set_error_handler(static function (int $severity, string $message): never {
    throw new ErrorException($message, 0, $severity);
});

try {
    $runner = static function (array $input, array $context): mixed {
/*__FWT_DYNAMIC_SOURCE__*/
    };

    $result = $runner($input, $context);
    if (is_array($result) && array_key_exists('success', $result)) {
        $normalized = $result;
        if (($normalized['success'] ?? false) === true) {
            if (!array_key_exists('value', $normalized) && array_key_exists('data', $normalized)) $normalized['value'] = $normalized['data'];
            if (!array_key_exists('data', $normalized) && array_key_exists('value', $normalized)) $normalized['data'] = $normalized['value'];
            if (!isset($normalized['type'])) $normalized['type'] = (is_array($normalized['value'] ?? null) || is_object($normalized['value'] ?? null)) ? 'JSON' : 'TEXT';
        }
    } else {
        $type = (is_array($result) || is_object($result)) ? 'JSON' : 'TEXT';
        $normalized = ['success'=>true,'type'=>$type,'value'=>$result,'data'=>$result,'meta'=>[]];
    }

    echo (string)json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    echo (string)json_encode(['success'=>false,'error'=>'Dynamic PHP execution failed: '.$e->getMessage()], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
PHP;
        return str_replace('/*__FWT_DYNAMIC_SOURCE__*/', $source, $template);
    }

    private function createSandboxDirectory(): string
    {
        $base = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'favorite-web-tools-runtime';
        if (!is_dir($base) && !@mkdir($base, 0700, true) && !is_dir($base)) {
            throw new RuntimeException('Unable to create runtime temp directory.');
        }

        $dir = $base . DIRECTORY_SEPARATOR . bin2hex(random_bytes(12));
        if (!@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('Unable to create Dynamic PHP sandbox.');
        }
        return $dir;
    }

    private function removeSandboxDirectory(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = @scandir($dir) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && !is_link($path)) {
                $this->removeSandboxDirectory($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    private function resolvePhpBinary(): ?string
    {
        $candidates = [];
        if (defined('PHP_BINARY') && PHP_BINARY !== '') {
            $candidates[] = PHP_BINARY;
        }
        if (defined('PHP_BINDIR') && PHP_BINDIR !== '') {
            $candidates[] = rtrim(PHP_BINDIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . (DIRECTORY_SEPARATOR === '\\' ? 'php.exe' : 'php');
        }
        if (DIRECTORY_SEPARATOR !== '\\') {
            $candidates[] = '/usr/bin/php';
            $candidates[] = '/usr/local/bin/php';
        }

        foreach (array_unique($candidates) as $candidate) {
            if (!is_string($candidate) || $candidate === '' || !is_file($candidate)) {
                continue;
            }
            $base = strtolower(basename($candidate));
            if (!preg_match('/^php(?:[0-9.]+)?(?:\.exe)?$/', $base)) {
                continue;
            }
            if (DIRECTORY_SEPARATOR === '\\' || is_executable($candidate)) {
                return $candidate;
            }
        }
        return null;
    }

    private function sanitizeChildError(string $message): string
    {
        $message = (string)preg_replace('#[A-Za-z]:[\\\\/][^\s]+#', '[path]', $message);
        $message = (string)preg_replace('#/(?:tmp|var|home|usr|opt)/[^\s]+#', '[path]', $message);
        $message = trim($message);
        if ($message === '' || strlen($message) > 500) {
            return 'Dynamic PHP execution failed.';
        }
        return $message;
    }
}

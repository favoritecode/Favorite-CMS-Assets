<?php

declare(strict_types=1);

namespace FavoriteCMS\Tools\Services;

use FavoriteCMS\Tools\Repositories\SecretRepository;
use RuntimeException;

final class SecretVaultService
{
    public function __construct(private SecretRepository $repo) {}

    public function store(string $key, string $label, string $plain, array $scope = [], string $status = 'active', int $id = 0): void
    {
        if (!preg_match('/^[A-Z][A-Z0-9_]{1,149}$/', $key)) {
            throw new RuntimeException('Secret key must use uppercase letters, numbers, and underscores.');
        }
        if ($plain === '' && $id <= 0) {
            throw new RuntimeException('Secret value cannot be empty.');
        }
        $existing = $id > 0 ? $this->repo->find($id) : null;
        $cipher = $plain !== '' ? $this->encrypt($plain) : (string)($existing?->encrypted_value ?? '');
        if ($cipher === '') throw new RuntimeException('Unable to preserve secret value.');
        $this->repo->save(['secret_key'=>$key,'label'=>$label ?: $key,'encrypted_value'=>$cipher,'scope'=>$scope,'status'=>$status], $id);
    }

    public function resolve(string $key, ?string $toolSlug = null, ?string $operationId = null): ?string
    {
        $record = $this->repo->findByKey($key);
        if (!$record || !$record->isActive()) return null;
        $scope = $record->scope;
        if (!empty($scope['tools']) && is_array($scope['tools']) && $toolSlug !== null && !in_array($toolSlug, $scope['tools'], true)) return null;
        if (!empty($scope['operations']) && is_array($scope['operations']) && $operationId !== null && !in_array($operationId, $scope['operations'], true)) return null;
        return $this->decrypt($record->encrypted_value);
    }

    public function mask(string $cipher): string
    {
        return $cipher === '' ? '' : '••••••••••••';
    }

    public function isAvailable(): bool
    {
        return function_exists('openssl_encrypt') || function_exists('sodium_crypto_secretbox');
    }

    private function encrypt(string $plain): string
    {
        $key = $this->key();
        if (function_exists('sodium_crypto_secretbox')) {
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = sodium_crypto_secretbox($plain, $nonce, $key);
            return 'sodium:' . base64_encode($nonce . $cipher);
        }
        if (function_exists('openssl_encrypt')) {
            $iv = random_bytes(12);
            $tag = '';
            $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if ($cipher === false) throw new RuntimeException('Secret encryption failed.');
            return 'gcm:' . base64_encode($iv . $tag . $cipher);
        }
        throw new RuntimeException('No supported server-side encryption extension is available.');
    }

    private function decrypt(string $stored): ?string
    {
        try {
            $key = $this->key();
            if (str_starts_with($stored, 'sodium:')) {
                $raw = base64_decode(substr($stored, 7), true);
                if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return null;
                $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $plain = sodium_crypto_secretbox_open($cipher, $nonce, $key);
                return is_string($plain) ? $plain : null;
            }
            if (str_starts_with($stored, 'gcm:')) {
                $raw = base64_decode(substr($stored, 4), true);
                if (!is_string($raw) || strlen($raw) < 29) return null;
                $iv = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $cipher = substr($raw, 28);
                $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
                return is_string($plain) ? $plain : null;
            }
        } catch (\Throwable) {}
        return null;
    }

    private function key(): string
    {
        $material = '';
        foreach (['FWT_SECRET_KEY','FAVORITE_CMS_SECRET','APP_KEY'] as $constant) {
            if (defined($constant) && is_string(constant($constant)) && constant($constant) !== '') { $material = constant($constant); break; }
        }
        if ($material === '') {
            foreach (['FWT_SECRET_KEY','FAVORITE_CMS_SECRET','APP_KEY'] as $envKey) {
                $value = getenv($envKey);
                if (is_string($value) && $value !== '') { $material = $value; break; }
            }
        }
        if ($material === '') {
            $path = function_exists('storage_path') ? storage_path('favorite-web-tools/secret.key') : sys_get_temp_dir() . '/favorite-web-tools-secret.key';
            $dir = dirname($path);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            if (is_file($path)) $material = trim((string)@file_get_contents($path));
            if ($material === '') {
                $material = bin2hex(random_bytes(32));
                if (@file_put_contents($path, $material, LOCK_EX) === false) throw new RuntimeException('A persistent secret encryption key could not be created. Configure FWT_SECRET_KEY.');
                @chmod($path, 0600);
            }
        }
        return hash('sha256', $material, true);
    }
}

# Favorite Web Tools v1.4.0 — Final Universal Platform

## Purpose

v1.4.0 converts Favorite Web Tools from a collection of hard-coded tool implementations into an admin-driven platform. Existing tools and engines remain supported. Ordinary future tools should be created from **Web Tools → Create Tool** and the reusable platform sections, without editing plugin source code.

## Existing engines preserved

- PHP (Controlled Handler)
- Dynamic PHP Runtime (Sandboxed)
- HTML Engine
- CSS Engine
- JavaScript Engine
- Python API Service
- Generic HTTP API
- Dynamic Handlers
- Frontend Presentation Designs

## New reusable platform layer

### Dynamic Operations

`Web Tools → Dynamic Operations`

Create reusable operations backed by:

- Built-in Safe Capability
- Sandboxed PHP
- Generic HTTP API
- Python API
- Controlled Handler

Operations are immediately available inside Dynamic Handler pipelines. Built-in seeded capabilities include `trim`, `lowercase`, `uppercase`, `slugify`, `csv_parse`, `csv_create`, `qr_generate`, `file_output`, `zip_create`, and `image_resize`.

Bindings support values such as `{{input.name}}`, `{{current}}`, `{{step.previous.value}}`, `{{secret.API_KEY}}`, and `{{context.tool_slug}}`.

### Dynamic Handlers as pipelines

Dynamic Handlers now support ordered steps, reusable Dynamic Operations, `when` conditions, optional/error strategy, `foreach`, output mappings, file-oriented result types, and bulk/array values. Existing built-in pipeline operations remain backward compatible.

### Dynamic PHP Runtime

Dynamic PHP remains a separate PHP CLI subprocess; it does not execute with `eval()` in the CMS request. `open_basedir`, disabled functions, timeout, memory and output limits remain enforced.

It now receives a per-execution isolated workspace through `$context['workspace']` / `$context['files']` for safe temporary file processing. It cannot access arbitrary filesystem locations, CMS source/config, internal network, shell/process commands, or CMS DB/classes. Files returned from the workspace are converted into controlled download references before the sandbox is deleted.

### Files and output

The common platform provides:

- normalized upload handling and executable-extension blocking
- safe temporary/generated files
- secure download references
- CSV helpers
- ZIP capability when ZipArchive is available
- image resize/convert capability when GD is available
- server-side QR capability
- normalized text/JSON/file output contracts

### Secrets

`Web Tools → Secrets`

Secret values are encrypted server-side, displayed masked, referenced by name, and are never exported in tool packages or returned to public frontend configuration. HTTP/Dynamic Operation bindings can resolve approved secret references server-side.

### Frontend Libraries / Assets

`Web Tools → Frontend Libraries / Assets`

Admins can register approved HTTPS/local JS/CSS assets. A tool can attach asset keys in **Universal Platform Controls**. Only assets attached to that tool are injected into the active theme's existing head hook. The plugin does not create or replace the site header/footer.

### PHP Libraries

`Web Tools → PHP Libraries`

This is a safe registry/health layer for approved or pre-installed server packages and capability adapters. It does **not** expose arbitrary public Composer command execution. Hosting environments that do not permit safe runtime package installation should pre-install packages and register them here.

### Tool revisions, duplicate, import/export

- Every tool create/update/status change attempts to save an immutable revision snapshot.
- Edit screens can restore a previous revision as **DRAFT**.
- **Duplicate Tool** creates a new unique slug and DRAFT copy.
- **Export** produces a portable JSON tool definition.
- **Import Tool JSON** always creates a new DRAFT with a collision-safe slug.
- Secret values are never exported.

Dynamic Handlers and Dynamic Operations also have JSON import/export support; imports are disabled by default until reviewed.

### Execution logs, limits and health

- optional per-tool requests/minute
- upload/bulk/output configuration
- safe execution logs without full sensitive input
- `Web Tools → System Health` for PHP/runtime/extension/temp checks
- old log cleanup

## Recommended future-tool workflow

1. Register any needed secret, frontend asset, Python service, or API connection.
2. Reuse or create Dynamic Operations for reusable server capabilities.
3. Create a Dynamic Handler pipeline when multiple operations are required.
4. Create Tool and choose the best engine.
5. Configure Input / Output / UI Schema.
6. Select/create a Frontend Presentation Design and attach asset keys.
7. Test from the admin console.
8. Publish only after preview passes.

## Which engine should I use?

- **Browser-only UI/transformation:** HTML/CSS/JavaScript.
- **Safe custom PHP algorithm / temporary file workflow:** Dynamic PHP Runtime.
- **Reusable configurable chain:** Dynamic Handler + Dynamic Operations.
- **External REST service:** Generic HTTP API.
- **OCR/AI/heavy processing service:** Python API.
- **Deep CMS privilege/internal trusted logic:** Controlled Handler.

A plugin source update should only be necessary for a genuinely new platform-level infrastructure capability that cannot be represented by those engines/capabilities.

## Security boundary

No ordinary dynamic tool gets unrestricted `eval`, arbitrary shell commands, arbitrary filesystem, arbitrary includes, CMS credentials, or internal-network access. Admin mutations remain permission + CSRF protected. Public execution remains subject to tool status/access checks, validation and configured rate limits.

## Active theme ownership

Favorite Web Tools provides tool content only. The active Favorite CMS theme remains the owner of the public HTML shell, header, footer, navigation, and global appearance. Registered frontend assets are injected through the theme's existing head variable, not by generating a second header/footer.

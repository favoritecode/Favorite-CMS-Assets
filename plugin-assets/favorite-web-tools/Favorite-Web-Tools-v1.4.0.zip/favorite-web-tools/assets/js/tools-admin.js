/**
 * Favorite Web Tools - Admin JavaScript
 *
 * The Favorite CMS admin appearance is authoritative. Some CMS builds apply
 * dark mode through computed shell colors rather than a stable html/body
 * `dark` class, so Web Tools detects the actual admin shell and mirrors it on
 * `.fwt-admin-wrap` as `fwt-dark` / `fwt-light`.
 */
(function () {
    'use strict';

    function parseColor(value) {
        if (!value || value === 'transparent') return null;
        const match = value.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)/i);
        if (!match) return null;
        return {
            r: Number(match[1]),
            g: Number(match[2]),
            b: Number(match[3]),
            a: match[4] === undefined ? 1 : Number(match[4])
        };
    }

    function isDarkRgb(rgb) {
        if (!rgb || rgb.a <= 0.05) return null;
        // Perceived luminance is enough for distinguishing the CMS shell's
        // slate/navy dark theme from the light admin theme.
        const luminance = (0.2126 * rgb.r + 0.7152 * rgb.g + 0.0722 * rgb.b) / 255;
        return luminance < 0.48;
    }

    function explicitThemeState() {
        const html = document.documentElement;
        const body = document.body;
        const values = [];

        [html, body].forEach(function (el) {
            if (!el) return;
            values.push(el.getAttribute('data-theme'));
            values.push(el.getAttribute('data-color-scheme'));
            values.push(el.getAttribute('data-mode'));
            const cls = String(el.className || '').toLowerCase();
            if (/(^|\s)(dark|dark-mode|theme-dark|admin-dark)(\s|$)/.test(cls)) values.push('dark');
            if (/(^|\s)(light|light-mode|theme-light|admin-light)(\s|$)/.test(cls)) values.push('light');
        });

        try {
            ['admin_theme', 'admin-theme', 'theme', 'appearance', 'color-scheme'].forEach(function (key) {
                values.push(window.localStorage ? localStorage.getItem(key) : null);
            });
        } catch (e) {}

        for (const value of values) {
            const v = String(value || '').trim().toLowerCase();
            if (v === 'dark' || v.includes('dark')) return true;
            if (v === 'light' || v.includes('light')) return false;
        }
        return null;
    }

    function computedShellState() {
        const selectors = [
            '.wp-content',
            'main.wp-content',
            '.wp-body',
            '.wp-sidebar',
            '.plugin-page-card',
            '#wpbody-content',
            '#wpcontent',
            'body'
        ];

        for (const selector of selectors) {
            const el = document.querySelector(selector);
            if (!el) continue;
            const rgb = parseColor(getComputedStyle(el).backgroundColor);
            const state = isDarkRgb(rgb);
            if (state !== null) return state;
        }
        return null;
    }

    function resolveCmsAdminDark() {
        const explicit = explicitThemeState();
        if (explicit !== null) return explicit;

        const computed = computedShellState();
        if (computed !== null) return computed;

        return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }

    function syncAdminMode() {
        const dark = resolveCmsAdminDark();
        document.documentElement.classList.toggle('fwt-admin-dark', dark);
        document.documentElement.classList.toggle('fwt-admin-light', !dark);
        document.querySelectorAll('.fwt-admin-wrap').forEach(function (wrap) {
            wrap.classList.toggle('fwt-dark', dark);
            wrap.classList.toggle('fwt-light', !dark);
            wrap.setAttribute('data-fwt-color-mode', dark ? 'dark' : 'light');
        });
    }

    function setupThemeSync() {
        syncAdminMode();

        const observer = new MutationObserver(function () {
            // Core theme toggles can update classes/styles in more than one
            // microtask; sync on the next frame after the CMS finishes.
            requestAnimationFrame(syncAdminMode);
        });

        [document.documentElement, document.body].forEach(function (el) {
            if (!el) return;
            observer.observe(el, {
                attributes: true,
                attributeFilter: ['class', 'style', 'data-theme', 'data-color-scheme', 'data-mode']
            });
        });

        document.addEventListener('click', function (event) {
            const target = event.target && event.target.closest
                ? event.target.closest('#admin-theme-toggle, [data-theme-toggle], .theme-toggle, .admin-theme-toggle, [aria-label*="theme" i], [title*="theme" i]')
                : null;
            if (!target) return;
            [0, 50, 150, 350].forEach(function (delay) {
                setTimeout(syncAdminMode, delay);
            });
        }, true);

        if (window.matchMedia) {
            const mq = window.matchMedia('(prefers-color-scheme: dark)');
            if (mq.addEventListener) mq.addEventListener('change', syncAdminMode);
            else if (mq.addListener) mq.addListener(syncAdminMode);
        }

        // A few delayed passes cover admin shells that restore their saved
        // appearance after plugin content has already been rendered.
        [50, 200, 600, 1200].forEach(function (delay) {
            setTimeout(syncAdminMode, delay);
        });
    }

    function setupJsonFormatting() {
        const jsonFields = document.querySelectorAll('textarea[name$="_schema"]');
        jsonFields.forEach(function (field) {
            field.addEventListener('blur', function () {
                const val = field.value.trim();
                if (val !== '') {
                    try {
                        const parsed = JSON.parse(val);
                        field.value = JSON.stringify(parsed, null, 2);
                    } catch (e) {
                        // Keep raw if invalid JSON
                    }
                }
            });
        });
    }

    function init() {
        setupThemeSync();
        setupJsonFormatting();
    }

    // Prime a document-level marker immediately. The Web Tools content comes
    // after this script in the admin response, so the CSS can paint newly
    // parsed plugin cards in the correct mode without a white flash.
    try {
        const initialDark = resolveCmsAdminDark();
        document.documentElement.classList.toggle('fwt-admin-dark', initialDark);
        document.documentElement.classList.toggle('fwt-admin-light', !initialDark);
    } catch (e) {}

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();

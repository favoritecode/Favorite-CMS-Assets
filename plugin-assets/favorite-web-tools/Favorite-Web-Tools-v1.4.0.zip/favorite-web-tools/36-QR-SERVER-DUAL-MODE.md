# QR Server-Side Dual Mode

Favorite Web Tools now exposes one shared server-side QR service through two execution paths without browser-side QR generation.

## Option A — Controlled Handler

Create a tool and choose:

- Canonical Engine: `PHP (Controlled Handler)`
- Registered Controlled Handler: `QR Code Generator (Server-side)`
- Internal handler ID: `qr_code_generator`

Use the schemas under `examples/qr-dual-mode/`.

## Option B — Generic HTTP API

Create another tool and choose:

- Canonical Engine: `Generic HTTP API`
- Method: `POST`
- Endpoint: `https://YOUR-SITE/api/web-tools/qr-code/generate`
- Body mode: `JSON` for normal inputs or `Multipart / File Upload` for CSV uploads
- Allowed Hosts: your own public site hostname

The HTTP endpoint and Controlled Handler both call the same `QrCodeService` implementation. QR generation, CSV parsing, validation, PNG creation, duplicate filename handling, and ZIP generation are not duplicated.

## Supported Inputs

- one URL or multiple URLs
- CSV with `title,url`
- quoted CSV values containing commas
- custom title/filename
- foreground/background colors
- 0–20 px visual border and border color
- 100–400 px PNG size
- transparent PNG
- maximum 100 items per request
- maximum 2 MB CSV upload

Only `http://` and `https://` URLs are accepted.

## Output

Single item:

- server-generated PNG
- secure temporary download URL

Multiple items:

- server-generated PNG files packaged into one ZIP
- secure temporary ZIP download URL

Generated files use the existing `/api/tools/download/{reference}` mechanism and expire under the plugin's existing cleanup policy.

## Security Notes

- no QRCode.js or JSZip is required for final QR processing
- no `eval()` or shell execution
- no server filesystem path is returned to public users
- uploaded CSV size is bounded
- filenames are sanitized
- path traversal is blocked by generated filenames and the existing download manager
- the HTTP engine retains its SSRF/public-host restrictions

## Compatibility

Existing Controlled Handlers, Dynamic Handlers, Python API tools, Generic HTTP API tools, frontend designs, access modes, routes, and existing tool records remain unchanged. No database migration is required for this QR upgrade.

## Encoder Scope

The built-in QR encoder uses QR Model 2 byte mode, error correction level L, versions 1–10. It is intended for ordinary web URLs and returns a controlled validation error for payloads beyond its supported URL capacity instead of failing or silently producing invalid output.

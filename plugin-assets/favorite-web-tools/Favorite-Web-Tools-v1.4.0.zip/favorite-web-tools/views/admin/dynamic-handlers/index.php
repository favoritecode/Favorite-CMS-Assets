<?php
/** @var array $handlers */
?>
<div class="fwt-admin-wrap" style="max-width:1100px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1e293b;">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:20px;">
        <div>
            <h1 style="margin:0 0 6px;font-size:24px;">Dynamic Controlled Handlers</h1>
            <p style="margin:0;color:#64748b;font-size:13px;">Build reusable server-side tool handlers from safe, allowlisted operations. No plugin source edit or PHP class is required.</p>
        </div>
        <div style="display:flex;gap:8px;align-items:center;">
            <details style="position:relative;"><summary style="list-style:none;cursor:pointer;padding:9px 13px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;font-weight:700;">Import JSON</summary>
                <form method="POST" enctype="multipart/form-data" action="/admin/page/favorite-web-tools-dynamic-handlers" style="position:absolute;right:0;z-index:20;width:340px;background:#fff;border:1px solid #cbd5e1;border-radius:8px;padding:12px;margin-top:8px;box-shadow:0 10px 28px rgba(15,23,42,.15);">
                    <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8'); ?>"><input type="hidden" name="action" value="import">
                    <input type="file" name="handler_package" accept="application/json,.json" style="width:100%;margin-bottom:8px;">
                    <textarea name="package_json" rows="4" placeholder="...or paste handler package JSON" style="width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:6px;font-family:monospace;font-size:11px;"></textarea>
                    <button type="submit" style="margin-top:8px;padding:7px 10px;background:#0f766e;color:#fff;border:0;border-radius:6px;cursor:pointer;font-weight:700;">Import Disabled</button>
                </form>
            </details>
            <a href="/admin/page/favorite-web-tools-dynamic-handlers?action=create" style="padding:10px 16px;border-radius:7px;background:#2563eb;color:#fff;text-decoration:none;font-weight:700;">+ Create Handler</a>
        </div>
    </div>

    <?php if (!empty($flashSuccess)): ?><div style="padding:12px 14px;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;margin-bottom:16px;color:#065f46;"><?php echo htmlspecialchars($flashSuccess, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
    <?php if (!empty($flashError)): ?><div style="padding:12px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;margin-bottom:16px;color:#991b1b;"><?php echo htmlspecialchars($flashError, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
            <thead><tr style="background:#f8fafc;text-align:left;"><th style="padding:12px;">Name</th><th style="padding:12px;">Handler ID</th><th style="padding:12px;">Status</th><th style="padding:12px;">Steps</th><th style="padding:12px;text-align:right;">Actions</th></tr></thead>
            <tbody>
            <?php if (empty($handlers)): ?>
                <tr><td colspan="5" style="padding:32px;text-align:center;color:#64748b;">No dynamic handlers yet.</td></tr>
            <?php else: foreach ($handlers as $handler): ?>
                <tr style="border-top:1px solid #e2e8f0;">
                    <td style="padding:12px;font-weight:700;"><?php echo htmlspecialchars($handler->name, ENT_QUOTES, 'UTF-8'); ?><div style="font-weight:400;color:#64748b;margin-top:3px;"><?php echo htmlspecialchars($handler->description, ENT_QUOTES, 'UTF-8'); ?></div></td>
                    <td style="padding:12px;"><code><?php echo htmlspecialchars($handler->handler_id, ENT_QUOTES, 'UTF-8'); ?></code></td>
                    <td style="padding:12px;"><?php echo $handler->isActive() ? '🟢 Active' : '⚪ Disabled'; ?></td>
                    <td style="padding:12px;"><?php echo count($handler->definition['steps'] ?? []); ?></td>
                    <td style="padding:12px;text-align:right;"><a href="/admin/page/favorite-web-tools-dynamic-handlers?action=edit&id=<?php echo (int)$handler->id; ?>" style="color:#2563eb;text-decoration:none;font-weight:600;margin-right:10px;">Edit</a><a href="/admin/page/favorite-web-tools-dynamic-handlers?action=export&id=<?php echo (int)$handler->id; ?>" style="color:#7c3aed;text-decoration:none;font-weight:600;">Export</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top:16px;"><a href="/admin/page/favorite-web-tools" style="color:#2563eb;text-decoration:none;">← Back to Web Tools</a></div>
</div>

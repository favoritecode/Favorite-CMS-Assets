<?php
$definitionJson = json_encode($handler->definition, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
<div class="fwt-admin-wrap" style="max-width:980px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1e293b;">
    <div style="margin-bottom:20px;">
        <a href="/admin/page/favorite-web-tools-dynamic-handlers" style="color:#2563eb;text-decoration:none;font-size:13px;">← Back to Dynamic Handlers</a>
        <h1 style="font-size:24px;margin:8px 0 5px;"><?php echo $handler->id ? 'Edit Dynamic Handler' : 'Create Dynamic Handler'; ?></h1>
        <p style="margin:0;color:#64748b;font-size:13px;">Configuration-driven only: no eval(), shell commands, arbitrary file access, or executable PHP source.</p>
    </div>

    <?php if (!empty($flashError)): ?><div style="padding:12px 14px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;margin-bottom:16px;color:#991b1b;"><?php echo htmlspecialchars($flashError, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

    <form method="POST" action="/admin/page/favorite-web-tools-dynamic-handlers" style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:24px;">
        <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?php echo (int)($handler->id ?? 0); ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
            <div><label style="display:block;font-weight:700;font-size:13px;margin-bottom:6px;">Name *</label><input name="name" required value="<?php echo htmlspecialchars($handler->name, ENT_QUOTES, 'UTF-8'); ?>" style="width:100%;box-sizing:border-box;padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;"></div>
            <div><label style="display:block;font-weight:700;font-size:13px;margin-bottom:6px;">Handler ID *</label><input name="handler_id" required value="<?php echo htmlspecialchars($handler->handler_id, ENT_QUOTES, 'UTF-8'); ?>" placeholder="my_custom_transform" style="width:100%;box-sizing:border-box;padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;font-family:monospace;"></div>
        </div>
        <div style="margin-bottom:16px;"><label style="display:block;font-weight:700;font-size:13px;margin-bottom:6px;">Description</label><textarea name="description" rows="2" style="width:100%;box-sizing:border-box;padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;"><?php echo htmlspecialchars($handler->description, ENT_QUOTES, 'UTF-8'); ?></textarea></div>
        <div style="margin-bottom:16px;"><label style="display:block;font-weight:700;font-size:13px;margin-bottom:6px;">Status</label><select name="status" style="padding:9px 11px;border:1px solid #cbd5e1;border-radius:6px;"><option value="active" <?php echo $handler->status === 'active' ? 'selected' : ''; ?>>Active</option><option value="disabled" <?php echo $handler->status === 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></div>

        <div style="display:grid;grid-template-columns:minmax(0,1.4fr) minmax(260px,.6fr);gap:18px;align-items:start;">
            <div>
                <label style="display:block;font-weight:700;font-size:13px;margin-bottom:6px;">Handler Definition (JSON)</label>
                <textarea name="definition" rows="20" style="width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #cbd5e1;border-radius:6px;font:12px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;"><?php echo htmlspecialchars((string)$definitionJson, ENT_QUOTES, 'UTF-8'); ?></textarea>
                <div style="font-size:11px;color:#64748b;margin-top:5px;">Pipeline starts from <code>input_key</code>. Each step executes one allowlisted operation. Result is normalized through the existing ToolExecutionService.</div>
            </div>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px;">
                <strong style="font-size:13px;">Allowed Operations</strong>
                <div style="margin-top:10px;display:flex;flex-direction:column;gap:6px;font-size:12px;">
                    <?php foreach ($allowedOperations as $op => $label): ?><div><code><?php echo htmlspecialchars($op, ENT_QUOTES, 'UTF-8'); ?></code> — <?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?></div><?php endforeach; ?>
                </div>
                <hr style="border:0;border-top:1px solid #e2e8f0;margin:14px 0;">
                <div style="font-size:12px;color:#475569;"><strong>Example</strong><pre style="white-space:pre-wrap;background:#fff;border:1px solid #e2e8f0;padding:8px;border-radius:6px;overflow:auto;">{
  "input_key": "text",
  "result_type": "TEXT",
  "steps": [
    {"operation":"trim"},
    {"operation":"uppercase"}
  ]
}</pre></div>
            </div>
        </div>

        <div style="display:flex;gap:10px;margin-top:20px;padding-top:16px;border-top:1px solid #e2e8f0;">
            <button type="submit" style="padding:10px 18px;border:0;border-radius:6px;background:#2563eb;color:white;font-weight:700;cursor:pointer;">Save Handler</button>
            <a href="/admin/page/favorite-web-tools-dynamic-handlers" style="padding:10px 12px;color:#475569;text-decoration:none;">Cancel</a>
        </div>
    </form>

    <?php if ($handler->id): ?>
    <form method="POST" action="/admin/page/favorite-web-tools-dynamic-handlers" onsubmit="return confirm('Delete this dynamic handler? Tools using it will stop executing until reassigned.');" style="margin-top:14px;">
        <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$handler->id; ?>">
        <button type="submit" style="padding:8px 12px;border:1px solid #fecaca;border-radius:6px;background:#fff;color:#b91c1c;cursor:pointer;">Delete Handler</button>
    </form>
    <?php endif; ?>
</div>

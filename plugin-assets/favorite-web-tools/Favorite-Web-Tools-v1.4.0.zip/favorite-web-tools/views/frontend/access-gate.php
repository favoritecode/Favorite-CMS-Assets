<?php
/**
 * Frontend Access Gate View
 *
 * Variables:
 * - $mode : 'LOGIN_REQUIRED' | 'MEMBERSHIP_REQUIRED'
 * - $tool : Tool
 */
?>
<div class="fwt-access-gate">
    <?php if ($mode === 'LOGIN_REQUIRED'): ?>
        <div class="fwt-access-gate-icon" aria-hidden="true">🔒</div>
        <h3 class="fwt-access-gate-title">Login Required</h3>
        <p class="fwt-access-gate-text">
            You must be logged in to use <strong><?php echo htmlspecialchars($tool->name, ENT_QUOTES, 'UTF-8'); ?></strong>.
        </p>
        <div class="fwt-access-gate-actions">
            <a href="/login?redirect=<?php echo urlencode('/tools/' . $tool->slug); ?>" class="fwt-btn fwt-btn-primary fwt-access-gate-btn">
                Log In to Continue
            </a>
            <a href="/register?redirect=<?php echo urlencode('/tools/' . $tool->slug); ?>" class="fwt-btn fwt-btn-secondary fwt-access-gate-btn">
                Create Account
            </a>
        </div>
    <?php else: ?>
        <div class="fwt-access-gate-icon" aria-hidden="true">⭐</div>
        <h3 class="fwt-access-gate-title">Membership Required</h3>
        <p class="fwt-access-gate-text">
            An active membership is required to access <strong><?php echo htmlspecialchars($tool->name, ENT_QUOTES, 'UTF-8'); ?></strong>. Members enjoy unlimited access to all tools.
        </p>
        <div class="fwt-access-gate-actions">
            <?php if (empty($_SESSION['auth_user_id'])): ?>
                <a href="/login?redirect=<?php echo urlencode('/tools/' . $tool->slug); ?>" class="fwt-btn fwt-btn-primary fwt-access-gate-btn">
                    Log In with Account
                </a>
            <?php endif; ?>
            <a href="/account/membership" class="fwt-btn fwt-access-gate-btn fwt-btn-membership">
                View Membership Plans
            </a>
        </div>
    <?php endif; ?>
</div>

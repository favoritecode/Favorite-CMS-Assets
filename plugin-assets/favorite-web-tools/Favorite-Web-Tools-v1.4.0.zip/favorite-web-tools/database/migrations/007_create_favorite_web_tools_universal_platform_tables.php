<?php

declare(strict_types=1);

use FavoriteCMS\Core\Database;

/**
 * Favorite Web Tools — Migration 007: Final Universal Platform tables.
 *
 * Additive/backward-compatible only. Existing tools/handlers/designs remain untouched.
 */
class CreateFavoriteWebToolsUniversalPlatformTables
{
    public function __construct(protected Database $db)
    {
        if (method_exists($this->db, 'registerPrefixableTables')) {
            $this->db->registerPrefixableTables([
                'favorite_web_tool_dynamic_operations',
                'favorite_web_tool_secrets',
                'favorite_web_tool_libraries',
                'favorite_web_tool_assets',
                'favorite_web_tool_execution_logs',
                'favorite_web_tool_revisions',
                'favorite_web_tool_operation_revisions',
            ]);
        }
    }

    public function up(): void
    {
        $sqlite = $this->isSqlite();
        $engine = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        $pk = $sqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT AUTO_INCREMENT PRIMARY KEY';
        $updated = $sqlite ? 'DATETIME DEFAULT CURRENT_TIMESTAMP' : 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP';
        $long = $sqlite ? 'TEXT' : 'LONGTEXT';

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_dynamic_operations` (
            `id` {$pk},
            `operation_id` VARCHAR(120) NOT NULL UNIQUE,
            `name` VARCHAR(160) NOT NULL,
            `description` TEXT NULL,
            `executor_type` VARCHAR(40) NOT NULL DEFAULT 'BUILTIN',
            `version` INT NOT NULL DEFAULT 1,
            `status` VARCHAR(32) NOT NULL DEFAULT 'active',
            `parameter_schema` {$long} NULL,
            `configuration` {$long} NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` {$updated}
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_secrets` (
            `id` {$pk},
            `secret_key` VARCHAR(150) NOT NULL UNIQUE,
            `label` VARCHAR(180) NOT NULL,
            `encrypted_value` {$long} NOT NULL,
            `scope` {$long} NULL,
            `status` VARCHAR(32) NOT NULL DEFAULT 'active',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` {$updated}
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_libraries` (
            `id` {$pk},
            `library_key` VARCHAR(160) NOT NULL UNIQUE,
            `name` VARCHAR(180) NOT NULL,
            `library_type` VARCHAR(32) NOT NULL DEFAULT 'PHP',
            `package_name` VARCHAR(255) NULL,
            `version` VARCHAR(80) NULL,
            `capabilities` {$long} NULL,
            `configuration` {$long} NULL,
            `status` VARCHAR(32) NOT NULL DEFAULT 'active',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` {$updated}
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_assets` (
            `id` {$pk},
            `asset_key` VARCHAR(160) NOT NULL UNIQUE,
            `name` VARCHAR(180) NOT NULL,
            `asset_type` VARCHAR(32) NOT NULL DEFAULT 'JS',
            `source_type` VARCHAR(32) NOT NULL DEFAULT 'CDN',
            `url` TEXT NULL,
            `integrity` VARCHAR(255) NULL,
            `crossorigin` VARCHAR(64) NULL,
            `load_order` INT NOT NULL DEFAULT 100,
            `configuration` {$long} NULL,
            `status` VARCHAR(32) NOT NULL DEFAULT 'active',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` {$updated}
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_execution_logs` (
            `id` {$pk},
            `tool_id` BIGINT NULL,
            `tool_slug` VARCHAR(180) NULL,
            `engine` VARCHAR(64) NULL,
            `status` VARCHAR(32) NOT NULL,
            `duration_ms` DECIMAL(12,2) NULL,
            `user_id` BIGINT NULL,
            `is_anonymous` TINYINT NOT NULL DEFAULT 1,
            `error_code` VARCHAR(100) NULL,
            `file_count` INT NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_revisions` (
            `id` {$pk},
            `tool_id` BIGINT NOT NULL,
            `revision_no` INT NOT NULL,
            `revision_status` VARCHAR(32) NOT NULL DEFAULT 'draft',
            `snapshot` {$long} NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ){$engine}");

        $this->db->execute("CREATE TABLE IF NOT EXISTS `favorite_web_tool_operation_revisions` (
            `id` {$pk},
            `operation_id` BIGINT NOT NULL,
            `version` INT NOT NULL,
            `snapshot` {$long} NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ){$engine}");

        foreach ([
            ['favorite_web_tool_dynamic_operations', 'idx_fwt_operation_status', '`status`'],
            ['favorite_web_tool_dynamic_operations', 'idx_fwt_operation_executor', '`executor_type`'],
            ['favorite_web_tool_execution_logs', 'idx_fwt_log_tool', '`tool_id`'],
            ['favorite_web_tool_execution_logs', 'idx_fwt_log_created', '`created_at`'],
            ['favorite_web_tool_revisions', 'idx_fwt_revision_tool', '`tool_id`, `revision_no`'],
            ['favorite_web_tool_operation_revisions', 'idx_fwt_operation_revision', '`operation_id`, `version`'],
            ['favorite_web_tool_libraries', 'idx_fwt_library_status', '`status`'],
            ['favorite_web_tool_assets', 'idx_fwt_asset_status', '`status`'],
        ] as [$table, $name, $cols]) {
            $this->createIndexIfNotExists($table, $name, $cols);
        }
    }

    public function down(): void
    {
        // Intentionally non-destructive for platform data. The CMS must never wipe user-created
        // tools/operations/secrets automatically during a rollback/deactivation.
    }

    private function isSqlite(): bool
    {
        try {
            return strtolower((string)$this->db->getConnection()->getAttribute(PDO::ATTR_DRIVER_NAME)) === 'sqlite';
        } catch (Throwable) {
            return false;
        }
    }

    private function createIndexIfNotExists(string $table, string $name, string $cols): void
    {
        try {
            if ($this->isSqlite()) {
                $this->db->execute("CREATE INDEX IF NOT EXISTS `{$name}` ON `{$table}` ({$cols})");
                return;
            }
            $rows = $this->db->select("SHOW INDEX FROM `{$table}` WHERE Key_name = ?", [$name]);
            if (empty($rows)) {
                $this->db->execute("ALTER TABLE `{$table}` ADD INDEX `{$name}` ({$cols})");
            }
        } catch (Throwable) {
            // Index creation must never block an otherwise safe additive migration.
        }
    }
}

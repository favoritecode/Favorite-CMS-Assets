<?php

declare(strict_types=1);

use FavoriteCMS\Core\Database;

/**
 * Favorite Web Tools — Migration 006: reusable configuration-driven controlled handlers.
 */
class CreateFavoriteWebToolDynamicHandlersTable
{
    protected Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
        if (method_exists($this->db, 'registerPrefixableTables')) {
            $this->db->registerPrefixableTables(['favorite_web_tool_dynamic_handlers']);
        }
    }

    public function up(): void
    {
        $isSqlite = $this->isSqlite();
        $engine = $isSqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        $pk = $isSqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT AUTO_INCREMENT PRIMARY KEY';
        $longtext = $isSqlite ? 'TEXT' : 'LONGTEXT';
        $updatedAt = $isSqlite
            ? 'DATETIME DEFAULT CURRENT_TIMESTAMP'
            : 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP';

        $this->db->execute("
            CREATE TABLE IF NOT EXISTS `favorite_web_tool_dynamic_handlers` (
                `id`          {$pk},
                `handler_id`  VARCHAR(150) NOT NULL UNIQUE,
                `name`        VARCHAR(150) NOT NULL,
                `description` TEXT NULL,
                `status`      VARCHAR(32) NOT NULL DEFAULT 'active',
                `definition`  {$longtext} NOT NULL,
                `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at`  {$updatedAt}
            ){$engine};
        ");

        $this->createIndexIfNotExists('favorite_web_tool_dynamic_handlers', 'idx_fwt_dynamic_handler_status', '`status`');
    }

    public function down(): void
    {
        $this->db->execute("DROP TABLE IF EXISTS `favorite_web_tool_dynamic_handlers`");
    }

    protected function isSqlite(): bool
    {
        try {
            return strtolower((string)$this->db->getConnection()->getAttribute(\PDO::ATTR_DRIVER_NAME)) === 'sqlite';
        } catch (\Throwable) {
            return false;
        }
    }

    protected function createIndexIfNotExists(string $table, string $indexName, string $columns): void
    {
        if ($this->isSqlite()) {
            $this->db->execute("CREATE INDEX IF NOT EXISTS `{$indexName}` ON `{$table}` ({$columns})");
            return;
        }
        try {
            $existing = $this->db->select("SHOW INDEX FROM `{$table}` WHERE Key_name = ?", [$indexName]);
            if (empty($existing)) {
                $this->db->execute("ALTER TABLE `{$table}` ADD INDEX `{$indexName}` ({$columns})");
            }
        } catch (\Throwable) {
            try {
                $this->db->execute("ALTER TABLE `{$table}` ADD INDEX `{$indexName}` ({$columns})");
            } catch (\Throwable) {
            }
        }
    }
}

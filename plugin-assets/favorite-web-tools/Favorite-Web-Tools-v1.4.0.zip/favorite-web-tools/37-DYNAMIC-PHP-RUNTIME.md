# Dynamic PHP Runtime — v1.3.2

## Goal

`Dynamic PHP Runtime (Sandboxed)` is a canonical engine for future tools whose processing can be implemented as pure server-side PHP without adding a new plugin class for each tool.

## Admin flow

`Web Tools → Create Tool → Canonical Engine → Dynamic PHP Runtime (Sandboxed)`

Write a PHP **function body** only (no `<?php` tags). The runtime exposes:

- `$input` — validated tool input array
- `$context` — read-only metadata (`tool_id`, `tool_slug`, `tool_name`, `engine`)

Example:

```php
$text = (string)($input['text'] ?? '');
return [
    'success' => true,
    'type' => 'TEXT',
    'value' => strtoupper($text),
];
```

A scalar/array may also be returned directly and will be normalized automatically.

## Security boundary

Dynamic PHP is **not** executed with `eval()` in the CMS process. It runs in a separate PHP CLI subprocess with `-n`, randomized temp sandbox, `open_basedir`, disabled URL wrappers, disabled process/network/filesystem escape functions, memory/output limits, and wall-clock timeout. Input and output use JSON pipes. If PHP CLI or `proc_open` is unavailable, execution fails closed.

Dynamic PHP cannot access Favorite CMS classes/database, arbitrary files, environment variables, network sockets, shell/process execution, includes/requires, or superglobals. Tools requiring those capabilities must use Controlled Handler, Python API, or Generic HTTP API.

## Migration use case

Existing HTML/CSS/JavaScript tools can be progressively converted so the sensitive processing becomes Dynamic PHP while the Frontend Presentation Design remains separate. This does not require a plugin release for each ordinary tool.

## Backward compatibility

Existing `PHP` means **PHP Controlled Handler** and is unchanged. `DYNAMIC_PHP` is a new separate engine. No existing tool record is migrated automatically.

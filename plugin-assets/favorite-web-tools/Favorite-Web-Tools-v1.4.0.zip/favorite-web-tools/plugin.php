<?php
/**
 * Plugin Name: Favorite Web Tools
 * Plugin URI: https://github.com/favoritecode/Favorite-CMS-Universal
 * Description: Final universal tool-building platform for Favorite CMS supporting controlled handlers, dynamic operations/pipelines, sandboxed PHP runtime, browser/Python/HTTP engines, secure files/secrets/assets, revisions, import/export, logs and diagnostics.
 * Version: 1.4.0
 * Author: Favorite CMS Team
 */

declare(strict_types=1);

namespace FavoriteCMS\Tools;

require_once __DIR__ . '/autoload.php';

// Bootstrap plugin when Favorite CMS boots
if (isset($app) && $app instanceof \FavoriteCMS\Core\Application) {
    FavoriteWebToolsPlugin::bootstrap($app);
} elseif (function_exists('app')) {
    $coreApp = app();
    if ($coreApp instanceof \FavoriteCMS\Core\Application) {
        FavoriteWebToolsPlugin::bootstrap($coreApp);
    }
}

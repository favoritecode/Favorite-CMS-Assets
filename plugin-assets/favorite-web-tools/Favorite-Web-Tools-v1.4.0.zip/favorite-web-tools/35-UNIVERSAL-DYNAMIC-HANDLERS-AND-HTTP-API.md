# Favorite Web Tools v1.3.0 — Universal Builder Upgrade

## Goal

After this platform upgrade, ordinary new tools should be creatable from the admin area without adding a new PHP class or releasing the plugin again.

The existing built-in Controlled Handler registry remains fully supported. The upgrade adds two safe extension paths:

1. **Dynamic Controlled Handlers** — reusable server-side pipelines built from a finite allowlist of operations.
2. **Generic HTTP API Engine** — server-side API-backed tools configured from the Tool Builder.

Existing HTML/CSS/JavaScript workspace support and Python API services remain unchanged.

---

## Dynamic Controlled Handlers

Admin path:

```text
Web Tools → Dynamic Handlers → Create Handler
```

A handler has:

- Name
- Handler ID
- Description
- Active/Disabled status
- JSON definition

Example:

```json
{
  "input_key": "text",
  "result_type": "TEXT",
  "steps": [
    {"operation": "trim"},
    {"operation": "uppercase"},
    {"operation": "suffix", "value": "!"}
  ]
}
```

Supported operations are intentionally allowlisted. The runtime does **not** use `eval()`, arbitrary PHP source, shell commands, arbitrary filesystem access, or direct database access.

Dynamic handlers are automatically available in:

```text
Web Tools → Create/Edit Tool → PHP (Controlled Handler) → Registered Controlled Handler
```

At plugin boot, active dynamic handlers are also registered into the controlled-handler catalog when their IDs do not collide with built-in handlers. Built-in handler IDs always win on collision.

The dynamic pipeline can also call one existing built-in Controlled Handler through the `core_handler` operation, enabling safe composition without source-code changes.

---

## Generic HTTP API Engine

Tool Builder engine:

```text
HTTP_API
```

Configurable fields:

- API URL
- HTTP method: GET/POST/PUT/PATCH/DELETE
- JSON or form body mode
- Header map
- server-side environment-secret references such as `{{env:MY_API_KEY}}`
- request input mapping
- optional response dot-path
- timeout (1–30 seconds)
- optional host allowlist

Security controls include:

- HTTP/HTTPS only
- URL credentials blocked
- localhost/private/reserved network targets blocked
- standard ports only
- redirects disabled
- proxy use disabled
- host DNS resolution checked for public addresses
- response size cap
- secrets resolved only server-side
- raw API configuration is not exposed by the public Tool API

Example header configuration:

```json
{
  "Authorization": "Bearer {{env:MY_API_KEY}}",
  "X-App": "favorite-web-tools"
}
```

Example request mapping:

```json
{
  "q": "text",
  "lang": "language"
}
```

---

## Backward Compatibility

The upgrade intentionally preserves:

- existing tool rows and slugs;
- built-in PHP handler classes and IDs;
- existing HTML/CSS/JavaScript engines;
- existing Python API services;
- existing access modes;
- existing public routes and execution API;
- existing frontend designs;
- existing categories and statuses.

Migration `006_create_favorite_web_tool_dynamic_handlers_table.php` only adds a new table and does not rename or remove existing tables or columns.

---

## When a plugin update is still required

A new plugin release should only be needed when a genuinely new **platform capability** is required, for example a new low-level media processor or execution engine that cannot be expressed with:

- Browser workspace code;
- Dynamic Controlled Handler operations;
- existing Controlled Handlers;
- Python API;
- Generic HTTP API.

Ordinary new tools should be configuration/data, not new plugin source files.


## v1.3.2 — Dynamic PHP Runtime

The Canonical Engine selector now includes `DYNAMIC_PHP` / **Dynamic PHP Runtime (Sandboxed)** for pure server-side PHP transformations without creating a plugin handler class. It runs only in a restricted PHP CLI subprocess and fails closed when the host does not provide PHP CLI + `proc_open`. Existing `PHP` Controlled Handler behavior is unchanged. See `37-DYNAMIC-PHP-RUNTIME.md`.
